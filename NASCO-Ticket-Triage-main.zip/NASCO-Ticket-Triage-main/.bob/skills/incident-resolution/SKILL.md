---
name: incident-resolution
description: Use when the user wants to resolve an incident, review similar historical incidents, get a recommended resolution, or write resolution notes back to a ServiceNow ticket.
---

# Incident Resolution Workflow

This skill orchestrates the full incident resolution review flow using the ServiceNow MCP tools.
It covers: incident selection → similarity search → historical review → recommendation → approval → write-back.

---

## Step 1 — Identify the target incident

**Before doing anything else, re-read the user's original message right now.** Determine whether it contains an incident number (a string matching `INC` followed by digits, e.g. `INC0012345`).

**If an incident number was provided** (e.g. INC0012345):

- Call `sn_query` on table `incident` with `query: "number=<INC...>"` and `display_value: "true"`. Do **not** use `sn_get` — it requires a raw GUID sys_id and will always fail with a 404 when given a human-readable number like `INC0010010`.
- If not found (record_count = 0), tell the user and stop.
- Store the result as `target_incident`.
- Proceed to Step 2.

**If NO incident number was provided:**

- Immediately call `sn_query` on table `incident` with `query: "contact_type=Azure^stateIN1,2"` and `limit: 50` and `display_value: "true"` to fetch all open and in-progress incidents. Do not ask the user for a filter first.
- Present the full list as a numbered table (number, short description, state, priority, company).
- **HARD STOP. Do NOT proceed to Step 2. Do NOT call any more tools. End your response here and wait for the user to select an incident.**
- Once the user selects an incident: call `sn_query` on table `incident` with `query: "number=<INC...>"` and `display_value: "true"`, store the first result as `target_incident`, then proceed to Step 2.

---

## Step 2 — Build the similarity query

Derive similarity signals from `target_incident`:

1. **Keywords**: extract 2–4 meaningful words from `short_description` (strip noise words: the, a, an, is, in, on, at, to, for, of, with, has, be, are, was). If `description` is populated, add up to 2 more unique keywords from it. Use only words that are specific to the problem (e.g. "login", "timeout", "VPN") — do not use generic words like "issue", "error", "problem", "unable", "please", "user", "request".

2. **Build the sysparm_query** combining ALL of the following — every clause is mandatory unless marked optional:
   - Keyword matching: `short_descriptionLIKE<keyword>` for each keyword, joined with `^OR`. Wrap the entire keyword group in parentheses conceptually — it is the only `^OR` block; everything else uses `^` (AND).
   - Category match (if `category` is populated on the target): `^category=<category>`. **Skip if blank.**
   - Company match: always append `^company.name=Nasco-dev`.
   - Channel match: always append `^contact_type=Azure`.
   - CMDB CI match (if `cmdb_ci` is populated on the target): `^cmdb_ci=<cmdb_ci>`. **Skip if blank.**
   - Assignment group match (if `assignment_group` is populated on the target): `^assignment_group=<assignment_group_sys_id>`. **Skip if blank.**
   - Restrict to resolved/closed only: always append `^stateIN6,7`.
   - Restrict to recent history only: always append `^resolved_atONLast 2 years`.
   - Exclude the target incident itself: `^sys_id!=${target_incident.sys_id}`.
   - Sort most-recently resolved first: append `^ORDERBYDESCresolvedAt`.

   Example query structure:

   ```
   short_descriptionLIKElogin^ORshort_descriptionLIKEVPN^category=Network^company.name=Nasco-dev^contact_type=Azure^cmdb_ci=<cmdb_ci>^stateIN6,7^resolved_atONLast 2 years^sys_id!=<sys_id>^ORDERBYDESCresolvedAt
   ```

3. **Label boost**: if the target incident has labels, retrieve them by calling `sn_query` on table `incident` with `query: "labels=<label>"` and `limit: 10` for each label. Collect those `sys_id` values as a label-boosted set.

---

## Step 3 — Search for similar historical incidents

- Call `sn_query` on table `incident` with the constructed query, `limit: 20`, and `display_value: "true"`. Only resolved (state=6) and closed (state=7) tickets from the last 2 years are returned — enforced by `^stateIN6,7` and `^resolved_atONLast 2 years` in the query.
- **Also call `search_historical_tickets`** with a query derived from the target incident's keywords (the same 2–6 keywords extracted in Step 2). This searches the unified knowledge base of pre-indexed resolved tickets across Mainframe (`InquirePaymentInformation_v2`) and Midtier (`AI Benefits Portal`) systems. Collect any results as `kb_candidates`. If no results are returned, continue without them — this step is additive, not a blocker.
- **Relevance gate — apply after fetching.** For each returned incident, count how many of the following match the target incident:
  - Same `category`
  - Same `cmdb_ci`
  - Same `assignment_group`
  - At least one keyword present in the returned incident's `short_description`

  Keep only incidents that satisfy **at least 2 of the above criteria**. If fewer than 3 incidents pass the gate, relax to **at least 1 criterion** and re-evaluate. If still 0, surface what was returned with a warning: "Matches may have low relevance — please review carefully."

- **Resolution quality gate — apply after the relevance gate.** Discard any incident whose `close_notes` field is empty, null, or generic. A `close_notes` value is considered generic if it matches any of the following patterns (case-insensitive):
  - Empty or whitespace-only string
  - Common filler phrases with no actionable content, such as: `"resolved"`, `"closed"`, `"done"`, `"fixed"`, `"ok"`, `"completed"`, `"as per discussion"`, `"as discussed"`, `"no issues found"`, `"issue resolved"`, `"resolved as per user"`, `"resolved by user"`, `"auto-closed"`, or any string shorter than **20 characters**.
  - Only incidents with substantive `close_notes` (specific steps, commands, configurations, or findings) pass this gate.
  - If fewer than 3 incidents pass this gate, do **not** relax it — it is a hard quality filter. Simply work with fewer incidents and note in the recommendation how many quality sources were available.

- Merge the label-boosted sys_ids: incidents in the label-boosted set should be listed first (they receive a relevance boost), followed by remaining matches.
- Merge in `kb_candidates`: knowledge-base hits that are not already in the list are appended after the label-boosted and keyword-matched results.
- Deduplicate by `sys_id` (or ticket number for knowledge-base entries that may not have a ServiceNow `sys_id`).
- Trim the merged list to a maximum of **10 similar incidents**.

---

## Step 4 — Display similar incidents and STOP for confirmation

Before generating any recommendation, **always show the similar incidents to the user.**

Present them as a table with these columns:
| # | Number | Short Description | State | Priority | Company | Resolved At |

Mark label-boosted incidents with `★` in the `#` column.

Then say:

> "These are the most similar historical incidents I found. Reviewing their resolutions to generate a recommendation. Proceed?"

**HARD STOP. Do NOT proceed to Step 5 in the same turn. Do NOT call any more tools. Do NOT generate a recommendation. End your response here and wait for the user's reply.**

- If the user replies **yes / ok / proceed / y**: continue to Step 5.
- If the user replies **no / skip**: go directly to Step 7 with no recommendation text prefilled.
- If the user replies anything ambiguous: ask for clarification before proceeding.

---

## Step 5 — Retrieve resolution history from similar incidents

For each of the top **5** similar incidents (prioritize label-boosted first, then most recently resolved):

1. Call `sn_query` on table `sys_journal_field` with `query: "name=incident^element=work_notes^element_id=<sys_id>"` and `limit: 10` and `fields: "value,sys_created_on"`.
   - If that returns entries, collect the `value` fields as resolution notes.
   - If that returns nothing (journal not exposed for this instance), fall back to the incident's `close_notes` field from the similarity search result. **Only use `close_notes` as a fallback if it passed the resolution quality gate in Step 3** (i.e. it is non-empty, non-generic, and at least 20 characters). If the fallback `close_notes` does not meet this bar, treat this incident as having no usable evidence and skip it.

2. Also collect the incident's own `close_notes` if it passed the resolution quality gate and differs from the journal entries.

3. For any knowledge-base candidates (`kb_candidates`) that surfaced in Step 3, their resolution content is already embedded in the knowledge-base record — no additional tool call is needed. Include their resolution text directly in the evidence list.

Build a resolution evidence list: for each of the top-5 similar incidents that have usable evidence, store:

```
{ number, short_description, close_notes, work_notes_values: string[] }
```

---

## Step 5b — Invalid Argument Classification Check

Before generating any recommendation, classify the target incident into one of three types. Store the result as `ticket_type` — it is used in Step 9 to determine whether a CSR is required.

---

**Type 1 — Working as Designed (Invalid Argument)**

The failure was caused by the caller submitting input that violates a documented field rule. The system is behaving correctly. No code change is needed.

Classify as **Working as Designed** when the ticket indicates:
- A field expected to be numeric contained non-numeric characters or whitespace
- A required field was missing or empty
- A value exceeded a defined length or fell outside a documented range
- The caller supplied a value in the wrong format for a field the API has always enforced

**If Working as Designed:**
- Skip Step 6 entirely.
- Produce a **User Education Note**:

  ```
  ## Resolution — Working as Designed

  **Field:** <field name>
  **Rule violated:** <what the API requires for this field>
  **What was submitted:** <description of the invalid value, from the ticket>
  **Corrected usage:** <what the caller should submit instead>

  No code change is required. The system is behaving correctly.
  Advise the submitter to correct their input and resubmit.
  ```

- Proceed directly to Step 7 with this note as the prefilled recommendation text.
- Set `ticket_type = "Working as Designed"`.

---

**Type 2 — Code Defect**

The system is not behaving as designed. A bug exists in existing implementation. A targeted code fix is required. No CSR is needed.

Classify as **Code Defect** when the ticket indicates:
- A program returns wrong data, incorrect return codes, or unexpected errors for valid input
- Logic that should work correctly does not — file reads, calculations, or data transformations produce incorrect results
- The failure is in existing, documented behaviour — not a request for new capability

**If Code Defect:**
- Proceed normally to Step 6.
- Set `ticket_type = "Code Defect"`.

---

**Type 3 — Enhancement / Missing Functionality**

The system is working as implemented, but the caller expects functionality that does not currently exist. New development is required. A CSR is required.

Classify as **Enhancement / Missing Functionality** when the ticket indicates:
- A field or response value is expected but was never implemented
- A capability is requested that goes beyond current documented behaviour
- Historical evidence from Step 5 shows similar tickets were resolved via a CSR or classified as Feature Expansion / Feature Request

**If Enhancement / Missing Functionality:**
- Proceed normally to Step 6 to generate a resolution note documenting the technical scope.
- Set `ticket_type = "Enhancement"`.

---

State the classification before continuing:

> "**Ticket type: <Working as Designed | Code Defect | Enhancement / Missing Functionality>**"
> "<one sentence explaining why>"

---

## Step 6 — Generate the recommended resolution

Synthesize a recommended resolution note **strictly from the evidence collected in Step 5**. No external knowledge, assumptions, or inferred steps are permitted.

Rules:

- **Only use text that appears in `close_notes` or `work_notes_values` of the fetched incidents.** Do not add steps, commands, or explanations that are not present in the evidence.
- **Do not generalise.** If the evidence says "restarted the IIS service on server PROD-WEB-01", keep that specificity — do not expand it to "restart the relevant web service".
- **Cite the source.** After each resolution step, note which incident it came from using a bold bracketed badge styled as `**[↗ INC0009812]**`. This citation must be visually distinct — always bold, always wrapped in square brackets, and always prefixed with the `↗` arrow so it stands out from the surrounding resolution text. Example: `Restarted the IIS service on PROD-WEB-01. **[↗ INC0009812]**`
- Open with a one-sentence summary of the common resolution pattern observed across the evidence.
- List the key resolution steps verbatim or near-verbatim (bulleted, concise).
- Note any divergence if resolution patterns differ significantly across incidents.
- Close with: "Please review and adjust before approving."

Do **not** fabricate steps. If the evidence is thin (e.g. all `close_notes` are empty and journal entries returned nothing), say so honestly and do not invent a resolution: "No detailed resolution history was available for similar incidents. Please provide your own resolution notes below."

Present the recommendation in a clearly labelled block:

```
## Recommended Resolution Note

<recommendation text>
```

Then ask:

> "Would you like to:
> (A) Accept this recommendation as-is
> (B) Edit the text before saving
> (C) Write your own resolution note
> (D) Cancel without saving"

---

## Step 7 — Collect the final note text

- **A (accept)**: use the recommendation text unchanged.
- **B (edit)**: present the recommendation text and ask the user to provide their edited version. Use their edited text.
- **C (write own)**: ask the user to type their resolution note. Use that text.
- **D (cancel)**: stop. Tell the user no changes were made.

---

## Step 8 — Write the resolution note back to the incident

- Before calling `update_ticket`, strip all source citations from the final note text. Citations are bold bracketed badges of the form `**[↗ INCxxxx]**`. Remove every occurrence of ` \*\*\[↗ INC\d+\]\*\*` from the text.
- Call `sn_update` on table `incident` with:
  - `sys_id`: `target_incident.sys_id`
  - `fields`: `{ "close_notes": <citation-stripped final note text> }`

- On success, confirm to the user:

> "✓ Resolution note written to **<number>** (<short_description>).
> sys_id: <sys_id>"

- On error, show the error message and offer to retry or cancel.

---

## Step 9 — CSR Check

After the resolution note has been written back to the incident, check `ticket_type` set in Step 5b.

**If `ticket_type = "Enhancement"`:**

Output the following CSR flag:

```
## ⚠ CSR Required

This ticket is classified as Enhancement / Missing Functionality.
The resolution requires new development and must be tracked as a
Change Service Request (CSR) before implementation begins.

**Affected components:** <list programs and copybooks identified from the ticket and resolution evidence>
**Compile order:** <correct sequence — copybooks first, then dependent programs in dependency order>

Recommended next step: check the CSR register for an existing change request
covering this scope before opening a new one.
```

**If `ticket_type = "Code Defect"` or `"Working as Designed"`:**

Output a brief closing line:

```
No CSR required. This ticket is a <Code Defect | Working as Designed> —
the fix can be implemented directly without a change request.
```

Then, **if and only if `ticket_type = "Code Defect"`**, immediately ask:

> "Would you like me to implement the fix in the codebase now? (yes / no)"

**HARD STOP. Do NOT proceed to Step 10. End your response here and wait for the user's reply.**

- If the user replies **yes / y / ok / sure**: proceed to Step 10.
- If the user replies **no / skip / cancel**: tell the user "No code changes were made." and stop.
- If the user replies anything ambiguous: ask for clarification before proceeding.

Do **not** ask this question for `ticket_type = "Enhancement"` or `"Working as Designed"` — those types have no direct code fix to apply.

---

## Step 10 — Implement the code fix

This step only runs when `ticket_type = "Code Defect"` and the user confirmed they want the fix applied.

### 10a — Locate the affected file(s)

Using the resolution evidence from Step 5 and Step 6, identify the specific file(s) and symbol(s) that need to change. The close_notes or work_notes from the similar incidents will name the file path, class, method, or property directly — use those exact references.

- If the evidence names a file path explicitly (e.g. `product-details-modal.component.ts`), use `grep` or `glob` to locate it in the workspace before reading it. Do not assume the path — verify it exists.
- If no file is named in the evidence, use `grep` to search the codebase for the specific symbol, property name, or hardcoded value described in the resolution (e.g. `canEdit = true`).
- Read only the portion of the file that contains the defect — use `read_file` with a line range if the file is large.

### 10b — Apply the fix

Apply the minimal targeted change that resolves the defect as described in the resolution evidence. Follow these rules:

- **Minimal change only.** Change exactly what the resolution says. Do not refactor surrounding code, rename variables, add comments, or improve formatting beyond the fix itself.
- **Match existing code style.** Follow the indentation, naming, and syntax conventions of the file being edited.
- **Use `apply_diff` or `search_and_replace`** for surgical edits to existing files. Use `write_file` only if an entirely new file must be created.
- **Do not invent the fix.** If the resolution evidence does not describe the exact change with enough specificity to implement it safely, stop and tell the user: "The resolution evidence does not provide enough detail to safely implement the fix automatically. Please apply the change manually."

### 10c — Confirm the change

After applying the fix, report exactly what was changed:

> "✓ Fix applied to `<filename>` (line <N>–<M>):
> — <one-line description of what changed>"

If more than one file was changed, list each file separately.

Then ask the user to verify the change looks correct and run any relevant tests before closing the incident.

---

## Practical limits to communicate to the user

If asked, or if it is relevant to the outcome, be transparent about these constraints:

- **Journal retrieval is best-effort.** Whether work notes and comments are accessible depends on the ServiceNow instance configuration and integration user permissions. When journal entries return empty, resolution evidence falls back to the `close_notes` field on the incident record.
- **Similarity is keyword + field based, not semantic.** There is no vector or embedding search. Short descriptions with vague wording or unusual phrasing may produce weak matches. The relevance gate in Step 3 is the primary defence against irrelevant results.
- **Label boost is additive.** Labels are a bonus signal, not a filter. Incidents without labels on the target still get keyword similarity results.
- **Excluded states.** Historical similarity search is always restricted to resolved (state=6) and closed (state=7) incidents via `^stateIN6,7`. Open, in-progress, on-hold, and cancelled tickets are never included.
- **Date window.** Only incidents resolved in the last 2 years are considered. Older resolutions may reflect outdated procedures and are excluded.
- **No hallucination policy.** The recommendation in Step 6 must be derived entirely from the fetched evidence. If the evidence does not contain resolution steps, the recommendation must say so — it must never invent steps.
- **Ticket type classification.** Step 5b classifies every ticket into one of three types before any recommendation is generated: Working as Designed (invalid argument — no code change, user education note only), Code Defect (targeted fix, no CSR), or Enhancement / Missing Functionality (new development required, CSR flagged at Step 9). This prevents misrouting tickets that describe validation rejections into the code-fix path, and ensures Enhancement tickets are escalated correctly rather than resolved as direct fixes.
- **CSR flag.** Step 9 fires after the resolution note is written back. If the ticket was classified as Enhancement in Step 5b, a CSR Required block is output naming the affected components and compile order. This is the handoff signal into CSR Identification & Scoping.
