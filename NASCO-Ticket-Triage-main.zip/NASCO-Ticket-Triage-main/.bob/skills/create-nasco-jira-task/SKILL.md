---
name: create-nasco-jira-task
description: Use when the user wants to create a Jira task in the NASCO SAM1 project using the standard NASCO Change Control template — derives all field values from context already in the conversation (incident details, CSR match, effort assessment) and skips any field that cannot be determined.
---

# Create NASCO Jira Task

Follow these steps to create a Jira task in the SAM1 project using the NASCO Change Control template.

## Step 1 — Gather Context from the Conversation

Before calling any tool, collect the following from what is already known in the current conversation. Do **not** ask the user to repeat information that has already been established. If a value cannot be determined, mark it as **skip**.

| Field | Source |
|---|---|
| Incident number | The originating ServiceNow incident |
| Short description | The incident's short description — used to derive the summary |
| CSR ID | The matched CSR from the duplicate check |
| CSR priority | From the matched CSR's details |
| Work category | From the effort assessment (Defect Fix / Feature Expansion / Configuration Change) |
| Affected components | From the effort assessment |
| Compile & link order | From the effort assessment |
| Root cause | From the recommended resolution |
| Test scope | From the effort assessment |
| Effort size | From the effort assessment (Small / Medium / Large + justification) |
| System indicator | Derived from the incident domain (e.g. Mainframe / CICS-COBOL) |
| Service type indicator | Derived from the work category |

## Step 2 — Map to Jira Fields

Map the gathered context to SAM1 Jira fields. Skip any field whose value is **skip**.

| Jira Field | Value |
|---|---|
| `summary` | Concise title derived from the incident's short description |
| `issue_type` | `Task` |
| `priority` | Derived from the matched CSR's priority |
| `labels` | The matched CSR ID (e.g. `CSR-0042`) |
| `description` | See template below |

All other fields (assignee, due date, fix version, components) — **skip unless explicitly provided**.

## Step 3 — Build the Description

Structure the `description` field using the following template. Populate each section from the gathered context. Omit any section whose content is **skip**.

```
**Business Request**
[One paragraph: what is being delivered, why it is needed, referencing the originating incident and the matched CSR.]

**CSR Number:** [CSR ID]
**Project Name:** [Project name from context, e.g. NASCO — SAM1]
**System Indicator:** [e.g. Mainframe / CICS-COBOL]
**Service Type Indicator:** [e.g. System modification/enhancement]

**Affected Components**
[List each component on its own line]

**Compile & Link Order**
[Ordered list from the effort assessment]

**Root Cause**
[From the recommended resolution]

**Test Scope**
[From the effort assessment]

**Effort Estimate**
[Size] — [Justification from the effort assessment]

**Originating Incident:** [Incident number]
```

## Step 4 — Create the Jira Task

Call `jira_create_issue` with the mapped fields. Use only the fields identified in Step 2 — do not pass fields marked as **skip**.

## Step 5 — Display the Result

After the task is created, display the new issue key, summary, and full description in chat so the user can verify the content.
