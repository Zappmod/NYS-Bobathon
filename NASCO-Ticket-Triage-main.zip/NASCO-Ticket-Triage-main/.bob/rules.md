## ServiceNow Tool Preferences

When looking up ServiceNow records by ticket number (e.g. INC0010012, CHG0001234),
always use `sn_query` with a `query` filter such as `number=INC0010012`.
Never use `sn_get` for this purpose — it requires a `sys_id`, which is an internal
UUID and is not the same as a human-readable ticket number.
