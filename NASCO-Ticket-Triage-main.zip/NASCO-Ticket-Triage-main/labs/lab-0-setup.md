# Lab 0 — Environment Setup

This lab gets you connected to the shared ServiceNow instance, the knowledge base, and the Jira MCP before you run any of the other labs. It should take about two minutes.

## Lab Outcomes

By the end of this lab you will have:
- Bob installed and signed in
- All MCP servers active (pre-configured in the workspace)
- Verified all connections with test queries

---

## Step 1 — Install Bob

If you have not already installed Bob, follow the official getting-started guide:

👉 <https://bob.ibm.com/docs/ide/getting-started/install>

Click the **Sign in to Bob** button to log in with your IBM ID when prompted.

![Bob sign-in screen](images/loginBob.png)

---

## Step 2 — Open the Workshop Folder

Unzip the repository folder, then open it in Bob (`File > Open Folder`).

![Open project folder in Bob](images/openProject.png)

---

## Step 3 — Check Bob MCP Settings

The MCP configuration is already committed at `.bob/mcp.json` — no edits required. Bob connects to both servers automatically on folder open.

Open Bob Settings.

![Bob Settings](images/bob-settings.png)

Find the MCP settings. You should see **three** `🟢 Connected` entries in Bob's MCP panel — `servicenow`, `knowledge-base`, and `JIRA`.

![Bob MCP connected](images/bob-mcp-connected.png)

If any entry shows red, click **Reload MCPs**.

---

## Step 4 — Verify All Connections

Open a new chat and run the prompts below to confirm all three MCPs are working.

### Prompt A — ServiceNow

```text
Can you provide me with ServiceNow tickets that are close to reaching their SLA?
```

**Success check:**
- Bob calls a ServiceNow MCP tool (visible as a tool-use step in the chat)
- A list of incidents is returned with numbers in the format `INC0000000` (e.g. `INC0000015`)
- Incidents are grouped or sorted by SLA due date, with priority and assignee visible
- No authentication or connection errors appear

### Prompt B — Knowledge Base

```text
Use the knowledge-base MCP to search for historical tickets related to "Payment ID validation" or "canEdit permission modal". Show the top results with their ticket number, short description, and a one-sentence summary of the close notes.
```

**Success check:**
- Bob calls `search_historical_tickets` (visible as a tool-use step in the chat)
- Search successfully returns relevant historical incidents across Mainframe or Midtier applications
- No connection errors appear

### Prompt C — Jira

```text
List the most recently updated Jira issues from NASCO project SAM1 . For each one show the issue key, summary, type, and status.
```

**Success check:**
- Bob calls an Atlassian MCP tool (visible as a tool-use step in the chat)
- Issues are returned with keys in the format `SAM1-N` (e.g. `SAM1-18`)
- Each issue shows its key, summary, type (e.g. Task, Incident), and status (e.g. To Do)
- No authentication or connection errors appear

If any prompt fails, open Bob Settings and reload MCPs. If the problem persists, contact your facilitator.

---

## Optional Step 5 — Start the AI Benefits Portal (for Lab 1)

Lab 1 uses a local Angular app (`aibenefits-fe-bobathon/`) as its codebase context. If you want to reproduce the reported issues visually before triaging them, start the app now by following the instructions in [`aibenefits-fe-bobathon/docs/QUICK-START.md`](../aibenefits-fe-bobathon/docs/QUICK-START.md) — the backend runs on port 8080 and the frontend on port 4300. Demo accounts are `jack@aibenefits.com` (full access) and `smith@aibenefits.com` (read-only). **This step is optional for Lab 1** — the triage work is done entirely through ServiceNow MCP tool calls; the running app is only needed for visual reproduction.

---

## You're Ready

Once all three prompts return results, move on to the next labs:

**Start with Midtier Lab:** [Lab 1 — Midtier Ticket Triage](lab-1-midtier-fe-triage.md)

**Start with Mainframe Lab:** [Lab 2 — Ticket Analysis & Classification](lab-2-ticket-analysis-classification.md)
