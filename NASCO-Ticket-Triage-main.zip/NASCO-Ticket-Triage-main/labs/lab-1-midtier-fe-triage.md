# Lab 1 — Midtier Ticket Triage

This lab introduces AI-assisted ticket triage using two ServiceNow incidents raised against the **AI Benefits Portal** — an Angular + Python FastAPI web application. The two tickets cover two of the most common resolution paths: a missing feature that requires new development (INC0010012) and a permission gap caused by hardcoded logic that must be properly wired up (INC0010015). You will use the **`incident-resolution` skill** on both tickets, observing how the same workflow produces two distinct outcomes — a CSR flag for the Enhancement and a direct fix note for the Code Defect.

> **Running the app locally** — If you want to reproduce the issues visually in a browser, follow the start instructions in [`aibenefits-fe-bobathon/docs/QUICK-START.md`](../aibenefits-fe-bobathon/docs/QUICK-START.md).

## Lab Outcomes

By the end of this lab you will use Bob, the ServiceNow MCP tools, Jira MCP tools, and Knowledge Base MCP tools to:
- classify two Midtier incidents and match each one to the correct resolution path (Enhancement Request, Code Defect)
- use the `incident-resolution` skill on INC0010012 to surface it as an Enhancement, write a resolution note, and trigger the CSR Required flag
- use the `incident-resolution` skill on INC0010015 to diagnose the Code Defect, synthesize the fix recommendation, and write the resolution note back to ServiceNow
- create a Jira story in the `SAM1` project driven by the CSR Required output from the Enhancement path

---

## 1a — Classify Incidents

### Goal

Have Bob retrieve the incidents and classify each one before any investigation begins. The goal is a quick triage table — not a full diagnosis — so you can confirm the approach for each ticket before going deeper in sections 1b–1d.

### Bob Prompt

```text
Use the ServiceNow MCP tools to look up the following incidents from the incident table:
INC0010012, INC0010014, INC0010015

For each ticket, return:
- Ticket number and short description
- State and priority
- Triage classification: one of "Working as Desired", "Code Defect", or "Enhancement Request". Use the knowledge base to assist with classification.
- One-sentence rationale for the classification

Display the results as a table. Do not write anything back to ServiceNow.
```

### Success Check

Bob returns a three-row table. The expected classifications are:

| Ticket | Classification |
|---|---|
| INC0010012 | Enhancement Request |
| INC0010014 | Working as Desired |
| INC0010015 | Code Defect |
---

## 1b — INC0010012: Enhancement Request — Resolution Skill

### Goal

Run the `incident-resolution` skill on INC0010012 to let the skill's own classification logic determine it is an Enhancement, write the resolution note back to ServiceNow, and observe the ⚠ CSR Required flag the skill emits at Step 9.

**Context:** The AI Benefits Portal's category filter is driven by `backend/category.properties`. A comment in that file reads: *"Users requirement was to provide Category filter for Medical and Dental products."* Vision was never part of the original requirement. The ticket is in **Resolved** state.

### Bob Prompt

```text
Resolve Incident INC0010012
```

### Success Check

Bob invokes the `incident-resolution` skill. The skill searches the knowledge base, surfaces `CSR-0101` / `INC0009101` as prior evidence that Vision was out of scope by design, and classifies INC0010012 as **Enhancement / Missing Functionality**. A resolution note is written to the ticket via `sn_update`. At Step 9 the skill outputs the ⚠ **CSR Required** block, listing the affected components (`backend/category.properties`, frontend filter components) as the handoff signal for the next step.

> **ServiceNow write-back:** This step writes a resolution note to INC0010012.

---

## 1c — INC0010012: Create the Jira Story

### Goal

Use the CSR Required output from 1b to create a tracked Jira story in the `SAM1` project. The skill has already done the scoping work — this step turns that output into a deliverable artifact.

### Bob Prompt

```text
Using the JIRA MCP tools, create a task in the SAM1 project to track the enhancement identified for INC0010012. Use the CSR Required output as the basis for the story description and link back to INC0010012. Use the create-nasco-jira-task skill to structure the task, and derive an effort estimate from the affected components before creating the ticket.
```

### Success Check

Bob derives an effort estimate (**Small** — four isolated, low-risk file changes with no compile/deploy chain), then invokes the `create-nasco-jira-task` skill and calls `jira_create_issue`, returning a new issue key in the `SAM1` project labelled `CSR-0101`. The description follows the NASCO Change Control template — Business Request, CSR Number, System Indicator, Affected Components, Compile & Link Order, Root Cause, Test Scope, Effort Estimate, and Originating Incident — with references to both INC0010012 and CSR-0101.

> **No additional ServiceNow write-back in this step.** The Jira story is the only artifact created here.

![Example Jira ticket created for INC0010012](images/mid-tier-JIRA.png)

---

## 1d — INC0010015: Code Defect — Resolution Skill

### Goal

Run the `incident-resolution` skill on INC0010015 to diagnose why the Edit button is visible to the read-only user `smith@aibenefits.com`, pinpoint the hardcoded code location, synthesize the fix recommendation from historical evidence, and write the resolution note back to ServiceNow.

### Bob Prompt

```text
Resolve Incident INC0010015
```

> **Same prompt, different outcome:** The skill classifies INC0010015 as a **Code Defect** (not an Enhancement), so Step 9 outputs "No CSR required" instead of the CSR flag — demonstrating how the same three-word prompt drives two entirely different resolution paths based on the skill's own classification logic.

> **Code fix + automated testing:** After writing the resolution note, the skill asks whether to implement the fix in the codebase. Reply **yes** and Bob will locate the defective file from the ticket evidence, apply the targeted fix, and run the automated test suite to confirm nothing is broken — all without leaving the chat.

![Code change applied by Bob for INC0010015](images/codeChange.png)

### Success Check

Bob invokes the `incident-resolution` skill, finds `INC0009102` as a matching historical case, and classifies INC0010015 as a **Code Defect**. The resolution note is synthesized from historical evidence and written back to INC0010015 in ServiceNow. Step 9 outputs "No CSR required." When prompted, Bob locates the defective file, applies the targeted code fix directly in the codebase, and runs the automated test suite — all tests pass.

> **ServiceNow write-back:** This step writes a resolution note to INC0010015.

![Automated test results after code fix](images/testingResult.png)

---

## Wrap-Up

In this lab you triaged three Angular Midtier incidents, covering all three resolution paths, and completed the full loop from classification through to code fix and Jira story creation:

- **INC0010012** — classified as **Enhancement Request**. The knowledge base confirmed Vision was out of scope by design. The `incident-resolution` skill wrote a resolution note to ServiceNow and emitted a ⚠ CSR Required flag. The `create-nasco-jira-task` skill then structured a tracked Jira story in `SAM1` — with effort estimate, affected components, and the full NASCO Change Control template populated automatically (1b → 1c).
- **INC0010014** — classified as **Working as Desired**. The knowledge base confirmed the "Configure" status label is the correct, intentional lifecycle value — no action required.
- **INC0010015** — classified as **Code Defect**. The `incident-resolution` skill matched historical evidence, synthesized the fix recommendation, and wrote the resolution note to ServiceNow with no CSR needed. When prompted, Bob applied the targeted code fix directly in the codebase and ran the automated test suite — all tests passed (1d).

The three classification outcomes, two ServiceNow write-backs (1b and 1d), one Jira story (1c), and one in-codebase fix (1d) show how the same prompts and skills produce the right outcome for each ticket type — demonstrating the full Midtier triage loop before moving into deeper mainframe systems.

---

**Next Lab:** [Lab 2 — Ticket Analysis & Classification](lab-2-ticket-analysis-classification.md)
