# Lab 3 — Mainframe Resolution Assistance

This lab focuses on diagnosing a real mainframe code defect and recommending a fix. The anchor ticket is **INC0010010**: `InquirePaymentInformation_v2.getPaymentInformation` does not read records for BankAccountId values `0123` and `0124`.

The defect lives in `HKAP170C`, the WAPI business logic program. That program reads payment records across three CICS files in sequence — bank master (`S1000`), bank interim (`S1100`), and bank purge (`S1200`) — swapping the Account ID between two hardcoded values (`0404` provider check / `0405` subscriber check) when the first pass finds nothing. Account IDs outside those two values are never handled correctly, so records for `0123` and `0124` are never found.

This lab is standalone and can be completed without doing any other lab first.

## Lab Outcomes

By the end of this lab you will use Bob and the ServiceNow MCP tools to:
- identify the specific program logic responsible for a file-read failure
- recommend a targeted code fix and write it to the ticket as a work note
- run the full `incident-resolution` skill and observe how it handles a code-defect ticket

---

## 3a — Suggest Probable Root Causes

### Goal

Have Bob analyze INC0010010 and identify the exact logic that causes the failure for account IDs outside the two hardcoded values.

### Bob Prompt

```text
Use the ServiceNow MCP tools to look up incident INC0010010 from the incident table. Based only on the ticket content, propose the most probable root cause of the failure.

For the root cause:
- identify which part of the program logic is likely responsible
- explain what the program does when BankAccountId is not one of the two expected values
- note what additional information (logs, trace output, or code review) would confirm the diagnosis

Display the analysis in chat. Do not write anything back to ServiceNow.
```

### Success Check

Bob's root cause points to the multi-pass file read logic: the program has hardcoded fallback account IDs and does not handle any other values, so records keyed to `0123` or `0124` are silently missed on both the first and second pass through the three bank files.

You will see an RCA like this: 

![alt text](images/2a-example.png)

---

## 3b — Recommend a Fix and Post a Work Note

### Goal

Have Bob recommend the specific change needed in `HKAP170C` and write it to INC0010010 as a work note. This is the one section in the lab series where you will use the ServiceNow MCP update tool to write back to the instance.

### Bob Prompt

```text
Use the ServiceNow MCP tools to look up incident INC0010010 from the incident table. Based on the ticket content, recommend the most targeted fix for the BankAccountId handling gap in HKAP170C.

The recommendation should:
- identify the paragraph(s) in HKAP170C that need to change
- describe the logic change needed so that account IDs beyond the two currently hardcoded values are handled
- note any related paragraphs or copybooks that may also need review

Then write the recommendation to the ticket as a work note using the ServiceNow MCP update tool. Keep the note concise and operator-friendly.
```

### Success Check

Bob recommends extending the account ID handling logic (in `S0225-EDIT-INPUT` and/or `S0250-MULTI-PASS` in `HKAP170C`) so that additional account IDs can be passed through to the file key without being overridden by the hardcoded defaults. The work note appears on INC0010010 in ServiceNow.

Approval gate for writing to ServiceNow:

![alt text](images/2b-example-bob.png)

You will see a work note like this to populate in ServiceNow: 

![alt text](images/2b-example-snow.png)

---

## 3c — Full Resolution Workflow with the Incident-Resolution Skill

### What is a Skill?

In Bob, a **skill** is a set of pre-loaded instructions stored in `.bob/<skill-name>/SKILL.md` inside your workspace. When you send a message that matches the skill's trigger description, Bob automatically loads those instructions and follows them — you do not need to specify any MCP tools yourself.

This workspace includes the `incident-resolution` skill at [`.bob/skills/incident-resolution/SKILL.md`](../.bob/skills/incident-resolution/SKILL.md). Its trigger is:

> *"Use when the user wants to resolve an incident, review similar historical incidents, get a recommended resolution, or write resolution notes back to a ServiceNow ticket."*

### How This Skill Works

The skill runs a structured workflow every time it is activated:

| Step | What happens |
|------|-------------|
| **1 — Identify** | Fetches the ticket by incident number from ServiceNow using `sn_query` |
| **2 — Build query** | Extracts keywords from the ticket and constructs a multi-clause similarity query (category, CI, assignment group, keywords); also queries for label-boosted incidents |
| **3 — Search history** | Queries ServiceNow for resolved/closed incidents from the last 2 years; also searches the **knowledge base** for pre-indexed resolved tickets; applies relevance and resolution quality gates to both result sets |
| **4 — Hard stop** | Shows similar incidents as a table and asks "Proceed?" — does not continue until you confirm |
| **5 — Retrieve history** | For each of the top 5 similar incidents, fetches work notes via `sn_query` on the `sys_journal_field` table; falls back to `close_notes` if the journal is not accessible; pulls knowledge-base evidence directly without an extra tool call |
| **5b — Classify** | Classifies the ticket as one of three types — **Working as Designed** (invalid argument → user-education note only, skips Step 6), **Code Defect** (targeted fix, no CSR), or **Enhancement / Missing Functionality** (new development required, CSR flagged at Step 9) |
| **6 — Recommend** | Synthesizes a resolution note strictly from the fetched evidence, with inline `**[↗ INCxxxxxx]**` citation badges; ends with "Please review and adjust before approving." |
| **7 — Approval** | Asks you to accept (A), edit (B), write your own (C), or cancel (D) |
| **8 — Write back** | On approval, strips citation badges and writes the note to the `close_notes` field via `sn_update` |
| **9 — CSR check** | If Enhancement: outputs **⚠ CSR Required** block naming affected components and compile order. If Code Defect: confirms no CSR, then asks "Would you like me to implement the fix now?" |
| **10 — Implement fix** | *(Code Defect only, if user said yes)* Locates the affected file(s) in the workspace, applies the minimal targeted change, and reports exactly what was changed |

### Goal

Run the full skill on INC0010010 — a code defect ticket — and observe how it differs from the ad-hoc prompts in 2a and 2b. Because this is a code defect (not an invalid-argument ticket), the skill will proceed through Step 6 and generate a code-fix recommendation from historical evidence.

### Bob Prompt

```text
Resolve incident INC0010010
```

That single phrase is enough. It matches the skill's trigger and Bob will run the full workflow automatically.

### What to Watch For

> **Steps 1–3:** Bob fetches the ticket, builds a similarity query from the account ID and file-read keywords, and searches historical incidents. Watch the tool calls — you will see it call multiple ServiceNow tools without you asking.

> **Step 4 — Hard Stop:** Bob presents a table of similar resolved incidents and asks "Proceed?" — it will not generate anything until you confirm.

> **Step 5b — Classification:** Because INC0010010 describes a program failing to read records (not a caller submitting bad input), it is classified as **Code Defect**. The invalid-argument path (Working as Designed) does not fire; the skill continues to Step 6.

> **Step 6 — Recommendation:** The recommendation block includes inline citations formatted as `**[↗ INCxxxxxx]**` after each step, and closes with "Please review and adjust before approving." Every suggestion traces back to a real resolved ticket — nothing is invented.

> **Step 7 — Approval:** Bob offers options A (accept), B (edit), C (write your own), or D (cancel). Choose any to see the approval flow.

![alt text](images/2c-example-citations.png)

> **Step 8 — Write-back:** On confirmation, Bob calls `sn_update` and writes the note to the `close_notes` field, reporting back with the ticket number and `sys_id`. Citation badges are stripped before saving.

> **Step 9 — CSR check / fix offer:** Because INC0010010 is a Code Defect, no CSR Required block appears. Instead, the skill asks: *"Would you like me to implement the fix in the codebase now?"* If you say yes, it proceeds to Step 10 — locating the affected file and applying the minimal change.

### Success Check

- Bob activates the skill without you specifying any MCP tools
- A table of similar historical incidents appears before any recommendation is generated (Step 4 hard stop)
- The recommendation includes `**[↗ INC...]**` citation badges on each step and ends with "Please review and adjust before approving."
- The A/B/C/D approval prompt appears before any write-back
- The write-back targets `close_notes` via `sn_update`; citation badges are absent from the saved note
- The skill does **not** produce a user-education note (INC0010010 is a Code Defect, not Working as Designed)
- After the write-back, the skill asks whether to implement the fix — it does **not** output a CSR Required block


You will see reference citations and Bob asking for a final input on action to be taken like this:



---

## 3d — Run the Resolution Skill on a Feature Expansion Ticket

### Goal

Run the same resolution skill on INC0010011 — the feature expansion ticket — and observe how the output differs from INC0010010. The skill will classify the ticket as **Enhancement / Missing Functionality** at Step 5b, generate a resolution note documenting the technical scope, and then output a **CSR Required** flag at Step 9. That flag is the handoff into Lab 4.

### Bob Prompt

```text
Resolve incident INC0010011
```

That single phrase is enough — the same trigger as 2c.

### What to Watch For

> **Step 5b — Classification:** INC0010011 is not an invalid argument (valid input is being supplied) and not a defect in existing behaviour (the fields were never implemented). Bob should classify it as **Enhancement / Missing Functionality** and state that before proceeding.

> **Step 6 — Recommendation:** The recommendation will reference response mapping changes across multiple components — the FOPTSTRO routine, copybooks `HKAY170O` and `HWAY170O`, and programs `HKAP170C` and `HWAP170C`. This is a multi-component, multi-copybook scope with a compile/link chain.

> **Step 9 — CSR Required flag:** Because `ticket_type = "Enhancement"`, the skill outputs the CSR Required block after writing back. It names the affected components and compile order, and directs you to check the CSR register before opening a new change request. This is the entry point for Lab 4.


### Success Check

- Bob classifies INC0010011 as **Enhancement / Missing Functionality** at Step 5b — not Code Defect, not Working as Designed
- The resolution note references changes across more than one program or copybook
- After Step 8 write-back, the **⚠ CSR Required** block appears with affected components listed
- The CSR Required block explicitly says to check the CSR register before opening a new request — that is the first action in Lab 4

![alt text](images/ticketType.png)

![alt text](images/CSRrequired.png)

---

## Wrap-Up

In this lab you diagnosed a mainframe file-read defect, recommended a targeted code change scoped to `HKAP170C`, posted a work note to the live ticket, and ran the full guided resolution workflow twice — once for a Code Defect (INC0010010) and once for an Enhancement (INC0010011). The contrast between the two runs shows the skill's Step 5b classification gate in action: INC0010010 produces a direct fix recommendation with no CSR flag, while INC0010011 produces a scope note and the ⚠ CSR Required block at Step 9. That CSR Required output is the starting point for Lab 4 — CSR Identification & Scoping picks up exactly where Step 9 leaves off.

---

**Next Lab:** [Lab 4 — Mainframe CSR Identification & Scoping](./lab-4-mainframe-csr-identification-scoping.md)
