# Lab 2 — Ticket Analysis & Classification

This lab focuses on reading incidents, classifying them by type, and identifying related tickets. Labs 2a and 2c use real incidents from the `InquirePaymentInformation_v2.getPaymentInformation` API — a CICS/COBOL mainframe service that reads payment records from bank master, interim, and purge files. Lab 2b retains INC0010012 — a Midtier UI ticket — as a domain-contrast reference. Its full triage was completed in Lab 1; here it appears solely to confirm that Bob correctly labels it Midtier while the other three are Mainframe.

Throughout this lab, **Mainframe** refers to CICS/COBOL services running on IBM Z, and **Midtier** is used as a catch-all for everything outside that stack — web UIs, portal applications, and other non-mainframe services.

The tickets you will work with are:

| Number | Short Description | Domain |
|---|---|---|
| INC0010009 | Payment ID validation rejects trailing spaces | Mainframe |
| INC0010010 | Does not read records for BankAccountId 0123 and 0124 | Mainframe |
| INC0010011 | Not returning response for Servicing Plan Code and Financial Plan Code | Mainframe |
| INC0010012 | Category filter on the Benefit Products page is missing the "Vision" option | Midtier (classification contrast — full triage in Lab 1) |

This lab is standalone and can be completed without doing any other lab first.

## Lab Outcomes

By the end of this lab you will use Bob and the ServiceNow MCP tools to:
- interpret a mainframe API incident in plain language and determine whether it is a user error or a program defect
- classify a batch of four tickets by type, priority, and domain — including one non-mainframe ticket — and observe how the domain classification differs
- identify related tickets in the same API surface and explain the relationship, cross-referencing the local knowledge base for historical context


---

## 2a — Read and Interpret an Incident

### Goal

Pull INC0010009 and explain what went wrong, whether it is a user error or a program defect, and what the caller should know.

### Bob Prompt

```text
Use the ServiceNow MCP tools to look up incident INC0010009 from the incident table. Based only on the ticket content, explain:
- what the caller did that caused the rejection
- what field rule was violated
- whether this is a user input error or a program defect, and why
- what the caller needs to do differently

Display the full ticket details in chat. Do not write anything back to ServiceNow.
```

### Success Check

Bob identifies this as a user input error — the Payment ID field must be entirely numeric and 9 characters long; a value padded with trailing spaces fails the numeric validation even though the numeric portion is valid. No code change is needed; the caller needs to submit the Payment ID as a fully numeric string (e.g. zero-padded: `000123456`) with no spaces anywhere in the field.


---

## 2b — Classify a Batch of Tickets

### Goal

Classify all four incidents by ticket type, priority, and domain, and review the results in chat. INC0010012 is included here solely as a domain-classification contrast — to confirm that Bob labels it Midtier while the other three receive Mainframe.

### Bob Prompt

```text
Use the ServiceNow MCP tools to look up incidents INC0010009, INC0010010, INC0010011, and INC0010012 from the incident table.

For each ticket, classify:
- ticket type: choose from "Working as Desired", "Code Defect", or "Enhancement"
- priority
- domain: use "Mainframe" for CICS/COBOL/IBM Z tickets and "Midtier" for everything else. Present the results as a table in chat with columns: Number, Short Description, Ticket Type, Priority, Domain. Use the knowledge base to assist classification.

Present the results as a table in chat with columns: Number, Short Description, Ticket Type, Priority, Domain. Use the knowledge base to assist classification.

Add a one-sentence explanation of your classification choice for each ticket below the table.

Do not write anything back to ServiceNow.
```

### Expected Classification

Expected output table similar to this:

- **INC0010009** — Working as Desired: the knowledge base confirms that numeric validation on the Payment ID field correctly rejects trailing spaces by design — this is documented API contract behaviour, no code change needed.
- **INC0010010** — Code Defect: the knowledge base surfaces multiple historical tickets showing a recurring pattern where BankAccountId values outside the hardcoded ranges fall through to an incorrect fallback, causing the multi-pass file read to fail.
- **INC0010011** — Enhancement: the knowledge base confirms that `ServicingPlanCode` and `FinancialPlanCode` were never part of the original API scope — their absence is an intentional scoping decision, not a regression.
- **INC0010012** — Enhancement (Midtier): the knowledge base confirms the "Vision" category was explicitly excluded from the initial portal release; this is an Angular/FastAPI web application ticket outside the CICS/COBOL mainframe stack, and adding Vision is new scope.

### Success Check

Critically, Bob assigns INC0010012 the domain **Midtier** — confirming it recognises this ticket as outside the CICS/COBOL mainframe stack. Its full triage was completed in Lab 1. The knowledge base search surfaces historical precedents for all three mainframe tickets, confirming the classification for each.

---

## 2c — Detect Related Tickets

### Goal

Scan the three tickets and identify which ones are related, explaining why and which should be treated as the primary record for tracking. Then search the local knowledge base for historically resolved tickets that share the same failure patterns — giving you a richer picture of recurrence.

### Bob Prompt

```text
Use the ServiceNow MCP tools to look up incidents INC0010009, INC0010010, and INC0010011 from the incident table.

Review the three tickets and identify any that are related. For each related set:
- list the incident numbers involved
- explain why they are related (shared API, shared program, shared data path, etc.)
- recommend which ticket should be the primary record and why

Then use the knowledge-base MCP tool. For each historical result, show the ticket number, short description, and a one-sentence summary of the close notes.

Display the full relationship summary — both the live ticket relationships and the historical context — in chat. Do not write anything back to ServiceNow.
```

### Expected Output

You should see relationship and historical context output similar to this:

![alt text](images/1c-example.png)

### Success Check

Bob identifies the live ticket relationships correctly and then calls `search_historical_tickets` twice, returning at least two historical tickets per theme. The historical results demonstrate that the patterns in INC0010009 and INC0010010 are recurring issues with known resolution paths.

> **Knowledge base note:** Results labelled "from ServiceNow" come from the live instance via the `servicenow` MCP. Results labelled "from the local knowledge base" come from `data/historical-tickets.json` via the `knowledge-base` MCP — these are pre-loaded synthesized historical tickets that simulate a resolved ticket archive.


---

## Wrap-Up

In this lab you used Bob to interpret a mainframe API incident, classify four tickets by type and domain, and surface the relationships between tickets that share the same API surface:

- **2a** — INC0010009 was correctly identified as a user input error (Working as Desired): the Payment ID numeric validation is behaving as designed, and the caller needs to submit a fully numeric value with no spaces.
- **2b** — All four tickets were classified by type, priority, and domain. Bob correctly assigned INC0010012 as **Midtier** while the three `InquirePaymentInformation_v2` tickets received **Mainframe** — with the knowledge base confirming the classification for each.
- **2c** — Bob identified the live ticket relationships and drew on the knowledge base to show that the payment ID validation and BankAccountId file-read patterns are both recurring issues with well-established resolution paths in the historical archive.

The key distinction to carry into Lab 3: INC0010009 needs no code change, INC0010010 needs a targeted defect fix, and INC0010011 is an Enhancement requiring new development before the missing response fields can be returned by the API.

---

**Next Lab:** [Lab 3 — Mainframe Resolution Assistance](./lab-3-mainframe-resolution-assistance.md)
