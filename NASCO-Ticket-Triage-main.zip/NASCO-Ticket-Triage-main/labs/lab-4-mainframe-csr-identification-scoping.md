# Lab 4 — Mainframe CSR Identification & Scoping

This lab picks up where Lab 3d left off. At the end of Lab 3d, the `incident-resolution` skill classified INC0010011 as **Enhancement / Missing Functionality** and output a ⚠ CSR Required flag naming the affected components, along with a recommended resolution note documenting the technical scope. This lab acts on those two outputs in three steps: check whether a change request already exists, estimate the full scope of work using the resolution note as input, then create a Jira story to track the delivery.

A CSR is warranted when a ticket is classified as Enhancement / Missing Functionality — meaning the system is working as implemented, but the requested capability requires new development. That is the profile of **INC0010011**: the API does not return `ServicingPlanCode` or `FinancialPlanCode` in the response even when those values are supplied as input — closing Use the ServiceNow MCP tools to look up incident INC0010011 from the incident table.

Using both the ticket content AND the recommended resolution produced for INC0010011
in Lab 3d (which identified affected components HWAP170C, HKAP170C, HKAY170O, HWAY170O
and root cause FOPTSTRO routine not outputting zero-initialised PIC 9 fields), estimate
the effort and scope of the work.

Include:
- effort estimate: Small, Medium, or Large — and the reasoning
- work category: Defect Fix, Feature Expansion, or Configuration Change
- compile and link chain: which components need to be recompiled and in what order
- test scope: what needs to be verified to confirm the fix is complete

Keep the assessment concise. Display the output in chat — do not write anything to
ServiceNow or Jira yet this gap requires changes across the WAPI response copybook (`HKAY170O`), the FGS response copybook (`HWAY170O`), and the mapping layer in `HWAP170C`.

> **Note:** This lab can also be completed standalone without doing Lab 3 first. If you skipped Lab 3, use this context as the starting point: INC0010011 was classified as Enhancement / Missing Functionality. The recommended resolution identified these affected components: HWAP170C, HKAP170C, HKAY170O, HWAY170O — with compile order: copybooks first, then HKAP170C, then HWAP170C. Root cause: FOPTSTRO routine does not output zero-initialised PIC 9 fields.

## Lab Outcomes

By the end of this lab you will use Bob and the ServiceNow and JIRA MCP tools to:
- check the local CSR register for an existing change request covering INC0010011's scope, and produce an attachment recommendation when a duplicate is found
- estimate effort, compile order, and test scope grounded in the recommended resolution from Lab 3d
- create a Jira story in the Nasco Project (`SAM1`) that captures the full scope, linked to the existing CSR and the originating incident

---

## 4a — CSR Duplicate Check

### Goal

The ⚠ CSR Required flag from Lab 3d names the affected components but does not check whether a change request already exists. Before any new CSR or Jira ticket is opened, check the local CSR register for overlapping scope. The expected outcome is a **duplicate found** — CSR-0042 already covers INC0010011 — and an attachment recommendation instead of a new draft.

> **Instructor note:** This step models real-world change governance: before opening a new change request, practitioners should verify that no existing CSR already covers the same scope. When a duplicate is found, the correct action is to link the new incident to the existing CSR rather than creating a parallel request that fragments the work.

### Bob Prompt

```text
The incident-resolution skill has flagged INC0010011 as requiring a CSR.
Affected components from the flag: HWAP170C, HKAP170C, HKAY170O, HWAY170O.

Before opening a new change request, use the knowledge-base MCP tool search_csrs
to check whether any existing CSRs already cover this scope. Search using:
"ServicingPlanCode FinancialPlanCode FOPTSTRO response mapping HWAP170C HKAY170O HWAY170O".

If a matching CSR is found:
- retrieve its full details using get_csr_by_id
- compare its scope against INC0010011
- if the scope fully covers INC0010011, do NOT draft a new CSR — instead write a short
  attachment recommendation note (3-5 sentences) explaining which CSR to link to, why the
  scope already covers this incident, and what action the change manager should take

If no matching CSR is found, confirm that a new CSR should be drafted.

Do not write anything to ServiceNow or Jira yet.
```

### Expected Output

Bob calls `search_csrs`, finds CSR-0042 as the top result, then calls `get_csr_by_id("CSR-0042")` to read its full scope. After comparing, Bob determines the scope fully covers INC0010011 and outputs an attachment recommendation note similar to:

---

> **Duplicate CSR detected — no new draft required.**
>
> CSR-0042 ("Enhance response mapping for all optional plan codes — ServicingPlanCode and FinancialPlanCode") already covers the complete scope of INC0010011. The existing CSR addresses the same root cause (FOPTSTRO routine failing to output zero-initialised PIC 9 fields) and targets the same components: HWAP170C, HKAP170C, HKAY170O, and HWAY170O.
>
> **Recommended action:** Attach INC0010011 to CSR-0042 as a related incident. No new Change Service Request should be opened. Notify the CSR-0042 assignee that this incident provides additional evidence of business impact.

---

### Success Check

Bob calls `search_csrs` and `get_csr_by_id` — both tool calls are visible in chat. Bob does **not** draft a new CSR. It produces the attachment recommendation citing CSR-0042 by ID and title with the scope overlap explained.

![alt text](images/checkDuplicate.png)

---

## 4b — Estimate Effort and Scope

### Goal

With CSR-0042 confirmed as the existing change request, estimate the full effort and scope of the work. The estimate must be grounded in **both** the recommended resolution note produced in Lab 3d (which identified the fix pattern and affected components from historical evidence) and the raw ticket content from ServiceNow. This produces the content that will populate the Jira story in 4c.

### Bob Prompt

```text
Use the ServiceNow & knowledge base MCP tools to look up incident INC0010011 from the incident table.

Using both the ticket content AND the recommended resolution produced for INC0010011
in Lab 3d (which identified affected components HWAP170C, HKAP170C, HKAY170O, HWAY170O
and root cause FOPTSTRO routine not outputting zero-initialised PIC 9 fields), estimate
the effort and scope of the work.

Include:
- effort estimate: Small, Medium, or Large — and the reasoning
- work category: Defect Fix, Feature Expansion, or Configuration Change
- compile and link chain: which components need to be recompiled and in what order
- test scope: what needs to be verified to confirm the fix is complete

Keep the assessment concise. Display the output in chat — do not write anything to
ServiceNow or Jira yet.
```

### Success Check

The effort estimate is Medium or Large — justified by two programs, two copybooks, a compile/link chain, and response field verification, all derived from the resolution note evidence. The work category is Feature Expansion. The compile order correctly identifies copybook changes first (`HKAY170O`, `HWAY170O`), then `HKAP170C`, then `HWAP170C`. The test scope includes verifying that `ServicingPlanCode` and `FinancialPlanCode` are populated in the response when valid input values are supplied.


---

## 4c — Create the Jira Story

### Goal

Use the scope from 4b and the CSR-0042 reference from 4a to create a Jira story in the Nasco Project (`SAM1`) via the JIRA MCP. This is the artifact that tracks the actual delivery work and closes the loop from the original incident through the recommended resolution and CSR confirmation.

### Bob Prompt

```text
Using the effort and scope assessment from the previous step and the CSR details
from the duplicate check, create a Jira task in the SAM1 project.

Use the create-nasco-jira-task skill to structure and create the task — derive all
field values from what you already know and skip any field that cannot be determined.

Display the created task with its full description in chat.
```

### Success Check

Bob calls the JIRA MCP `jira_create_issue` tool and returns a new issue key in the `SAM1` project. The story summary references ServicingPlanCode / FinancialPlanCode. The description includes the affected components, compile order, test scope, root cause from the resolution note, and references both INC0010011 and CSR-0042.

![alt text](images/displayJIRAticket.png)
![alt text](images/JIRAticket.png)

### Why a Skill Makes This Better

The `create-nasco-jira-task` skill ([`.bob/skills/create-nasco-jira-task/SKILL.md`](../.bob/skills/create-nasco-jira-task/SKILL.md)) gives Bob three things a plain prompt cannot:

- **Consistent structure.** Every task produced by this flow has the same sections — Business Request, CSR Number, Compile Order, Test Scope, Effort Estimate, Originating Incident — regardless of who runs it.
- **Context carry-forward.** The skill instructs Bob to derive all values from what is already in the conversation. No re-pasting of ticket details or templates between steps.
- **Single edit point.** Add a Risk Assessment block, enforce a compliance label, or rename a section once in the skill file and every future task picks it up automatically.

![alt text](images/jira-Skill.png)

---

## Wrap-Up

In this lab you acted on the two outputs from Lab 3d — the ⚠ CSR Required flag and the recommended resolution note. Rather than immediately opening a new change request, Bob first checked the CSR register and found that CSR-0042 already covers the full scope of INC0010011, preventing duplicate work. The effort estimate was grounded in the resolution note's historical evidence, not re-derived from the raw ticket. The final step created a tracked Jira story in the Nasco Project linking the incident, the existing CSR, and the delivery work together. The complete flow across Labs 1–4: INC0010009 needs no code change, INC0010010 needs a targeted defect fix written back as a work note, and INC0010011 belongs to a planned feature expansion already tracked under CSR-0042 and now represented as Jira story `SAM1-xxx`.
