# ServiceNow Ticket Triage Labs

This repository contains five short, standalone labs for practicing AI-assisted ServiceNow ticket triage with Bob, the ServiceNow MCP, the Knowledge Base MCP, and the Jira MCP. The lab series spans two application domains: a Midtier Angular + FastAPI app (AI Benefits Portal) for Lab 1, and a mainframe CICS/COBOL service (`InquirePaymentInformation_v2.getPaymentInformation`) for Labs 2–4.

Across both domains the labs cover the three most common ticket outcomes: **Working as Desired** (invalid argument — user education note, no code change), **Code Defect** (targeted fix written back to the ticket and optionally applied in the codebase), and **Enhancement Request** (new scope flagged as CSR Required and tracked as a Jira story).

## Prerequisites

- Install and sign in to Bob by following the official guide: <https://bob.ibm.com/docs/ide/getting-started/install>
- Complete [Lab 0 — Environment Setup](labs/lab-0-setup.md) to verify all MCP connections before starting any other lab

## Lab Overview

- [**Lab 0 — Environment Setup**](labs/lab-0-setup.md): Verify that all three MCPs (ServiceNow, Knowledge Base, Jira) are connected and returning results; optionally start the AI Benefits Portal for Lab 1.
- [**Lab 1 — Midtier Ticket Triage**](labs/lab-1-midtier-fe-triage.md): Classify three AI Benefits Portal incidents (INC0010012, INC0010014, INC0010015), then run the `incident-resolution` skill on INC0010012 (Enhancement — writes resolution note + CSR Required flag + Jira story) and INC0010015 (Code Defect — writes resolution note + applies codebase fix + runs tests).
- [**Lab 2 — Ticket Analysis & Classification**](labs/lab-2-ticket-analysis-classification.md): Interpret INC0010009 as a user input error; classify INC0010009, INC0010010, INC0010011, and INC0010012 by type, priority, and domain using the Knowledge Base; surface related tickets and historical context.
- [**Lab 3 — Mainframe Resolution Assistance**](labs/lab-3-mainframe-resolution-assistance.md): Propose the root cause for INC0010010, post a targeted fix recommendation as a work note, then run the `incident-resolution` skill on INC0010010 (Code Defect path) and INC0010011 (Enhancement path — produces ⚠ CSR Required flag).
- [**Lab 4 — Mainframe CSR Identification & Scoping**](labs/lab-4-mainframe-csr-identification-scoping.md): Check the CSR register for a duplicate before opening a new request (CSR-0042 found), estimate effort and compile order for INC0010011, then create a tracked Jira story in SAM1 using the `create-nasco-jira-task` skill.

## Recommended Order

1. [Lab 0 — Environment Setup](labs/lab-0-setup.md)
2. [Lab 1 — Midtier Ticket Triage](labs/lab-1-midtier-fe-triage.md)
3. [Lab 2 — Ticket Analysis & Classification](labs/lab-2-ticket-analysis-classification.md)
4. [Lab 3 — Mainframe Resolution Assistance](labs/lab-3-mainframe-resolution-assistance.md)
5. [Lab 4 — Mainframe CSR Identification & Scoping](labs/lab-4-mainframe-csr-identification-scoping.md)

## Tickets Used in These Labs

### Midtier (AI Benefits Portal) — Lab 1

| Number | Short Description | Type |
|---|---|---|
| INC0010012 | Category filter on the Benefit Products page is missing the "Vision" option | Enhancement Request |
| INC0010014 | Products display a status of "Configure", which should instead read "In Progress" | Working as Desired |
| INC0010015 | User "Smith" (read-only role) sees the "Edit" button, which should be hidden | Code Defect |

### Mainframe (InquirePaymentInformation_v2) — Labs 2–4

| Number | Short Description | Type |
|---|---|---|
| INC0010009 | Payment ID validation rejects trailing spaces | Working as Desired |
| INC0010010 | Does not read records for BankAccountId 0123 and 0124 | Code Defect |
| INC0010011 | Not returning response for Servicing Plan Code and Financial Plan Code | Enhancement Request |

> INC0010012 also appears in Lab 2 as a domain-classification contrast only — its full triage is in Lab 1.

## AI Benefits Portal

The `aibenefits-fe-bobathon/` directory contains an Angular 18 frontend backed by a Python FastAPI server. When running locally, the backend listens on `http://localhost:8080` and the frontend on `http://localhost:4300`. Two demo accounts are provided:

- `jack@aibenefits.com` — Benefit Developer role (full access)
- `smith@aibenefits.com` — Product Reviewer role (read-only)

See [`aibenefits-fe-bobathon/docs/QUICK-START.md`](aibenefits-fe-bobathon/docs/QUICK-START.md) for start instructions.

## Bob Skills

A skill is a set of instructions Bob automatically activates when your message matches its trigger. Skills matter because they turn a multi-step, error-prone manual workflow into a single repeatable prompt — no tool wiring required, no steps skipped, consistent output every time.

This workspace includes two pre-installed skills:

**`incident-resolution`** (`.bob/skills/incident-resolution/SKILL.md`) — Runs the full resolution workflow: similarity search across historical incidents, ticket classification (Working as Desired / Code Defect / Enhancement), citation-backed recommendation, approval checkpoint, ServiceNow write-back, and CSR flag or codebase fix offer depending on ticket type. A single phrase like "Resolve incident INC0010010" is all that is needed to trigger it. Used in Labs 1b, 1d, 3c, and 3d.

**`create-nasco-jira-task`** (`.bob/skills/create-nasco-jira-task/SKILL.md`) — Structures a Jira task using the NASCO Change Control template, deriving all field values (affected components, compile order, effort estimate, originating incident) from context already in the conversation. Ensures every story created in SAM1 follows the same format without re-pasting details. Used in Labs 1c and 4c.
