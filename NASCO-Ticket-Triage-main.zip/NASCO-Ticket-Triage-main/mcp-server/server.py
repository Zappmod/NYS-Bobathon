# /// script
# requires-python = ">=3.11"
# dependencies = ["mcp>=2.0.0"]
# ///
"""
knowledge-base MCP server — historical resolved tickets and CSR register
for the BCBS-MI ticket triage labs.

Run with:  uv run mcp-server/server.py
Zero setup required — uv handles Python and dependencies automatically.
"""

import json
import re
from pathlib import Path

from mcp.server.mcpserver import MCPServer

# ---------------------------------------------------------------------------
# Data loading — always relative to this file, regardless of cwd
# ---------------------------------------------------------------------------

DATA_DIR = Path(__file__).parent.parent / "data"


def load_tickets() -> list[dict]:
    return json.loads((DATA_DIR / "historical-tickets.json").read_text())


def load_csrs() -> list[dict]:
    return json.loads((DATA_DIR / "csrs.json").read_text())


# ---------------------------------------------------------------------------
# Scoring helpers
# ---------------------------------------------------------------------------

def tokenize(query: str) -> list[str]:
    return [t for t in re.split(r"[\s,;]+", query.lower()) if len(t) > 2]


def score_record(record: dict, tokens: list[str], fields: list[str]) -> int:
    score = 0
    for field in fields:
        raw = record.get(field, "")
        value = " ".join(raw).lower() if isinstance(raw, list) else str(raw).lower()
        score += sum(1 for t in tokens if t in value)
    return score


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

TICKET_FIELDS = [
    "short_description", "description", "close_notes",
    "work_notes", "category", "subcategory", "cmdb_ci",
]
CSR_FIELDS = ["title", "description", "scope", "labels", "assignee"]


def _search_historical_tickets(query: str, limit: int = 5) -> dict:
    tickets = load_tickets()
    tokens = tokenize(query)
    scored = sorted(
        [{"ticket": t, "score": score_record(t, tokens, TICKET_FIELDS)} for t in tickets],
        key=lambda x: x["score"],
        reverse=True,
    )
    scored = [x for x in scored if x["score"] > 0][: min(limit, 15)]
    if not scored:
        return {"results": [], "message": "No matching historical tickets found."}
    return {
        "results": [
            {
                "number": x["ticket"]["number"],
                "short_description": x["ticket"]["short_description"],
                "category": x["ticket"]["category"],
                "subcategory": x["ticket"]["subcategory"],
                "state": x["ticket"]["state"],
                "resolved_at": x["ticket"]["resolved_at"],
                "close_notes": (
                    x["ticket"]["close_notes"][:300] + "\u2026"
                    if len(x["ticket"]["close_notes"]) > 300
                    else x["ticket"]["close_notes"]
                ),
                "relevance_score": x["score"],
            }
            for x in scored
        ]
    }


def _search_csrs(query: str, limit: int = 5) -> dict:
    csrs = load_csrs()
    tokens = tokenize(query)

    def csr_score(csr: dict) -> int:
        s = score_record(csr, tokens, CSR_FIELDS)
        components = " ".join(csr.get("affected_components", [])).lower()
        s += sum(1 for t in tokens if t in components)
        return s

    scored = sorted(
        [{"csr": c, "score": csr_score(c)} for c in csrs],
        key=lambda x: x["score"],
        reverse=True,
    )
    scored = [x for x in scored if x["score"] > 0][:limit]
    if not scored:
        return {"results": [], "message": "No matching CSRs found."}
    return {
        "results": [
            {
                "csr_id": x["csr"]["csr_id"],
                "title": x["csr"]["title"],
                "status": x["csr"]["status"],
                "priority": x["csr"]["priority"],
                "scope": x["csr"]["scope"],
                "affected_components": x["csr"]["affected_components"],
                "created_from_incident": x["csr"]["created_from_incident"],
                "relevance_score": x["score"],
            }
            for x in scored
        ]
    }


def _get_csr_by_id(csr_id: str) -> dict:
    csrs = load_csrs()
    match = next((c for c in csrs if c["csr_id"].lower() == csr_id.lower()), None)
    if not match:
        return {"error": f"CSR '{csr_id}' not found in the local knowledge base."}
    return {"csr": match}


# ---------------------------------------------------------------------------
# MCP server
# ---------------------------------------------------------------------------

server = MCPServer("knowledge-base")


@server.tool(
    description=(
        "Search the local knowledge base of historically resolved ServiceNow tickets "
        "for Mainframe (InquirePaymentInformation_v2 API) and Midtier (AI Benefits Portal) applications. "
        "Use this to find prior incidents similar to the one being triaged — covering "
        "invalid argument, code defect, permissions/auth, configuration, and feature expansion patterns. "
        "Returns up to `limit` tickets ranked by keyword relevance."
    )
)
def search_historical_tickets(
    query: str,
    limit: int = 5,
) -> str:
    """
    query: Free-text search query. Use keywords from the incident short_description or description (e.g. 'Payment ID trailing space IS NUMERIC', 'canEdit permission modal', 'category.properties Vision').
    limit: Maximum number of results to return (default: 5, max: 15).
    """
    return json.dumps(_search_historical_tickets(query, limit), indent=2)


@server.tool(
    description=(
        "Search the local CSR (Change Service Request) and story register for existing change "
        "requests that may overlap with the scope of a new ticket or candidate change. "
        "Covers Mainframe API services and Midtier (AI Benefits Portal) enhancements. "
        "Use this BEFORE drafting a new CSR/story to detect duplicates. "
        "Returns up to `limit` CSRs ranked by keyword relevance."
    )
)
def search_csrs(
    query: str,
    limit: int = 5,
) -> str:
    """
    query: Free-text search query using component names, field names, or scope keywords (e.g. 'ServicingPlanCode FinancialPlanCode response mapping', 'category.properties Vision filter', 'OAuth2 role-based permissions').
    limit: Maximum number of results to return (default: 5).
    """
    return json.dumps(_search_csrs(query, limit), indent=2)


@server.tool(
    description=(
        "Retrieve the full details of a single CSR from the local knowledge base "
        "by its ID (e.g. 'CSR-0042'). "
        "Use this after search_csrs identifies a candidate to read its full scope, "
        "description, and affected components."
    )
)
def get_csr_by_id(csr_id: str) -> str:
    """
    csr_id: The CSR ID to look up (e.g. 'CSR-0042').
    """
    return json.dumps(_get_csr_by_id(csr_id), indent=2)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    server.run("stdio")
