#!/usr/bin/env node
"use strict";

/**
 * knowledge-base MCP server — zero external dependencies (Node.js built-ins only).
 *
 * Supports two transports, selected by the MCP_TRANSPORT environment variable:
 *   MCP_TRANSPORT=stdio  (default) — Content-Length framed stdin/stdout
 *   MCP_TRANSPORT=sse               — HTTP/SSE on PORT (default 8080)
 *
 * SSE transport endpoints:
 *   GET  /sse            — opens SSE stream, sends an "endpoint" event
 *   POST /message        — receives JSON-RPC, replies via the caller's SSE stream
 *   GET  /health         — returns 200 OK (Code Engine health check)
 *
 * Tools exposed:
 *   - search_historical_tickets(query, limit?)
 *   - search_csrs(query, limit?)
 *   - get_csr_by_id(csr_id)
 */

const path = require("path");
const fs = require("fs");
const http = require("http");
const crypto = require("crypto");

// ---------------------------------------------------------------------------
// Data loading (relative to this file's directory — works from any cwd)
// ---------------------------------------------------------------------------

const DATA_DIR = path.join(__dirname, "..", "data");

function loadTickets() {
  return JSON.parse(fs.readFileSync(path.join(DATA_DIR, "historical-tickets.json"), "utf8"));
}

function loadCsrs() {
  return JSON.parse(fs.readFileSync(path.join(DATA_DIR, "csrs.json"), "utf8"));
}

// ---------------------------------------------------------------------------
// Scoring helpers
// ---------------------------------------------------------------------------

function tokenize(query) {
  return query
    .toLowerCase()
    .split(/[\s,;]+/)
    .filter((t) => t.length > 2);
}

function scoreRecord(record, tokens, fields) {
  let score = 0;
  for (const field of fields) {
    const raw = record[field];
    const value = Array.isArray(raw)
      ? raw.join(" ").toLowerCase()
      : (raw || "").toLowerCase();
    for (const token of tokens) {
      if (value.includes(token)) score++;
    }
  }
  return score;
}

// ---------------------------------------------------------------------------
// Tool implementations
// ---------------------------------------------------------------------------

function searchHistoricalTickets(query, limit) {
  const tickets = loadTickets();
  const tokens = tokenize(query);
  const FIELDS = [
    "short_description", "description", "close_notes",
    "work_notes", "category", "subcategory", "cmdb_ci",
  ];
  const scored = tickets
    .map((t) => ({ t, score: scoreRecord(t, tokens, FIELDS) }))
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit || 5);

  if (!scored.length) return { results: [], message: "No matching historical tickets found." };

  return {
    results: scored.map(({ t, score }) => ({
      number: t.number,
      short_description: t.short_description,
      category: t.category,
      subcategory: t.subcategory,
      state: t.state,
      resolved_at: t.resolved_at,
      close_notes: t.close_notes.length > 300 ? t.close_notes.slice(0, 300) + "\u2026" : t.close_notes,
      relevance_score: score,
    })),
  };
}

function searchCsrs(query, limit) {
  const csrs = loadCsrs();
  const tokens = tokenize(query);
  const FIELDS = ["title", "description", "scope", "labels", "assignee"];
  const scored = csrs.map((csr) => {
    let score = scoreRecord(csr, tokens, FIELDS);
    const components = (csr.affected_components || []).join(" ").toLowerCase();
    for (const token of tokens) {
      if (components.includes(token)) score++;
    }
    return { csr, score };
  })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit || 5);

  if (!scored.length) return { results: [], message: "No matching CSRs found." };

  return {
    results: scored.map(({ csr, score }) => ({
      csr_id: csr.csr_id,
      title: csr.title,
      status: csr.status,
      priority: csr.priority,
      scope: csr.scope,
      affected_components: csr.affected_components,
      created_from_incident: csr.created_from_incident,
      relevance_score: score,
    })),
  };
}

function getCsrById(csr_id) {
  const csrs = loadCsrs();
  const csr = csrs.find((c) => c.csr_id.toLowerCase() === csr_id.toLowerCase());
  if (!csr) return { error: `CSR '${csr_id}' not found in the local knowledge base.` };
  return { csr };
}

// ---------------------------------------------------------------------------
// Tool registry
// ---------------------------------------------------------------------------

const TOOLS = [
  {
    name: "search_historical_tickets",
    description:
      "Search the local knowledge base of historically resolved ServiceNow tickets for Mainframe (InquirePaymentInformation_v2 API) and Midtier (AI Benefits Portal) applications. " +
      "Use this to find prior incidents similar to the one being triaged — covering invalid argument, code defect, permissions/auth, configuration, and feature expansion patterns. " +
      "Returns up to `limit` tickets ranked by keyword relevance.",
    inputSchema: {
      type: "object",
      properties: {
        query: {
          type: "string",
          description:
            "Free-text search query. Use keywords from the incident short_description or description " +
            "(e.g. 'Payment ID trailing space IS NUMERIC', 'canEdit permission modal', 'category.properties Vision').",
        },
        limit: {
          type: "number",
          description: "Maximum number of results to return (default: 5, max: 15).",
        },
      },
      required: ["query"],
    },
  },
  {
    name: "search_csrs",
    description:
      "Search the local CSR (Change Service Request) and story register for existing change requests that may overlap with the scope of a new ticket or candidate change. " +
      "Covers Mainframe API services and Midtier (AI Benefits Portal) enhancements. Use this BEFORE drafting a new CSR/story to detect duplicates. " +
      "Returns up to `limit` CSRs ranked by keyword relevance.",
    inputSchema: {
      type: "object",
      properties: {
        query: {
          type: "string",
          description:
            "Free-text search query using component names, field names, or scope keywords " +
            "(e.g. 'ServicingPlanCode FinancialPlanCode response mapping', 'category.properties Vision filter', 'OAuth2 role-based permissions').",
        },
        limit: {
          type: "number",
          description: "Maximum number of results to return (default: 5).",
        },
      },
      required: ["query"],
    },
  },
  {
    name: "get_csr_by_id",
    description:
      "Retrieve the full details of a single CSR from the local knowledge base by its ID (e.g. 'CSR-0042'). " +
      "Use this after search_csrs identifies a candidate to read its full scope, description, and affected components.",
    inputSchema: {
      type: "object",
      properties: {
        csr_id: {
          type: "string",
          description: "The CSR ID to look up (e.g. 'CSR-0042').",
        },
      },
      required: ["csr_id"],
    },
  },
];

// ---------------------------------------------------------------------------
// MCP request handler (transport-agnostic)
// ---------------------------------------------------------------------------

function handleRequest(req) {
  const { id, method, params } = req;

  if (method === "initialize") {
    return {
      jsonrpc: "2.0", id,
      result: {
        protocolVersion: "2024-11-05",
        capabilities: { tools: {} },
        serverInfo: { name: "knowledge-base", version: "1.0.0" },
      },
    };
  }

  if (method === "notifications/initialized" || method === "initialized") {
    return null;
  }

  if (method === "tools/list") {
    return { jsonrpc: "2.0", id, result: { tools: TOOLS } };
  }

  if (method === "tools/call") {
    const name = params && params.name;
    const args = (params && params.arguments) || {};
    try {
      let result;
      if (name === "search_historical_tickets") {
        if (typeof args.query !== "string") throw new Error("Missing required argument: query");
        result = searchHistoricalTickets(args.query, args.limit);
      } else if (name === "search_csrs") {
        if (typeof args.query !== "string") throw new Error("Missing required argument: query");
        result = searchCsrs(args.query, args.limit);
      } else if (name === "get_csr_by_id") {
        if (typeof args.csr_id !== "string") throw new Error("Missing required argument: csr_id");
        result = getCsrById(args.csr_id);
      } else {
        throw new Error(`Unknown tool: ${name}`);
      }
      return {
        jsonrpc: "2.0", id,
        result: { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] },
      };
    } catch (err) {
      return {
        jsonrpc: "2.0", id,
        result: {
          content: [{ type: "text", text: `Error: ${err.message}` }],
          isError: true,
        },
      };
    }
  }

  if (method === "ping") {
    return { jsonrpc: "2.0", id, result: {} };
  }

  if (id !== undefined && id !== null) {
    return { jsonrpc: "2.0", id, error: { code: -32601, message: `Method not found: ${method}` } };
  }

  return null;
}

// ---------------------------------------------------------------------------
// Transport: stdio
// ---------------------------------------------------------------------------

function runStdio() {
  function send(obj) {
    const body = JSON.stringify(obj);
    const header = `Content-Length: ${Buffer.byteLength(body, "utf8")}\r\n\r\n`;
    process.stdout.write(header + body);
  }

  let buf = Buffer.alloc(0);

  process.stdin.on("data", (chunk) => {
    buf = Buffer.concat([buf, chunk]);

    while (true) {
      const sep = buf.indexOf("\r\n\r\n");
      if (sep === -1) break;

      const header = buf.slice(0, sep).toString("utf8");
      const match = header.match(/Content-Length:\s*(\d+)/i);
      if (!match) {
        buf = buf.slice(sep + 4);
        break;
      }

      const contentLength = parseInt(match[1], 10);
      const bodyStart = sep + 4;
      const bodyEnd = bodyStart + contentLength;

      if (buf.length < bodyEnd) break;

      const body = buf.slice(bodyStart, bodyEnd).toString("utf8");
      buf = buf.slice(bodyEnd);

      try {
        const req = JSON.parse(body);
        const response = handleRequest(req);
        if (response !== null) send(response);
      } catch (e) {
        send({ jsonrpc: "2.0", id: null, error: { code: -32700, message: "Parse error" } });
      }
    }
  });

  process.stdin.on("end", () => process.exit(0));
  console.error("knowledge-base MCP server running on stdio");
}

// ---------------------------------------------------------------------------
// Transport: SSE (HTTP)
// ---------------------------------------------------------------------------

function runSSE() {
  const PORT = parseInt(process.env.PORT || "8080", 10);

  // Derive the public base URL for the endpoint event.
  // Code Engine sets CE_APP and CE_SUBDOMAIN and CE_DOMAIN; fall back to
  // the Host header at request time when those aren't present.
  const CE_SUBDOMAIN = process.env.CE_SUBDOMAIN;
  const CE_DOMAIN = process.env.CE_DOMAIN;
  const CE_APP = process.env.CE_APP;
  const STATIC_BASE = CE_APP && CE_SUBDOMAIN && CE_DOMAIN
    ? `https://${CE_APP}.${CE_SUBDOMAIN}.${CE_DOMAIN}`
    : null;

  // sessionId -> SSE response object
  const sessions = new Map();

  function sendSSE(res, event, data) {
    // Send strings (URLs) as bare values; everything else as JSON
    const payload = typeof data === "string" ? data : JSON.stringify(data);
    res.write(`event: ${event}\ndata: ${payload}\n\n`);
  }

  const server = http.createServer((req, res) => {
    // Health check for Code Engine
    if (req.method === "GET" && req.url === "/health") {
      res.writeHead(200, { "Content-Type": "text/plain" });
      res.end("ok");
      return;
    }

    // SSE stream — client connects here first
    if (req.method === "GET" && req.url === "/sse") {
      const sessionId = crypto.randomUUID();

      res.writeHead(200, {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "Access-Control-Allow-Origin": "*",
      });

      sessions.set(sessionId, res);

      // Tell the client where to POST messages — absolute URL required by Bob
      const base = STATIC_BASE || `https://${req.headers.host}`;
      sendSSE(res, "endpoint", `${base}/message?sessionId=${sessionId}`);

      req.on("close", () => sessions.delete(sessionId));
      return;
    }

    // Message endpoint — client POSTs JSON-RPC here
    if (req.method === "POST" && req.url && req.url.startsWith("/message")) {
      const url = new URL(req.url, `http://localhost:${PORT}`);
      const sessionId = url.searchParams.get("sessionId");
      const sseRes = sessionId && sessions.get(sessionId);

      if (!sseRes) {
        res.writeHead(400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "Unknown or expired sessionId" }));
        return;
      }

      let body = "";
      req.on("data", (chunk) => (body += chunk));
      req.on("end", () => {
        // Acknowledge the POST immediately
        res.writeHead(202, {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        });
        res.end("{}");

        try {
          const rpcReq = JSON.parse(body);
          const response = handleRequest(rpcReq);
          if (response !== null) {
            sendSSE(sseRes, "message", response);
          }
        } catch (e) {
          sendSSE(sseRes, "message", {
            jsonrpc: "2.0", id: null,
            error: { code: -32700, message: "Parse error" },
          });
        }
      });
      return;
    }

    // CORS preflight
    if (req.method === "OPTIONS") {
      res.writeHead(204, {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      });
      res.end();
      return;
    }

    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("Not found");
  });

  server.listen(PORT, () => {
    console.error(`knowledge-base MCP server running on SSE (port ${PORT})`);
  });
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

const transport = (process.env.MCP_TRANSPORT || "stdio").toLowerCase();
if (transport === "sse") {
  runSSE();
} else {
  runStdio();
}
