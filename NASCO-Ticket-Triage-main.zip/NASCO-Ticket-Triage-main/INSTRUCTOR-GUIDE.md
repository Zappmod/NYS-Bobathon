# Instructor Guide — ServiceNow Ticket Triage Lab Series

This guide gives a new instructor a concise picture of what the lab series covers, how it is structured, what each lab does, and where the common friction points are. Read this before delivering the labs for the first time.

---

## What This Lab Series Is

Five short, standalone labs that teach AI-assisted ServiceNow ticket triage using **Bob** and three pre-configured MCP servers (ServiceNow, Knowledge Base, Jira). Learners practice the three real-world ticket outcomes that cover the vast majority of support work:

| Outcome | Meaning | Action |
|---|---|---|
| **Working as Desired** | System behaves as specified; caller submitted bad input | Write a user-education note, no code change |
| **Code Defect** | Program bug; incorrect output for valid input | Write a targeted fix note; optionally apply the code change |
| **Enhancement Request** | Feature was never built; new development required | Flag as CSR Required; create a Jira story |

The series spans two application domains:
- **Midtier** — an Angular 18 + FastAPI web app called **AI Benefits Portal** (Lab 1)
- **Mainframe** — a CICS/COBOL service called `InquirePaymentInformation_v2.getPaymentInformation` (Labs 2–4)

---

## Repository Layout

```
README.md                          ← learner-facing landing page and lab overview
labs/
  lab-0-setup.md                   ← MCP connection verification (5 min)
  lab-1-midtier-fe-triage.md       ← Angular/FastAPI incident triage
  lab-2-ticket-analysis-classification.md  ← Mainframe batch classification
  lab-3-mainframe-resolution-assistance.md ← Mainframe root cause + fix
  lab-4-mainframe-csr-identification-scoping.md ← CSR check + Jira story
  images/                          ← screenshots referenced in lab instructions
aibenefits-fe-bobathon/            ← the local Angular app used in Lab 1
  docs/QUICK-START.md              ← how to start the app (backend + frontend)
data/
  historical-tickets.json          ← pre-loaded KB of resolved tickets (read by KB MCP)
  csrs.json                        ← CSR register (read by KB MCP)
  servicenow-incident-archive.json ← archived lab tickets for reference
.bob/
  mcp.json                         ← pre-configured MCP connections (committed)
  skills/incident-resolution/      ← full resolution workflow skill
  skills/create-nasco-jira-task/   ← NASCO Change Control Jira task skill
```

---

## The Two Skills

Skills are the main mechanic learners interact with in Labs 1, 3, and 4. Understanding them is critical to facilitating those sections confidently.

### `incident-resolution`
Triggered by any message matching *"resolve an incident"* or similar. Runs a 10-step structured workflow:
1. Fetches the ticket from ServiceNow
2. Builds a similarity query from keywords in the ticket
3. Searches both the live ServiceNow instance and the local knowledge base (`data/historical-tickets.json`) for resolved precedents
4. **Hard stop** — shows similar tickets as a table and asks "Proceed?" (does not continue until confirmed)
5. Classifies the ticket as Working as Desired / Code Defect / Enhancement
6. Synthesizes a citation-backed resolution note from the historical evidence
7. **Approval gate** — offers Accept / Edit / Write your own / Cancel before writing anything
8. Writes the resolution note to `close_notes` via `sn_update`
9. If Enhancement: outputs ⚠ CSR Required block. If Code Defect: asks "Implement the fix now?"
10. If yes to fix: locates the file, applies the minimal change, runs tests

**Key teaching point:** The same three-word prompt (`Resolve incident INCxxxxxxx`) produces two completely different outcomes depending on classification at Step 5. This is the payoff moment in Labs 1 and 3.

### `create-nasco-jira-task`
Triggered when a learner asks to create a Jira task for an incident or CSR. Structures the story description using the NASCO Change Control template (Business Request, CSR Number, Affected Components, Compile Order, Test Scope, Effort Estimate, Originating Incident). Derives all values from context already in the conversation — no re-pasting required.

Used in: Lab 1c (Midtier Enhancement) and Lab 4c (Mainframe Enhancement).

---

## Lab-by-Lab Summary

### Lab 0 — Environment Setup (~5 min)
Verify all three MCP servers are connected and returning results. Three test prompts, one per MCP. If any shows red in the MCP panel, click **Reload MCPs**. Optionally start the AI Benefits Portal for Lab 1.

**Common issue:** Learners skip Lab 0 and hit auth errors in Lab 1. Make sure everyone confirms green MCP status first.

---

### Lab 1 — Midtier Ticket Triage
**Tickets:** INC0010012 (Vision category filter), INC0010014 (Configure status label), INC0010015 (Edit button visible to read-only user)

| Section | What happens |
|---|---|
| **1a** | Batch classify all three tickets — learners get the triage table and see the three outcome types side by side |
| **1b** | `incident-resolution` skill on INC0010012 → classified as Enhancement → writes resolution note → ⚠ CSR Required flag for Vision category feature |
| **1c** | `create-nasco-jira-task` skill → creates a tracked Jira story in SAM1 from the CSR Required output |
| **1d** | `incident-resolution` skill on INC0010015 → classified as Code Defect → writes resolution note → Bob offers to apply the fix, runs automated tests |

INC0010014 is only used in 1a (classified as Working as Desired, no further action). Its full resolution does not require the skill.

**Common question:** "Why doesn't INC0010014 need the skill?" — Because Working as Desired tickets need only a short user-education note. The skill is warranted when historical evidence synthesis or write-back is needed; for a confirmed non-issue a plain note is sufficient.

---

### Lab 2 — Ticket Analysis & Classification
**Tickets:** INC0010009, INC0010010, INC0010011 (all Mainframe), plus INC0010012 (Midtier — domain contrast only)

| Section | What happens |
|---|---|
| **2a** | Pull and interpret INC0010009 — learners identify it as user input error (Payment ID must be fully numeric, no spaces) |
| **2b** | Batch classify all four tickets — INC0010012 must come back as Midtier while the three payment API tickets come back as Mainframe |
| **2c** | Detect related tickets across the three Mainframe incidents, then search the knowledge base for historical precedents |

No ServiceNow write-backs in this lab. Pure read and analysis.

**Common question:** "Why is INC0010012 in Lab 2 if it was already triaged in Lab 1?" — It appears here only to contrast domain classification. Learners who do Lab 2 without Lab 1 will still classify it correctly; it just won't have resolution notes already written.

---

### Lab 3 — Mainframe Resolution Assistance
**Anchor ticket:** INC0010010 (BankAccountId 0123/0124 not found). Secondary: INC0010011 (ServicingPlanCode/FinancialPlanCode not returned).

| Section | What happens |
|---|---|
| **3a** | Analyze INC0010010 and identify the root cause in HKAP170C without writing to ServiceNow |
| **3b** | Write a fix recommendation work note to INC0010010 via `sn_update` — **only write-back in this section** |
| **3c** | Full `incident-resolution` skill run on INC0010010 (Code Defect path) — learners observe all 10 steps; skill offers to implement the fix after write-back |
| **3d** | Full `incident-resolution` skill run on INC0010011 (Enhancement path) — skill outputs ⚠ CSR Required block at Step 9, which is the entry point for Lab 4 |

**Key teaching point for 3c vs 3d:** Identical prompt, completely different output. The classification at Step 5b is the gate. Walk learners through the step-by-step table in the lab to set this expectation before they run either prompt.

---

### Lab 4 — Mainframe CSR Identification & Scoping
**Picking up from:** The ⚠ CSR Required output from Lab 3d on INC0010011.

| Section | What happens |
|---|---|
| **4a** | Search the CSR register before opening any new request — expected outcome is CSR-0042 already exists and fully covers INC0010011; Bob outputs an attachment recommendation instead of a new draft |
| **4b** | Estimate effort, work category, compile order, and test scope for INC0010011 — expected: Medium/Large effort, Feature Expansion, copybooks first then programs |
| **4c** | `create-nasco-jira-task` skill creates a tracked Jira story in SAM1 linking INC0010011, CSR-0042, and the delivery scope |

**Can be done standalone** without Lab 3 — the lab provides the required context (affected components, root cause) in a note at the top of the lab for learners who skipped Lab 3d.

**Common question:** "What is CSR-0042?" — It is a pre-seeded entry in `data/csrs.json`, which the Knowledge Base MCP reads. It represents an existing approved change request that already covers the exact scope of INC0010011. The purpose is to model the real change governance rule: always check before opening a new request.

---

## Tickets Reference

| Number | Domain | Short Description | Expected Outcome |
|---|---|---|---|
| INC0010009 | Mainframe | Payment ID rejects trailing spaces | Working as Desired |
| INC0010010 | Mainframe | BankAccountId 0123/0124 not found | Code Defect |
| INC0010011 | Mainframe | ServicingPlanCode/FinancialPlanCode not returned | Enhancement |
| INC0010012 | Midtier | Vision category filter missing | Enhancement |
| INC0010014 | Midtier | "Configure" status label should read "In Progress" | Working as Desired |
| INC0010015 | Midtier | Edit button visible to read-only user Smith | Code Defect |

All six are live in the shared ServiceNow instance (`dev420930.service-now.com`, numbers > INC0010006).

---

## Delivering the Labs

**Recommended order:** Lab 0 → Lab 1 → Lab 2 → Lab 3 → Lab 4. Labs 2–4 form a narrative arc through the same three Mainframe tickets and flow most naturally in sequence. Lab 1 is self-contained and works as an opening exercise.

**Independent delivery:** Every lab (including Lab 4, with the standalone context note) can be run without completing the others. If time is short, Labs 1 and 3 together give learners both domains and all three outcome types.

**Estimated timing:**
- Lab 0: 5 min
- Lab 1: 25–35 min
- Lab 2: 20–25 min
- Lab 3: 25–35 min
- Lab 4: 20–25 min

**Where learners get stuck:**
1. MCP not connected (Lab 0) — always verify green status before starting
2. Skill not triggering — ensure Bob is signed in and the workspace folder is open (`.bob/` must be present)
3. Step 4 hard stop not appearing — learner may have rephrased the prompt; the skill needs a message that matches its trigger description
4. `close_notes` not visible after write-back — the ServiceNow instance shows the field; instruct learners to check the ticket directly at `dev420930.service-now.com`
5. Lab 4 without Lab 3 context — the standalone note at the top of Lab 4 has the required component and root cause details; copy those into the prompt if needed
