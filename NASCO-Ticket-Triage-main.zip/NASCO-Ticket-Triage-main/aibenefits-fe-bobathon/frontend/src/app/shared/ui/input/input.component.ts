import { 
  Component, 
  input, 
  computed,
  signal,
  forwardRef,
  ChangeDetectionStrategy,
  ViewChild,
  ElementRef,
  AfterViewInit
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { 
  ControlValueAccessor, 
  NG_VALUE_ACCESSOR,
  ReactiveFormsModule,
  FormsModule
} from '@angular/forms';
import { LabelComponent } from '../label/label.component';

/**
 * Input size variants
 */
export type InputSize = 'small' | 'default';

/**
 * Reusable Input Component with Form Integration
 * 
 * A flexible input component that integrates with Angular Reactive Forms
 * through ControlValueAccessor. Supports labels, error messages, validation,
 * and various input types.
 * 
 * @example
 * ```html
 * <app-input
 *   [id]="'email'"
 *   [label]="'Email Address'"
 *   [type]="'email'"
 *   [required]="true"
 *   [placeholder]="'Enter your email'"
 *   formControlName="email"
 * ></app-input>
 * ```
 */
@Component({
  selector: 'app-input',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, LabelComponent],
  templateUrl: './input.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => InputComponent),
      multi: true
    }
  ]
})
export class InputComponent implements ControlValueAccessor, AfterViewInit {
  @ViewChild('inputElement') inputElement!: ElementRef<HTMLInputElement>;

  /**
   * Unique identifier for the input
   */
  id = input.required<string>();

  /**
   * Label text for the input
   */
  label = input<string>('');

  /**
   * Input type (text, email, password, etc.)
   */
  type = input<string>('text');

  /**
   * Placeholder text
   */
  placeholder = input<string>('');

  /**
   * Whether the field is required
   */
  required = input<boolean>(false);

  /**
   * Whether the input is disabled
   */
  disabled = input<boolean>(false);

  /**
   * Auto-focus the input on load
   */
  autoFocus = input<boolean>(false);

  /**
   * Auto-complete attribute value
   */
  autoComplete = input<string>('off');

  /**
   * Size variant
   */
  size = input<InputSize>('default');

  /**
   * Full width input
   */
  fullWidth = input<boolean>(true);

  /**
   * Error message to display
   */
  error = input<string>('');

  /**
   * Additional CSS classes
   */
  class = input<string>('');

  /**
   * ARIA label for accessibility
   */
  ariaLabel = input<string | undefined>(undefined);

  /**
   * Internal value state
   */
  value = signal<string>('');

  /**
   * Internal disabled state
   */
  isDisabled = signal<boolean>(false);

  /**
   * Internal touched state
   */
  isTouched = signal<boolean>(false);

  /**
   * Computed CSS classes for the input
   */
  inputClasses = computed(() => {
    const classes: string[] = [
      'flex',
      'w-full',
      'rounded-md',
      'border',
      'px-3',
      'py-1',
      'text-base',
      'transition-all',
      'outline-none',
      'bg-white',
      'disabled:pointer-events-none',
      'disabled:cursor-not-allowed',
      'disabled:opacity-50'
    ];

    // Size classes
    if (this.size() === 'small') {
      classes.push('h-8', 'text-sm');
    } else {
      classes.push('h-9', 'md:text-sm');
    }

    // Error state
    if (this.error() && this.isTouched()) {
      classes.push(
        'border-red-500',
        'focus:ring-red-500',
        'focus:border-red-500',
        'focus:ring-2'
      );
    } else {
      classes.push(
        'border-gray-300',
        'focus:ring-blue-500',
        'focus:border-blue-500',
        'focus:ring-2'
      );
    }

    // Full width
    if (!this.fullWidth()) {
      classes.push('max-w-md');
    }

    return classes.join(' ');
  });

  /**
   * Computed wrapper classes
   */
  wrapperClasses = computed(() => {
    const classes: string[] = ['mb-4'];
    
    if (this.fullWidth()) {
      classes.push('w-full');
    }

    if (this.class()) {
      classes.push(this.class());
    }

    return classes.join(' ');
  });

  /**
   * Check if error should be displayed
   */
  shouldShowError = computed(() => {
    return this.error() && this.isTouched();
  });

  // ControlValueAccessor implementation
  private onChange: (value: string) => void = () => {};
  private onTouched: () => void = () => {};

  ngAfterViewInit(): void {
    if (this.autoFocus()) {
      setTimeout(() => {
        this.inputElement?.nativeElement.focus();
      }, 0);
    }
  }

  /**
   * Write value to the component
   */
  writeValue(value: string): void {
    this.value.set(value || '');
  }

  /**
   * Register onChange callback
   */
  registerOnChange(fn: (value: string) => void): void {
    this.onChange = fn;
  }

  /**
   * Register onTouched callback
   */
  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  /**
   * Set disabled state
   */
  setDisabledState(isDisabled: boolean): void {
    this.isDisabled.set(isDisabled);
  }

  /**
   * Handle input change
   */
  onInputChange(event: Event): void {
    const target = event.target as HTMLInputElement;
    const value = target.value;
    this.value.set(value);
    this.onChange(value);
  }

  /**
   * Handle input blur
   */
  onInputBlur(): void {
    this.isTouched.set(true);
    this.onTouched();
  }
}

// Made with Bob
