import { 
  Component, 
  input, 
  signal,
  forwardRef,
  ChangeDetectionStrategy
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { 
  ControlValueAccessor, 
  NG_VALUE_ACCESSOR,
  ReactiveFormsModule,
  FormsModule
} from '@angular/forms';

/**
 * Checkbox size variants
 */
export type CheckboxSize = 'small' | 'default';

/**
 * Reusable Checkbox Component with Form Integration
 * 
 * A flexible checkbox component that integrates with Angular Reactive Forms
 * through ControlValueAccessor. Supports labels and various configurations.
 * 
 * @example
 * ```html
 * <app-checkbox
 *   [id]="'remember-me'"
 *   [label]="'Remember me'"
 *   formControlName="rememberMe"
 * ></app-checkbox>
 * ```
 */
@Component({
  selector: 'app-checkbox',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './checkbox.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => CheckboxComponent),
      multi: true
    }
  ]
})
export class CheckboxComponent implements ControlValueAccessor {
  /**
   * Unique identifier for the checkbox
   */
  id = input.required<string>();

  /**
   * Label text for the checkbox
   */
  label = input<string>('');

  /**
   * Whether the checkbox is disabled
   */
  disabled = input<boolean>(false);

  /**
   * Size variant
   */
  size = input<CheckboxSize>('default');

  /**
   * Additional CSS classes
   */
  class = input<string>('');

  /**
   * ARIA label for accessibility
   */
  ariaLabel = input<string | undefined>(undefined);

  /**
   * Internal checked state
   */
  checked = signal<boolean>(false);

  /**
   * Internal disabled state
   */
  isDisabled = signal<boolean>(false);

  /**
   * Computed CSS classes for the checkbox
   */
  checkboxClasses = (): string => {
    const classes: string[] = [
      'peer',
      'shrink-0',
      'rounded',
      'border',
      'border-gray-300',
      'bg-white',
      'transition-all',
      'outline-none',
      'cursor-pointer',
      'focus:ring-2',
      'focus:ring-blue-500',
      'focus:ring-offset-2',
      'checked:bg-blue-600',
      'checked:border-blue-600',
      'disabled:cursor-not-allowed',
      'disabled:opacity-50'
    ];

    // Size classes
    if (this.size() === 'small') {
      classes.push('h-4', 'w-4');
    } else {
      classes.push('h-5', 'w-5');
    }

    return classes.join(' ');
  };

  /**
   * Computed wrapper classes
   */
  wrapperClasses = (): string => {
    const classes: string[] = ['flex', 'items-center'];
    
    if (this.class()) {
      classes.push(this.class());
    }

    return classes.join(' ');
  };

  /**
   * Computed label classes
   */
  labelClasses = (): string => {
    const classes: string[] = [
      'ml-2',
      'text-sm',
      'text-gray-700',
      'cursor-pointer',
      'select-none'
    ];

    if (this.isDisabled() || this.disabled()) {
      classes.push('cursor-not-allowed', 'opacity-50');
    }

    return classes.join(' ');
  };

  // ControlValueAccessor implementation
  private onChange: (value: boolean) => void = () => {};
  private onTouched: () => void = () => {};

  /**
   * Write value to the component
   */
  writeValue(value: boolean): void {
    this.checked.set(value || false);
  }

  /**
   * Register onChange callback
   */
  registerOnChange(fn: (value: boolean) => void): void {
    this.onChange = fn;
  }

  /**
   * Register onTouched callback
   */
  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  /**
   * Set disabled state
   */
  setDisabledState(isDisabled: boolean): void {
    this.isDisabled.set(isDisabled);
  }

  /**
   * Handle checkbox change
   */
  onCheckboxChange(event: Event): void {
    const target = event.target as HTMLInputElement;
    const value = target.checked;
    this.checked.set(value);
    this.onChange(value);
    this.onTouched();
  }
}

// Made with Bob
