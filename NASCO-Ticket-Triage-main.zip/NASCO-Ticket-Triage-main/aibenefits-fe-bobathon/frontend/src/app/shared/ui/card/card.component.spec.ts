import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { CardComponent } from './card.component';

describe('CardComponent', () => {
  let component: CardComponent;
  let fixture: ComponentFixture<CardComponent>;
  let cardElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CardComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(CardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    cardElement = fixture.debugElement.query(By.css('div'));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Rendering', () => {
    it('should render div element', () => {
      expect(cardElement).toBeTruthy();
      expect(cardElement.nativeElement.tagName).toBe('DIV');
    });

    it('should project content', () => {
      const testContent = '<h2>Test Title</h2><p>Test content</p>';
      fixture = TestBed.createComponent(CardComponent);
      fixture.nativeElement.innerHTML = testContent;
      fixture.detectChanges();
      
      expect(fixture.nativeElement.innerHTML).toContain('Test Title');
      expect(fixture.nativeElement.innerHTML).toContain('Test content');
    });

    it('should have base CSS classes', () => {
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('bg-white');
      expect(classes).toContain('border');
      expect(classes).toContain('border-gray-200');
    });
  });

  describe('Elevation Variants', () => {
    it('should apply default elevation (1)', () => {
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('shadow-sm');
    });

    it('should apply elevation 0 (no shadow)', () => {
      fixture.componentRef.setInput('elevation', 0);
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('shadow-none');
    });

    it('should apply elevation 2', () => {
      fixture.componentRef.setInput('elevation', 2);
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('shadow');
    });

    it('should apply elevation 3', () => {
      fixture.componentRef.setInput('elevation', 3);
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('shadow-md');
    });

    it('should apply elevation 6', () => {
      fixture.componentRef.setInput('elevation', 6);
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('shadow-lg');
    });

    it('should apply elevation 8', () => {
      fixture.componentRef.setInput('elevation', 8);
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('shadow-xl');
    });

    it('should apply elevation 12', () => {
      fixture.componentRef.setInput('elevation', 12);
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('shadow-2xl');
    });

    it('should apply elevation 24', () => {
      fixture.componentRef.setInput('elevation', 24);
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('shadow-2xl');
    });
  });

  describe('Padding Variants', () => {
    it('should apply default padding (md)', () => {
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('p-6');
    });

    it('should apply no padding', () => {
      fixture.componentRef.setInput('padding', 'none');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('p-0');
    });

    it('should apply small padding', () => {
      fixture.componentRef.setInput('padding', 'sm');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('p-4');
    });

    it('should apply medium padding', () => {
      fixture.componentRef.setInput('padding', 'md');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('p-6');
    });

    it('should apply large padding', () => {
      fixture.componentRef.setInput('padding', 'lg');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('p-8');
    });
  });

  describe('Border Radius Variants', () => {
    it('should apply default radius (md)', () => {
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('rounded-md');
    });

    it('should apply no radius', () => {
      fixture.componentRef.setInput('radius', 'none');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('rounded-none');
    });

    it('should apply small radius', () => {
      fixture.componentRef.setInput('radius', 'sm');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('rounded-sm');
    });

    it('should apply medium radius', () => {
      fixture.componentRef.setInput('radius', 'md');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('rounded-md');
    });

    it('should apply large radius', () => {
      fixture.componentRef.setInput('radius', 'lg');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('rounded-lg');
    });

    it('should apply extra large radius', () => {
      fixture.componentRef.setInput('radius', 'xl');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('rounded-xl');
    });
  });

  describe('Custom Classes', () => {
    it('should not have custom classes by default', () => {
      expect(component.class()).toBe('');
    });

    it('should apply custom classes when provided', () => {
      const customClass = 'max-w-md mx-auto';
      fixture.componentRef.setInput('class', customClass);
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('max-w-md');
      expect(classes).toContain('mx-auto');
    });

    it('should preserve base classes when custom classes are added', () => {
      fixture.componentRef.setInput('class', 'custom-class');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('bg-white');
      expect(classes).toContain('border');
      expect(classes).toContain('custom-class');
    });
  });

  describe('Combined Variants', () => {
    it('should apply multiple variants together', () => {
      fixture.componentRef.setInput('elevation', 8);
      fixture.componentRef.setInput('padding', 'lg');
      fixture.componentRef.setInput('radius', 'xl');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('shadow-xl');
      expect(classes).toContain('p-8');
      expect(classes).toContain('rounded-xl');
    });

    it('should handle all inputs including custom class', () => {
      fixture.componentRef.setInput('elevation', 6);
      fixture.componentRef.setInput('padding', 'sm');
      fixture.componentRef.setInput('radius', 'lg');
      fixture.componentRef.setInput('class', 'max-w-lg');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('shadow-lg');
      expect(classes).toContain('p-4');
      expect(classes).toContain('rounded-lg');
      expect(classes).toContain('max-w-lg');
    });
  });

  describe('Content Projection', () => {
    it('should project simple text content', () => {
      fixture = TestBed.createComponent(CardComponent);
      const textContent = 'Simple card content';
      fixture.nativeElement.textContent = textContent;
      fixture.detectChanges();
      
      expect(fixture.nativeElement.textContent).toContain(textContent);
    });

    it('should project complex HTML content', () => {
      fixture = TestBed.createComponent(CardComponent);
      fixture.nativeElement.innerHTML = `
        <div class="card-header">
          <h2>Card Title</h2>
        </div>
        <div class="card-body">
          <p>Card body content</p>
        </div>
      `;
      fixture.detectChanges();
      
      expect(fixture.nativeElement.innerHTML).toContain('Card Title');
      expect(fixture.nativeElement.innerHTML).toContain('Card body content');
    });
  });

  describe('Computed Properties', () => {
    it('should compute card classes correctly', () => {
      const classes = component.cardClasses();
      expect(classes).toContain('bg-white');
      expect(classes).toContain('shadow-sm');
      expect(classes).toContain('p-6');
      expect(classes).toContain('rounded-md');
    });

    it('should update computed classes when inputs change', () => {
      fixture.componentRef.setInput('elevation', 8);
      fixture.componentRef.setInput('padding', 'lg');
      fixture.detectChanges();
      
      const classes = component.cardClasses();
      expect(classes).toContain('shadow-xl');
      expect(classes).toContain('p-8');
    });
  });

  describe('Edge Cases', () => {
    it('should handle rapid variant changes', () => {
      fixture.componentRef.setInput('elevation', 2);
      fixture.detectChanges();
      expect(cardElement.nativeElement.className).toContain('shadow');

      fixture.componentRef.setInput('elevation', 8);
      fixture.detectChanges();
      expect(cardElement.nativeElement.className).toContain('shadow-xl');

      fixture.componentRef.setInput('elevation', 0);
      fixture.detectChanges();
      expect(cardElement.nativeElement.className).toContain('shadow-none');
    });

    it('should handle empty custom class', () => {
      fixture.componentRef.setInput('class', '');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('bg-white');
      expect(classes).not.toContain('undefined');
    });

    it('should handle multiple custom classes', () => {
      fixture.componentRef.setInput('class', 'class-1 class-2 class-3');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('class-1');
      expect(classes).toContain('class-2');
      expect(classes).toContain('class-3');
    });
  });

  describe('Material UI Paper Compatibility', () => {
    it('should match Material UI Paper elevation 8 styling', () => {
      fixture.componentRef.setInput('elevation', 8);
      fixture.componentRef.setInput('padding', 'lg');
      fixture.componentRef.setInput('radius', 'md');
      fixture.detectChanges();
      
      const classes = cardElement.nativeElement.className;
      expect(classes).toContain('shadow-xl');
      expect(classes).toContain('p-8');
      expect(classes).toContain('rounded-md');
    });

    it('should support all Material UI elevation levels', () => {
      const elevations: Array<0 | 1 | 2 | 3 | 4 | 6 | 8 | 12 | 16 | 24> = [0, 1, 2, 3, 4, 6, 8, 12, 16, 24];
      
      elevations.forEach(elevation => {
        fixture.componentRef.setInput('elevation', elevation);
        fixture.detectChanges();
        
        const classes = cardElement.nativeElement.className;
        expect(classes).toContain('shadow');
      });
    });
  });
});

// Made with Bob
