import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { LabelComponent } from './label.component';

describe('LabelComponent', () => {
  let component: LabelComponent;
  let fixture: ComponentFixture<LabelComponent>;
  let labelElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LabelComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(LabelComponent);
    component = fixture.componentInstance;
    labelElement = fixture.debugElement.query(By.css('label'));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Rendering', () => {
    it('should render label element', () => {
      expect(labelElement).toBeTruthy();
      expect(labelElement.nativeElement.tagName).toBe('LABEL');
    });

    it('should project content', () => {
      const testContent = 'Email Address';
      fixture = TestBed.createComponent(LabelComponent);
      fixture.nativeElement.textContent = testContent;
      fixture.detectChanges();
      
      expect(fixture.nativeElement.textContent).toContain(testContent);
    });

    it('should have base CSS classes', () => {
      const classes = labelElement.nativeElement.className;
      expect(classes).toContain('text-sm');
      expect(classes).toContain('font-medium');
      expect(classes).toContain('text-gray-700');
      expect(classes).toContain('block');
      expect(classes).toContain('mb-1.5');
    });
  });

  describe('For Attribute', () => {
    it('should not have for attribute by default', () => {
      expect(labelElement.nativeElement.getAttribute('for')).toBe('');
    });

    it('should set for attribute when provided', () => {
      const forValue = 'email-input';
      fixture.componentRef.setInput('for', forValue);
      fixture.detectChanges();
      
      expect(labelElement.nativeElement.getAttribute('for')).toBe(forValue);
    });

    it('should update for attribute when changed', () => {
      fixture.componentRef.setInput('for', 'input-1');
      fixture.detectChanges();
      expect(labelElement.nativeElement.getAttribute('for')).toBe('input-1');

      fixture.componentRef.setInput('for', 'input-2');
      fixture.detectChanges();
      expect(labelElement.nativeElement.getAttribute('for')).toBe('input-2');
    });
  });

  describe('Required Indicator', () => {
    it('should not show required indicator by default', () => {
      const requiredSpan = labelElement.query(By.css('span[aria-label="required"]'));
      expect(requiredSpan).toBeFalsy();
    });

    it('should show required indicator when required is true', () => {
      fixture.componentRef.setInput('required', true);
      fixture.detectChanges();
      
      const requiredSpan = labelElement.query(By.css('span[aria-label="required"]'));
      expect(requiredSpan).toBeTruthy();
      expect(requiredSpan.nativeElement.textContent).toBe('*');
    });

    it('should not show required indicator when required is false', () => {
      fixture.componentRef.setInput('required', false);
      fixture.detectChanges();
      
      const requiredSpan = labelElement.query(By.css('span[aria-label="required"]'));
      expect(requiredSpan).toBeFalsy();
    });

    it('should have proper styling for required indicator', () => {
      fixture.componentRef.setInput('required', true);
      fixture.detectChanges();
      
      const requiredSpan = labelElement.query(By.css('span[aria-label="required"]'));
      const classes = requiredSpan.nativeElement.className;
      expect(classes).toContain('text-red-500');
      expect(classes).toContain('ml-0.5');
    });

    it('should toggle required indicator', () => {
      fixture.componentRef.setInput('required', true);
      fixture.detectChanges();
      let requiredSpan = labelElement.query(By.css('span[aria-label="required"]'));
      expect(requiredSpan).toBeTruthy();

      fixture.componentRef.setInput('required', false);
      fixture.detectChanges();
      requiredSpan = labelElement.query(By.css('span[aria-label="required"]'));
      expect(requiredSpan).toBeFalsy();
    });
  });

  describe('Custom Classes', () => {
    it('should not have custom classes by default', () => {
      expect(component.class()).toBe('');
    });

    it('should apply custom classes when provided', () => {
      const customClass = 'custom-label-class';
      fixture.componentRef.setInput('class', customClass);
      fixture.detectChanges();
      
      const classes = labelElement.nativeElement.className;
      expect(classes).toContain(customClass);
    });

    it('should preserve base classes when custom classes are added', () => {
      fixture.componentRef.setInput('class', 'custom-class');
      fixture.detectChanges();
      
      const classes = labelElement.nativeElement.className;
      expect(classes).toContain('text-sm');
      expect(classes).toContain('font-medium');
      expect(classes).toContain('custom-class');
    });

    it('should update custom classes when changed', () => {
      fixture.componentRef.setInput('class', 'class-1');
      fixture.detectChanges();
      expect(labelElement.nativeElement.className).toContain('class-1');

      fixture.componentRef.setInput('class', 'class-2');
      fixture.detectChanges();
      expect(labelElement.nativeElement.className).toContain('class-2');
      expect(labelElement.nativeElement.className).not.toContain('class-1');
    });
  });

  describe('Accessibility', () => {
    it('should have aria-label on required indicator', () => {
      fixture.componentRef.setInput('required', true);
      fixture.detectChanges();
      
      const requiredSpan = labelElement.query(By.css('span[aria-label="required"]'));
      expect(requiredSpan.nativeElement.getAttribute('aria-label')).toBe('required');
    });

    it('should be properly associated with form control via for attribute', () => {
      const inputId = 'test-input';
      fixture.componentRef.setInput('for', inputId);
      fixture.detectChanges();
      
      expect(labelElement.nativeElement.getAttribute('for')).toBe(inputId);
    });
  });

  describe('Integration', () => {
    it('should work with all inputs combined', () => {
      fixture.componentRef.setInput('for', 'email');
      fixture.componentRef.setInput('required', true);
      fixture.componentRef.setInput('class', 'custom-label');
      fixture.detectChanges();
      
      expect(labelElement.nativeElement.getAttribute('for')).toBe('email');
      
      const requiredSpan = labelElement.query(By.css('span[aria-label="required"]'));
      expect(requiredSpan).toBeTruthy();
      
      const classes = labelElement.nativeElement.className;
      expect(classes).toContain('custom-label');
      expect(classes).toContain('text-sm');
    });

    it('should handle empty string for attribute', () => {
      fixture.componentRef.setInput('for', '');
      fixture.detectChanges();
      
      expect(labelElement.nativeElement.getAttribute('for')).toBe('');
    });

    it('should handle multiple class names', () => {
      fixture.componentRef.setInput('class', 'class-1 class-2 class-3');
      fixture.detectChanges();
      
      const classes = labelElement.nativeElement.className;
      expect(classes).toContain('class-1');
      expect(classes).toContain('class-2');
      expect(classes).toContain('class-3');
    });
  });

  describe('Component Inputs', () => {
    it('should have correct default values', () => {
      expect(component.for()).toBe('');
      expect(component.required()).toBe(false);
      expect(component.class()).toBe('');
    });

    it('should accept signal input for "for"', () => {
      fixture.componentRef.setInput('for', 'test-id');
      expect(component.for()).toBe('test-id');
    });

    it('should accept signal input for "required"', () => {
      fixture.componentRef.setInput('required', true);
      expect(component.required()).toBe(true);
    });

    it('should accept signal input for "class"', () => {
      fixture.componentRef.setInput('class', 'test-class');
      expect(component.class()).toBe('test-class');
    });
  });

  describe('Edge Cases', () => {
    it('should handle special characters in for attribute', () => {
      const specialId = 'input-with-special_chars.123';
      fixture.componentRef.setInput('for', specialId);
      fixture.detectChanges();
      
      expect(labelElement.nativeElement.getAttribute('for')).toBe(specialId);
    });

    it('should handle very long class names', () => {
      const longClass = 'very-long-class-name-that-might-be-used-in-some-cases';
      fixture.componentRef.setInput('class', longClass);
      fixture.detectChanges();
      
      expect(labelElement.nativeElement.className).toContain(longClass);
    });

    it('should handle rapid state changes', () => {
      fixture.componentRef.setInput('required', true);
      fixture.detectChanges();
      expect(labelElement.query(By.css('span[aria-label="required"]'))).toBeTruthy();

      fixture.componentRef.setInput('required', false);
      fixture.detectChanges();
      expect(labelElement.query(By.css('span[aria-label="required"]'))).toBeFalsy();

      fixture.componentRef.setInput('required', true);
      fixture.detectChanges();
      expect(labelElement.query(By.css('span[aria-label="required"]'))).toBeTruthy();
    });
  });
});

// Made with Bob
