import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { CheckboxComponent } from './checkbox.component';

describe('CheckboxComponent', () => {
  let component: CheckboxComponent;
  let fixture: ComponentFixture<CheckboxComponent>;
  let checkboxElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CheckboxComponent, ReactiveFormsModule]
    }).compileComponents();

    fixture = TestBed.createComponent(CheckboxComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('id', 'test-checkbox');
    fixture.detectChanges();
    checkboxElement = fixture.debugElement.query(By.css('input[type="checkbox"]'));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Rendering', () => {
    it('should render checkbox input element', () => {
      expect(checkboxElement).toBeTruthy();
      expect(checkboxElement.nativeElement.type).toBe('checkbox');
    });

    it('should set checkbox id', () => {
      expect(checkboxElement.nativeElement.id).toBe('test-checkbox');
    });

    it('should render label when provided', () => {
      fixture.componentRef.setInput('label', 'Remember me');
      fixture.detectChanges();
      
      const label = fixture.debugElement.query(By.css('label'));
      expect(label).toBeTruthy();
      expect(label.nativeElement.textContent.trim()).toBe('Remember me');
    });

    it('should not render label when not provided', () => {
      const label = fixture.debugElement.query(By.css('label'));
      expect(label).toBeFalsy();
    });

    it('should link label to checkbox via for attribute', () => {
      fixture.componentRef.setInput('label', 'Test Label');
      fixture.detectChanges();
      
      const label = fixture.debugElement.query(By.css('label'));
      expect(label.nativeElement.getAttribute('for')).toBe('test-checkbox');
    });
  });

  describe('Checked State', () => {
    it('should not be checked by default', () => {
      expect(checkboxElement.nativeElement.checked).toBe(false);
      expect(component.checked()).toBe(false);
    });

    it('should be checked when value is true', () => {
      component.writeValue(true);
      fixture.detectChanges();
      
      expect(component.checked()).toBe(true);
    });

    it('should be unchecked when value is false', () => {
      component.writeValue(false);
      fixture.detectChanges();
      
      expect(component.checked()).toBe(false);
    });

    it('should toggle checked state on click', () => {
      expect(component.checked()).toBe(false);
      
      checkboxElement.nativeElement.click();
      fixture.detectChanges();
      
      expect(component.checked()).toBe(true);
    });
  });

  describe('Disabled State', () => {
    it('should not be disabled by default', () => {
      expect(checkboxElement.nativeElement.disabled).toBe(false);
    });

    it('should be disabled when disabled input is true', () => {
      fixture.componentRef.setInput('disabled', true);
      fixture.detectChanges();
      
      expect(checkboxElement.nativeElement.disabled).toBe(true);
    });

    it('should be disabled via setDisabledState', () => {
      component.setDisabledState(true);
      fixture.detectChanges();
      
      expect(checkboxElement.nativeElement.disabled).toBe(true);
      expect(component.isDisabled()).toBe(true);
    });

    it('should apply disabled styles to label', () => {
      fixture.componentRef.setInput('label', 'Test');
      fixture.componentRef.setInput('disabled', true);
      fixture.detectChanges();
      
      const label = fixture.debugElement.query(By.css('label'));
      const classes = label.nativeElement.className;
      expect(classes).toContain('cursor-not-allowed');
      expect(classes).toContain('opacity-50');
    });
  });

  describe('Size Variants', () => {
    it('should apply default size classes', () => {
      const classes = checkboxElement.nativeElement.className;
      expect(classes).toContain('h-5');
      expect(classes).toContain('w-5');
    });

    it('should apply small size classes', () => {
      fixture.componentRef.setInput('size', 'small');
      fixture.detectChanges();
      
      const classes = checkboxElement.nativeElement.className;
      expect(classes).toContain('h-4');
      expect(classes).toContain('w-4');
    });
  });

  describe('ControlValueAccessor', () => {
    it('should write value', () => {
      component.writeValue(true);
      expect(component.checked()).toBe(true);
    });

    it('should write false for null value', () => {
      component.writeValue(null as any);
      expect(component.checked()).toBe(false);
    });

    it('should call onChange when checkbox changes', () => {
      const onChangeSpy = jasmine.createSpy('onChange');
      component.registerOnChange(onChangeSpy);
      
      checkboxElement.nativeElement.click();
      
      expect(onChangeSpy).toHaveBeenCalledWith(true);
    });

    it('should call onTouched when checkbox changes', () => {
      const onTouchedSpy = jasmine.createSpy('onTouched');
      component.registerOnTouched(onTouchedSpy);
      
      checkboxElement.nativeElement.click();
      
      expect(onTouchedSpy).toHaveBeenCalled();
    });

    it('should update internal checked state on change', () => {
      expect(component.checked()).toBe(false);
      
      checkboxElement.nativeElement.click();
      
      expect(component.checked()).toBe(true);
    });
  });

  describe('Reactive Forms Integration', () => {
    it('should work with FormControl', () => {
      const control = new FormControl(false);
      
      component.writeValue(control.value);
      expect(component.checked()).toBe(false);
      
      component.registerOnChange((value) => control.setValue(value));
      
      checkboxElement.nativeElement.click();
      
      expect(control.value).toBe(true);
    });

    it('should update when FormControl value changes', () => {
      const control = new FormControl(false);
      
      component.writeValue(control.value);
      expect(component.checked()).toBe(false);
      
      control.setValue(true);
      component.writeValue(control.value);
      
      expect(component.checked()).toBe(true);
    });
  });

  describe('Accessibility', () => {
    it('should have aria-label from input', () => {
      fixture.componentRef.setInput('ariaLabel', 'Remember me checkbox');
      fixture.detectChanges();
      
      expect(checkboxElement.nativeElement.getAttribute('aria-label')).toBe('Remember me checkbox');
    });

    it('should use label as aria-label when ariaLabel not provided', () => {
      fixture.componentRef.setInput('label', 'Remember me');
      fixture.detectChanges();
      
      expect(checkboxElement.nativeElement.getAttribute('aria-label')).toBe('Remember me');
    });

    it('should set aria-checked attribute', () => {
      expect(checkboxElement.nativeElement.getAttribute('aria-checked')).toBe('false');
      
      component.writeValue(true);
      fixture.detectChanges();
      
      expect(checkboxElement.nativeElement.getAttribute('aria-checked')).toBe('true');
    });

    it('should set aria-disabled when disabled', () => {
      fixture.componentRef.setInput('disabled', true);
      fixture.detectChanges();
      
      expect(checkboxElement.nativeElement.getAttribute('aria-disabled')).toBe('true');
    });

    it('should be keyboard accessible', () => {
      checkboxElement.nativeElement.focus();
      expect(document.activeElement).toBe(checkboxElement.nativeElement);
    });
  });

  describe('CSS Classes', () => {
    it('should have base checkbox classes', () => {
      const classes = checkboxElement.nativeElement.className;
      expect(classes).toContain('peer');
      expect(classes).toContain('shrink-0');
      expect(classes).toContain('rounded');
      expect(classes).toContain('border');
      expect(classes).toContain('cursor-pointer');
    });

    it('should have transition classes', () => {
      const classes = checkboxElement.nativeElement.className;
      expect(classes).toContain('transition-all');
    });

    it('should have focus classes', () => {
      const classes = checkboxElement.nativeElement.className;
      expect(classes).toContain('focus:ring-2');
      expect(classes).toContain('focus:ring-blue-500');
    });

    it('should have checked state classes', () => {
      const classes = checkboxElement.nativeElement.className;
      expect(classes).toContain('checked:bg-blue-600');
      expect(classes).toContain('checked:border-blue-600');
    });

    it('should have disabled state classes', () => {
      const classes = checkboxElement.nativeElement.className;
      expect(classes).toContain('disabled:cursor-not-allowed');
      expect(classes).toContain('disabled:opacity-50');
    });

    it('should apply custom classes to wrapper', () => {
      fixture.componentRef.setInput('class', 'custom-wrapper-class');
      fixture.detectChanges();
      
      const wrapper = fixture.debugElement.query(By.css('div'));
      expect(wrapper.nativeElement.className).toContain('custom-wrapper-class');
    });

    it('should have flex layout classes on wrapper', () => {
      const wrapper = fixture.debugElement.query(By.css('div'));
      const classes = wrapper.nativeElement.className;
      expect(classes).toContain('flex');
      expect(classes).toContain('items-center');
    });
  });

  describe('Label Styling', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('label', 'Test Label');
      fixture.detectChanges();
    });

    it('should have base label classes', () => {
      const label = fixture.debugElement.query(By.css('label'));
      const classes = label.nativeElement.className;
      expect(classes).toContain('ml-2');
      expect(classes).toContain('text-sm');
      expect(classes).toContain('text-gray-700');
      expect(classes).toContain('cursor-pointer');
      expect(classes).toContain('select-none');
    });

    it('should be clickable', () => {
      const label = fixture.debugElement.query(By.css('label'));
      expect(label.nativeElement.className).toContain('cursor-pointer');
    });
  });

  describe('Edge Cases', () => {
    it('should handle rapid state changes', () => {
      component.writeValue(true);
      expect(component.checked()).toBe(true);
      
      component.writeValue(false);
      expect(component.checked()).toBe(false);
      
      component.writeValue(true);
      expect(component.checked()).toBe(true);
    });

    it('should handle multiple clicks', () => {
      const onChangeSpy = jasmine.createSpy('onChange');
      component.registerOnChange(onChangeSpy);
      
      checkboxElement.nativeElement.click();
      checkboxElement.nativeElement.click();
      checkboxElement.nativeElement.click();
      
      expect(onChangeSpy).toHaveBeenCalledTimes(3);
    });

    it('should not trigger change when disabled', () => {
      const onChangeSpy = jasmine.createSpy('onChange');
      component.registerOnChange(onChangeSpy);
      
      fixture.componentRef.setInput('disabled', true);
      fixture.detectChanges();
      
      // Disabled checkboxes don't trigger click events
      expect(checkboxElement.nativeElement.disabled).toBe(true);
    });
  });

  describe('Computed Properties', () => {
    it('should compute checkbox classes correctly', () => {
      const classes = component.checkboxClasses();
      expect(classes).toContain('peer');
      expect(classes).toContain('h-5');
      expect(classes).toContain('w-5');
    });

    it('should compute wrapper classes correctly', () => {
      const classes = component.wrapperClasses();
      expect(classes).toContain('flex');
      expect(classes).toContain('items-center');
    });

    it('should compute label classes correctly', () => {
      const classes = component.labelClasses();
      expect(classes).toContain('ml-2');
      expect(classes).toContain('text-sm');
    });

    it('should include custom class in wrapper', () => {
      fixture.componentRef.setInput('class', 'my-custom-class');
      const classes = component.wrapperClasses();
      expect(classes).toContain('my-custom-class');
    });
  });
});

// Made with Bob
