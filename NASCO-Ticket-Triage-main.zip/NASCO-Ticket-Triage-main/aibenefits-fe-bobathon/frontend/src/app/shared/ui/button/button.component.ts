import { Component, input, computed, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Button variant types matching Shadcn design system
 */
export type ButtonVariant = 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link';

/**
 * Button size types
 */
export type ButtonSize = 'default' | 'sm' | 'lg' | 'icon';

/**
 * Reusable Button Component
 * 
 * A flexible button component that supports multiple variants, sizes, and states.
 * Follows Shadcn design patterns with Tailwind CSS styling.
 * 
 * @example
 * ```html
 * <app-button variant="default" size="lg" [loading]="isLoading">
 *   Sign In
 * </app-button>
 * ```
 */
@Component({
  selector: 'app-button',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './button.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ButtonComponent {
  /**
   * Button visual variant
   */
  variant = input<ButtonVariant>('default');

  /**
   * Button size
   */
  size = input<ButtonSize>('default');

  /**
   * Loading state - shows spinner and disables button
   */
  loading = input<boolean>(false);

  /**
   * Disabled state
   */
  disabled = input<boolean>(false);

  /**
   * Full width button
   */
  fullWidth = input<boolean>(false);

  /**
   * Button type attribute
   */
  type = input<'button' | 'submit' | 'reset'>('button');

  /**
   * ARIA label for accessibility
   */
  ariaLabel = input<string | undefined>(undefined);

  /**
   * Computed CSS classes based on variant, size, and state
   */
  buttonClasses = computed(() => {
    const classes: string[] = [
      // Base classes
      'inline-flex',
      'items-center',
      'justify-center',
      'gap-2',
      'whitespace-nowrap',
      'rounded-md',
      'text-sm',
      'font-medium',
      'transition-all',
      'outline-none',
      'focus-visible:ring-2',
      'focus-visible:ring-offset-2',
      'disabled:pointer-events-none',
      'disabled:opacity-50'
    ];

    // Variant classes
    const variantClasses: Record<ButtonVariant, string[]> = {
      default: [
        'bg-blue-600',
        'text-white',
        'hover:bg-blue-700',
        'focus-visible:ring-blue-500'
      ],
      destructive: [
        'bg-red-600',
        'text-white',
        'hover:bg-red-700',
        'focus-visible:ring-red-500'
      ],
      outline: [
        'border',
        'border-gray-300',
        'bg-white',
        'text-gray-700',
        'hover:bg-gray-50',
        'focus-visible:ring-gray-500'
      ],
      secondary: [
        'bg-gray-100',
        'text-gray-900',
        'hover:bg-gray-200',
        'focus-visible:ring-gray-500'
      ],
      ghost: [
        'text-gray-700',
        'hover:bg-gray-100',
        'focus-visible:ring-gray-500'
      ],
      link: [
        'text-blue-600',
        'underline-offset-4',
        'hover:underline',
        'focus-visible:ring-blue-500'
      ]
    };

    classes.push(...variantClasses[this.variant()]);

    // Size classes
    const sizeClasses: Record<ButtonSize, string[]> = {
      default: ['h-9', 'px-4', 'py-2'],
      sm: ['h-8', 'px-3', 'text-xs'],
      lg: ['h-10', 'px-6', 'text-base'],
      icon: ['h-9', 'w-9', 'p-0']
    };

    classes.push(...sizeClasses[this.size()]);

    // Full width
    if (this.fullWidth()) {
      classes.push('w-full');
    }

    return classes.join(' ');
  });

  /**
   * Check if button should be disabled
   */
  isDisabled = computed(() => this.disabled() || this.loading());
}

// Made with Bob
