import { Component, input, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Reusable Label Component
 * 
 * A simple label component for form fields with support for required indicators
 * and proper accessibility attributes.
 * 
 * @example
 * ```html
 * <app-label [for]="'email'" [required]="true">
 *   Email Address
 * </app-label>
 * ```
 */
@Component({
  selector: 'app-label',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './label.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LabelComponent {
  /**
   * The ID of the form control this label is associated with
   */
  for = input<string>('');

  /**
   * Whether the associated field is required
   */
  required = input<boolean>(false);

  /**
   * Additional CSS classes to apply
   */
  class = input<string>('');
}

// Made with Bob
