import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { ButtonComponent } from './button.component';

describe('ButtonComponent', () => {
  let component: ButtonComponent;
  let fixture: ComponentFixture<ButtonComponent>;
  let buttonElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ButtonComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(ButtonComponent);
    component = fixture.componentInstance;
    buttonElement = fixture.debugElement.query(By.css('button'));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Rendering', () => {
    it('should render button element', () => {
      expect(buttonElement).toBeTruthy();
      expect(buttonElement.nativeElement.tagName).toBe('BUTTON');
    });

    it('should project content', () => {
      const testContent = 'Click Me';
      fixture = TestBed.createComponent(ButtonComponent);
      fixture.nativeElement.textContent = testContent;
      fixture.detectChanges();
      
      expect(fixture.nativeElement.textContent).toContain(testContent);
    });
  });

  describe('Variants', () => {
    it('should apply default variant classes', () => {
      fixture.componentRef.setInput('variant', 'default');
      fixture.detectChanges();
      
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('bg-blue-600');
      expect(classes).toContain('text-white');
    });

    it('should apply destructive variant classes', () => {
      fixture.componentRef.setInput('variant', 'destructive');
      fixture.detectChanges();
      
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('bg-red-600');
      expect(classes).toContain('text-white');
    });

    it('should apply outline variant classes', () => {
      fixture.componentRef.setInput('variant', 'outline');
      fixture.detectChanges();
      
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('border');
      expect(classes).toContain('bg-white');
    });

    it('should apply secondary variant classes', () => {
      fixture.componentRef.setInput('variant', 'secondary');
      fixture.detectChanges();
      
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('bg-gray-100');
      expect(classes).toContain('text-gray-900');
    });

    it('should apply ghost variant classes', () => {
      fixture.componentRef.setInput('variant', 'ghost');
      fixture.detectChanges();
      
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('text-gray-700');
      expect(classes).toContain('hover:bg-gray-100');
    });

    it('should apply link variant classes', () => {
      fixture.componentRef.setInput('variant', 'link');
      fixture.detectChanges();
      
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('text-blue-600');
      expect(classes).toContain('underline-offset-4');
    });
  });

  describe('Sizes', () => {
    it('should apply default size classes', () => {
      fixture.componentRef.setInput('size', 'default');
      fixture.detectChanges();
      
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('h-9');
      expect(classes).toContain('px-4');
    });

    it('should apply small size classes', () => {
      fixture.componentRef.setInput('size', 'sm');
      fixture.detectChanges();
      
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('h-8');
      expect(classes).toContain('px-3');
    });

    it('should apply large size classes', () => {
      fixture.componentRef.setInput('size', 'lg');
      fixture.detectChanges();
      
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('h-10');
      expect(classes).toContain('px-6');
    });

    it('should apply icon size classes', () => {
      fixture.componentRef.setInput('size', 'icon');
      fixture.detectChanges();
      
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('h-9');
      expect(classes).toContain('w-9');
    });
  });

  describe('States', () => {
    it('should be enabled by default', () => {
      expect(buttonElement.nativeElement.disabled).toBe(false);
    });

    it('should be disabled when disabled input is true', () => {
      fixture.componentRef.setInput('disabled', true);
      fixture.detectChanges();
      
      expect(buttonElement.nativeElement.disabled).toBe(true);
      expect(component.isDisabled()).toBe(true);
    });

    it('should be disabled when loading input is true', () => {
      fixture.componentRef.setInput('loading', true);
      fixture.detectChanges();
      
      expect(buttonElement.nativeElement.disabled).toBe(true);
      expect(component.isDisabled()).toBe(true);
    });

    it('should show loading spinner when loading', () => {
      fixture.componentRef.setInput('loading', true);
      fixture.detectChanges();
      
      const spinner = fixture.debugElement.query(By.css('svg.animate-spin'));
      expect(spinner).toBeTruthy();
    });

    it('should not show loading spinner when not loading', () => {
      fixture.componentRef.setInput('loading', false);
      fixture.detectChanges();
      
      const spinner = fixture.debugElement.query(By.css('svg.animate-spin'));
      expect(spinner).toBeFalsy();
    });

    it('should apply full width class when fullWidth is true', () => {
      fixture.componentRef.setInput('fullWidth', true);
      fixture.detectChanges();
      
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('w-full');
    });

    it('should not apply full width class when fullWidth is false', () => {
      fixture.componentRef.setInput('fullWidth', false);
      fixture.detectChanges();
      
      const classes = buttonElement.nativeElement.className;
      expect(classes).not.toContain('w-full');
    });
  });

  describe('Button Type', () => {
    it('should have button type by default', () => {
      expect(buttonElement.nativeElement.type).toBe('button');
    });

    it('should apply submit type', () => {
      fixture.componentRef.setInput('type', 'submit');
      fixture.detectChanges();
      
      expect(buttonElement.nativeElement.type).toBe('submit');
    });

    it('should apply reset type', () => {
      fixture.componentRef.setInput('type', 'reset');
      fixture.detectChanges();
      
      expect(buttonElement.nativeElement.type).toBe('reset');
    });
  });

  describe('Accessibility', () => {
    it('should have base accessibility classes', () => {
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('outline-none');
      expect(classes).toContain('focus-visible:ring-2');
    });

    it('should apply aria-label when provided', () => {
      const ariaLabel = 'Submit form';
      fixture.componentRef.setInput('ariaLabel', ariaLabel);
      fixture.detectChanges();
      
      expect(buttonElement.nativeElement.getAttribute('aria-label')).toBe(ariaLabel);
    });

    it('should not have aria-label when not provided', () => {
      expect(buttonElement.nativeElement.getAttribute('aria-label')).toBeNull();
    });

    it('should set aria-busy to true when loading', () => {
      fixture.componentRef.setInput('loading', true);
      fixture.detectChanges();
      
      expect(buttonElement.nativeElement.getAttribute('aria-busy')).toBe('true');
    });

    it('should set aria-busy to false when not loading', () => {
      fixture.componentRef.setInput('loading', false);
      fixture.detectChanges();
      
      expect(buttonElement.nativeElement.getAttribute('aria-busy')).toBe('false');
    });

    it('should set aria-disabled when disabled', () => {
      fixture.componentRef.setInput('disabled', true);
      fixture.detectChanges();
      
      expect(buttonElement.nativeElement.getAttribute('aria-disabled')).toBe('true');
    });

    it('should set aria-disabled when loading', () => {
      fixture.componentRef.setInput('loading', true);
      fixture.detectChanges();
      
      expect(buttonElement.nativeElement.getAttribute('aria-disabled')).toBe('true');
    });

    it('should be keyboard accessible', () => {
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('focus-visible:ring-2');
      expect(classes).toContain('focus-visible:ring-offset-2');
    });
  });

  describe('CSS Classes', () => {
    it('should have base transition classes', () => {
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('transition-all');
    });

    it('should have flex layout classes', () => {
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('inline-flex');
      expect(classes).toContain('items-center');
      expect(classes).toContain('justify-center');
    });

    it('should have typography classes', () => {
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('text-sm');
      expect(classes).toContain('font-medium');
    });

    it('should have disabled state classes', () => {
      const classes = buttonElement.nativeElement.className;
      expect(classes).toContain('disabled:pointer-events-none');
      expect(classes).toContain('disabled:opacity-50');
    });
  });

  describe('Computed Properties', () => {
    it('should compute button classes correctly', () => {
      fixture.componentRef.setInput('variant', 'default');
      fixture.componentRef.setInput('size', 'lg');
      fixture.componentRef.setInput('fullWidth', true);
      fixture.detectChanges();
      
      const classes = component.buttonClasses();
      expect(classes).toContain('bg-blue-600');
      expect(classes).toContain('h-10');
      expect(classes).toContain('w-full');
    });

    it('should compute isDisabled correctly when disabled', () => {
      fixture.componentRef.setInput('disabled', true);
      fixture.detectChanges();
      
      expect(component.isDisabled()).toBe(true);
    });

    it('should compute isDisabled correctly when loading', () => {
      fixture.componentRef.setInput('loading', true);
      fixture.detectChanges();
      
      expect(component.isDisabled()).toBe(true);
    });

    it('should compute isDisabled correctly when both disabled and loading', () => {
      fixture.componentRef.setInput('disabled', true);
      fixture.componentRef.setInput('loading', true);
      fixture.detectChanges();
      
      expect(component.isDisabled()).toBe(true);
    });

    it('should compute isDisabled as false when neither disabled nor loading', () => {
      fixture.componentRef.setInput('disabled', false);
      fixture.componentRef.setInput('loading', false);
      fixture.detectChanges();
      
      expect(component.isDisabled()).toBe(false);
    });
  });

  describe('Edge Cases', () => {
    it('should handle multiple variant and size combinations', () => {
      const combinations = [
        { variant: 'default' as const, size: 'sm' as const },
        { variant: 'destructive' as const, size: 'lg' as const },
        { variant: 'outline' as const, size: 'icon' as const },
        { variant: 'ghost' as const, size: 'default' as const }
      ];

      combinations.forEach(({ variant, size }) => {
        fixture.componentRef.setInput('variant', variant);
        fixture.componentRef.setInput('size', size);
        fixture.detectChanges();
        
        expect(buttonElement.nativeElement).toBeTruthy();
        expect(component.buttonClasses()).toBeTruthy();
      });
    });

    it('should handle rapid state changes', () => {
      fixture.componentRef.setInput('loading', true);
      fixture.detectChanges();
      expect(component.isDisabled()).toBe(true);

      fixture.componentRef.setInput('loading', false);
      fixture.detectChanges();
      expect(component.isDisabled()).toBe(false);

      fixture.componentRef.setInput('disabled', true);
      fixture.detectChanges();
      expect(component.isDisabled()).toBe(true);
    });
  });
});

// Made with Bob
