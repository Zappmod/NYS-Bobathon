import { Component, input, computed, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Card elevation levels (Material UI Paper elevation)
 */
export type CardElevation = 0 | 1 | 2 | 3 | 4 | 6 | 8 | 12 | 16 | 24;

/**
 * Card padding variants
 */
export type CardPadding = 'none' | 'sm' | 'md' | 'lg';

/**
 * Card border radius variants
 */
export type CardRadius = 'none' | 'sm' | 'md' | 'lg' | 'xl';

/**
 * Reusable Card Component
 * 
 * A flexible container component that provides elevation, padding, and border radius
 * variants. Matches Material UI Paper component styling from the prototype.
 * 
 * @example
 * ```html
 * <app-card [elevation]="8" [padding]="'lg'" [radius]="'md'">
 *   <h2>Card Title</h2>
 *   <p>Card content goes here</p>
 * </app-card>
 * ```
 */
@Component({
  selector: 'app-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './card.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CardComponent {
  /**
   * Elevation level (shadow depth)
   * Matches Material UI Paper elevation prop
   */
  elevation = input<CardElevation>(1);

  /**
   * Padding variant
   */
  padding = input<CardPadding>('md');

  /**
   * Border radius variant
   */
  radius = input<CardRadius>('md');

  /**
   * Additional CSS classes
   */
  class = input<string>('');

  /**
   * Computed CSS classes based on elevation, padding, and radius
   */
  cardClasses = computed(() => {
    const classes: string[] = [
      'bg-white',
      'border',
      'border-gray-200'
    ];

    // Elevation (shadow) classes
    const elevationClasses: Record<CardElevation, string> = {
      0: 'shadow-none',
      1: 'shadow-sm',
      2: 'shadow',
      3: 'shadow-md',
      4: 'shadow-md',
      6: 'shadow-lg',
      8: 'shadow-xl',
      12: 'shadow-2xl',
      16: 'shadow-2xl',
      24: 'shadow-2xl'
    };

    classes.push(elevationClasses[this.elevation()]);

    // Padding classes
    const paddingClasses: Record<CardPadding, string> = {
      none: 'p-0',
      sm: 'p-4',
      md: 'p-6',
      lg: 'p-8'
    };

    classes.push(paddingClasses[this.padding()]);

    // Border radius classes
    const radiusClasses: Record<CardRadius, string> = {
      none: 'rounded-none',
      sm: 'rounded-sm',
      md: 'rounded-md',
      lg: 'rounded-lg',
      xl: 'rounded-xl'
    };

    classes.push(radiusClasses[this.radius()]);

    // Custom classes
    if (this.class()) {
      classes.push(this.class());
    }

    return classes.join(' ');
  });
}

// Made with Bob
