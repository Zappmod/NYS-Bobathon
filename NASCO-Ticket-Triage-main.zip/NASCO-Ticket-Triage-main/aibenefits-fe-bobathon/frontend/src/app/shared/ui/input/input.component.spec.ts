import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { InputComponent } from './input.component';

describe('InputComponent', () => {
  let component: InputComponent;
  let fixture: ComponentFixture<InputComponent>;
  let inputElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InputComponent, ReactiveFormsModule]
    }).compileComponents();

    fixture = TestBed.createComponent(InputComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('id', 'test-input');
    fixture.detectChanges();
    inputElement = fixture.debugElement.query(By.css('input'));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Rendering', () => {
    it('should render input element', () => {
      expect(inputElement).toBeTruthy();
      expect(inputElement.nativeElement.tagName).toBe('INPUT');
    });

    it('should set input id', () => {
      expect(inputElement.nativeElement.id).toBe('test-input');
    });

    it('should render label when provided', () => {
      fixture.componentRef.setInput('label', 'Email Address');
      fixture.detectChanges();
      
      const label = fixture.debugElement.query(By.css('app-label'));
      expect(label).toBeTruthy();
    });

    it('should not render label when not provided', () => {
      const label = fixture.debugElement.query(By.css('app-label'));
      expect(label).toBeFalsy();
    });
  });

  describe('Input Types', () => {
    it('should default to text type', () => {
      expect(inputElement.nativeElement.type).toBe('text');
    });

    it('should support email type', () => {
      fixture.componentRef.setInput('type', 'email');
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.type).toBe('email');
    });

    it('should support password type', () => {
      fixture.componentRef.setInput('type', 'password');
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.type).toBe('password');
    });

    it('should support number type', () => {
      fixture.componentRef.setInput('type', 'number');
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.type).toBe('number');
    });

    it('should support tel type', () => {
      fixture.componentRef.setInput('type', 'tel');
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.type).toBe('tel');
    });
  });

  describe('Placeholder', () => {
    it('should not have placeholder by default', () => {
      expect(inputElement.nativeElement.placeholder).toBe('');
    });

    it('should set placeholder when provided', () => {
      fixture.componentRef.setInput('placeholder', 'Enter your email');
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.placeholder).toBe('Enter your email');
    });
  });

  describe('Required State', () => {
    it('should not be required by default', () => {
      expect(inputElement.nativeElement.required).toBe(false);
    });

    it('should be required when set', () => {
      fixture.componentRef.setInput('required', true);
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.required).toBe(true);
    });

    it('should show required indicator in label', () => {
      fixture.componentRef.setInput('label', 'Email');
      fixture.componentRef.setInput('required', true);
      fixture.detectChanges();
      
      const requiredSpan = fixture.debugElement.query(By.css('span[aria-label="required"]'));
      expect(requiredSpan).toBeTruthy();
    });
  });

  describe('Disabled State', () => {
    it('should not be disabled by default', () => {
      expect(inputElement.nativeElement.disabled).toBe(false);
    });

    it('should be disabled when disabled input is true', () => {
      fixture.componentRef.setInput('disabled', true);
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.disabled).toBe(true);
    });

    it('should be disabled via setDisabledState', () => {
      component.setDisabledState(true);
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.disabled).toBe(true);
      expect(component.isDisabled()).toBe(true);
    });
  });

  describe('Auto-complete', () => {
    it('should default to off', () => {
      expect(inputElement.nativeElement.autocomplete).toBe('off');
    });

    it('should set autocomplete attribute', () => {
      fixture.componentRef.setInput('autoComplete', 'email');
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.autocomplete).toBe('email');
    });
  });

  describe('Size Variants', () => {
    it('should apply default size classes', () => {
      const classes = inputElement.nativeElement.className;
      expect(classes).toContain('h-9');
    });

    it('should apply small size classes', () => {
      fixture.componentRef.setInput('size', 'small');
      fixture.detectChanges();
      
      const classes = inputElement.nativeElement.className;
      expect(classes).toContain('h-8');
      expect(classes).toContain('text-sm');
    });
  });

  describe('Full Width', () => {
    it('should be full width by default', () => {
      expect(component.fullWidth()).toBe(true);
    });

    it('should apply max-width when not full width', () => {
      fixture.componentRef.setInput('fullWidth', false);
      fixture.detectChanges();
      
      const classes = inputElement.nativeElement.className;
      expect(classes).toContain('max-w-md');
    });
  });

  describe('Error Handling', () => {
    it('should not show error by default', () => {
      const errorDiv = fixture.debugElement.query(By.css('[role="alert"]'));
      expect(errorDiv).toBeFalsy();
    });

    it('should not show error when not touched', () => {
      fixture.componentRef.setInput('error', 'This field is required');
      fixture.detectChanges();
      
      const errorDiv = fixture.debugElement.query(By.css('[role="alert"]'));
      expect(errorDiv).toBeFalsy();
    });

    it('should show error when touched and error exists', () => {
      fixture.componentRef.setInput('error', 'This field is required');
      component.isTouched.set(true);
      fixture.detectChanges();
      
      const errorDiv = fixture.debugElement.query(By.css('[role="alert"]'));
      expect(errorDiv).toBeTruthy();
      expect(errorDiv.nativeElement.textContent.trim()).toBe('This field is required');
    });

    it('should apply error styling when error exists', () => {
      fixture.componentRef.setInput('error', 'Invalid email');
      component.isTouched.set(true);
      fixture.detectChanges();
      
      const classes = inputElement.nativeElement.className;
      expect(classes).toContain('border-red-500');
    });

    it('should have error id for aria-describedby', () => {
      fixture.componentRef.setInput('error', 'Error message');
      component.isTouched.set(true);
      fixture.detectChanges();
      
      const errorDiv = fixture.debugElement.query(By.css('[role="alert"]'));
      expect(errorDiv.nativeElement.id).toBe('test-input-error');
      expect(inputElement.nativeElement.getAttribute('aria-describedby')).toBe('test-input-error');
    });
  });

  describe('ControlValueAccessor', () => {
    it('should write value', () => {
      component.writeValue('test@example.com');
      expect(component.value()).toBe('test@example.com');
    });

    it('should write empty string for null value', () => {
      component.writeValue(null as any);
      expect(component.value()).toBe('');
    });

    it('should call onChange when input changes', () => {
      const onChangeSpy = jasmine.createSpy('onChange');
      component.registerOnChange(onChangeSpy);
      
      inputElement.nativeElement.value = 'new value';
      inputElement.nativeElement.dispatchEvent(new Event('input'));
      
      expect(onChangeSpy).toHaveBeenCalledWith('new value');
    });

    it('should call onTouched when input blurs', () => {
      const onTouchedSpy = jasmine.createSpy('onTouched');
      component.registerOnTouched(onTouchedSpy);
      
      inputElement.nativeElement.dispatchEvent(new Event('blur'));
      
      expect(onTouchedSpy).toHaveBeenCalled();
    });

    it('should set touched state on blur', () => {
      expect(component.isTouched()).toBe(false);
      
      inputElement.nativeElement.dispatchEvent(new Event('blur'));
      
      expect(component.isTouched()).toBe(true);
    });

    it('should update internal value on input', () => {
      inputElement.nativeElement.value = 'test value';
      inputElement.nativeElement.dispatchEvent(new Event('input'));
      
      expect(component.value()).toBe('test value');
    });
  });

  describe('Reactive Forms Integration', () => {
    it('should work with FormControl', () => {
      const control = new FormControl('initial value');
      
      component.writeValue(control.value);
      expect(component.value()).toBe('initial value');
      
      component.registerOnChange((value) => control.setValue(value));
      
      inputElement.nativeElement.value = 'updated value';
      inputElement.nativeElement.dispatchEvent(new Event('input'));
      
      expect(control.value).toBe('updated value');
    });
  });

  describe('Accessibility', () => {
    it('should have aria-label from input', () => {
      fixture.componentRef.setInput('ariaLabel', 'Email input field');
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.getAttribute('aria-label')).toBe('Email input field');
    });

    it('should use label as aria-label when ariaLabel not provided', () => {
      fixture.componentRef.setInput('label', 'Email Address');
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.getAttribute('aria-label')).toBe('Email Address');
    });

    it('should set aria-required when required', () => {
      fixture.componentRef.setInput('required', true);
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.getAttribute('aria-required')).toBe('true');
    });

    it('should set aria-invalid when error exists', () => {
      fixture.componentRef.setInput('error', 'Error');
      component.isTouched.set(true);
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.getAttribute('aria-invalid')).toBe('true');
    });

    it('should not set aria-invalid when no error', () => {
      expect(inputElement.nativeElement.getAttribute('aria-invalid')).toBe('false');
    });

    it('should link error message with aria-describedby', () => {
      fixture.componentRef.setInput('error', 'Error message');
      component.isTouched.set(true);
      fixture.detectChanges();
      
      expect(inputElement.nativeElement.getAttribute('aria-describedby')).toBe('test-input-error');
    });
  });

  describe('CSS Classes', () => {
    it('should have base input classes', () => {
      const classes = inputElement.nativeElement.className;
      expect(classes).toContain('flex');
      expect(classes).toContain('w-full');
      expect(classes).toContain('rounded-md');
      expect(classes).toContain('border');
      expect(classes).toContain('px-3');
      expect(classes).toContain('py-1');
    });

    it('should have transition classes', () => {
      const classes = inputElement.nativeElement.className;
      expect(classes).toContain('transition-all');
    });

    it('should have disabled state classes', () => {
      const classes = inputElement.nativeElement.className;
      expect(classes).toContain('disabled:pointer-events-none');
      expect(classes).toContain('disabled:cursor-not-allowed');
      expect(classes).toContain('disabled:opacity-50');
    });

    it('should apply custom classes to wrapper', () => {
      fixture.componentRef.setInput('class', 'custom-wrapper-class');
      fixture.detectChanges();
      
      const wrapper = fixture.debugElement.query(By.css('div'));
      expect(wrapper.nativeElement.className).toContain('custom-wrapper-class');
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty string value', () => {
      component.writeValue('');
      expect(component.value()).toBe('');
    });

    it('should handle rapid value changes', () => {
      component.writeValue('value1');
      expect(component.value()).toBe('value1');
      
      component.writeValue('value2');
      expect(component.value()).toBe('value2');
      
      component.writeValue('value3');
      expect(component.value()).toBe('value3');
    });

    it('should handle special characters in value', () => {
      const specialValue = 'test@example.com!#$%';
      component.writeValue(specialValue);
      expect(component.value()).toBe(specialValue);
    });

    it('should handle multiple blur events', () => {
      const onTouchedSpy = jasmine.createSpy('onTouched');
      component.registerOnTouched(onTouchedSpy);
      
      inputElement.nativeElement.dispatchEvent(new Event('blur'));
      inputElement.nativeElement.dispatchEvent(new Event('blur'));
      inputElement.nativeElement.dispatchEvent(new Event('blur'));
      
      expect(onTouchedSpy).toHaveBeenCalledTimes(3);
      expect(component.isTouched()).toBe(true);
    });
  });

  describe('Computed Properties', () => {
    it('should compute input classes correctly', () => {
      const classes = component.inputClasses();
      expect(classes).toContain('flex');
      expect(classes).toContain('w-full');
      expect(classes).toContain('border-gray-300');
    });

    it('should compute wrapper classes correctly', () => {
      const classes = component.wrapperClasses();
      expect(classes).toContain('mb-4');
      expect(classes).toContain('w-full');
    });

    it('should compute shouldShowError correctly', () => {
      expect(component.shouldShowError()).toBe(false);
      
      fixture.componentRef.setInput('error', 'Error');
      expect(component.shouldShowError()).toBe(false);
      
      component.isTouched.set(true);
      expect(component.shouldShowError()).toBe(true);
    });
  });
});

// Made with Bob
