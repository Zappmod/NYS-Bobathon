import { Component, input, output, effect, HostListener, OnInit, ElementRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { Product, NetworkTier } from '../../models/product.model';

/**
 * Product Form Modal Component
 * 
 * Modal form for creating new products or editing existing ones.
 * Uses reactive forms with dynamic network tier management.
 * 
 * @example
 * ```html
 * <app-product-form-modal 
 *   [open]="isModalOpen()"
 *   [product]="selectedProduct()"
 *   [mode]="formMode()"
 *   (close)="handleClose()"
 *   (save)="handleSave($event)">
 * </app-product-form-modal>
 * ```
 */
@Component({
  selector: 'app-product-form-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './product-form-modal.component.html',
})
export class ProductFormModalComponent implements OnInit {
  /**
   * Controls modal visibility
   */
  open = input.required<boolean>();

  /**
   * Product to edit (null for add mode)
   */
  product = input<Product | null>(null);

  /**
   * Form mode: 'add' or 'edit'
   */
  mode = input.required<'add' | 'edit'>();

  /**
   * Event emitted when modal should close
   */
  close = output<void>();

  /**
   * Event emitted when form is saved
   */
  save = output<Partial<Product>>();

  /**
   * Reactive form group
   */
  productForm!: FormGroup;

  /**
   * Show AI suggestion flag
   */
  showAISuggestion = false;

  /**
   * Configuration source visibility flag
   */
  showConfigSource = true;

  /**
   * Available categories
   */
  categories = ['Medical', 'Dental'];

  /**
   * Available classes
   */
  classes = [
    'Preferred Provider Organization (PPO) Plan',
    'Health Maintenance Organization (HMO) Plan',
    'High Deductible Health Plan (HDHP)',
  ];

  /**
   * Available states
   */
  states = [
    'Arkansas',
    'California',
    'Florida',
    'Georgia',
    'Illinois',
    'Massachusetts',
    'New York',
    'Ohio',
    'Texas',
    'Washington',
  ];

  private readonly elementRef = inject(ElementRef<HTMLElement>);

  constructor(private fb: FormBuilder) {
    // Initialize form in constructor
    this.initializeForm();

    // Watch for product changes to populate form in edit mode
    effect(() => {
      const currentProduct = this.product();
      const currentMode = this.mode();
      
      if (currentProduct && currentMode === 'edit') {
        this.populateForm(currentProduct);
      } else if (currentMode === 'add') {
        this.resetForm();
      }
    });

    // Prevent body scroll when modal is open
    effect(() => {
      if (this.open()) {
        document.body.style.overflow = 'hidden';
      } else {
        document.body.style.overflow = '';
      }
    });

    effect(() => {
      if (this.open()) {
        queueMicrotask(() => this.focusFirstElement());
      }
    });
  }

  ngOnInit(): void {
    // Additional initialization if needed
  }

  /**
   * Initialize the reactive form
   */
  private initializeForm(): void {
    this.productForm = this.fb.group({
      name: ['', Validators.required],
      category: ['Medical', Validators.required],
      class: ['Preferred Provider Organization (PPO) Plan', Validators.required],
      state: ['Arkansas', Validators.required],
      planInternalId: [''],
      blid: [''],
      effectiveDate: [''],
      templateAvailability: ['No'],
      description: [''],
      documentName: [''],
      importFromDocument: ['No'],
      isConfigFromProduct: ['Yes'],
      configurationSource: [''],
      network: this.fb.array([this.createNetworkTier()]),
    });

    // Watch for name changes to show AI suggestion
    this.productForm.get('name')?.valueChanges.subscribe(value => {
      this.showAISuggestion = value && value.length > 3;
    });

    // Watch for config source radio to show/hide field
    this.productForm.get('isConfigFromProduct')?.valueChanges.subscribe(value => {
      this.showConfigSource = value === 'Yes';
    });
  }

  /**
   * Create a new network tier form group
   */
  private createNetworkTier(tier: NetworkTier = { tier: '', network: '' }): FormGroup {
    return this.fb.group({
      tier: [tier.tier],
      network: [tier.network],
    });
  }

  /**
   * Get network form array
   */
  get networkArray(): FormArray {
    return this.productForm.get('network') as FormArray;
  }

  /**
   * Add a new network tier row
   */
  addNetworkTier(): void {
    this.networkArray.push(this.createNetworkTier());
  }

  /**
   * Remove a network tier row
   */
  removeNetworkTier(index: number): void {
    if (this.networkArray.length > 1) {
      this.networkArray.removeAt(index);
    }
  }

  /**
   * Populate form with product data in edit mode
   */
  private populateForm(product: Product): void {
    // Clear existing network tiers
    while (this.networkArray.length > 0) {
      this.networkArray.removeAt(0);
    }

    // Add network tiers from product
    if (product.network && product.network.length > 0) {
      product.network.forEach(tier => {
        this.networkArray.push(this.createNetworkTier(tier));
      });
    } else {
      this.networkArray.push(this.createNetworkTier());
    }

    // Populate form values
    this.productForm.patchValue({
      name: product.name,
      category: product.category,
      class: product.class,
      state: product.state,
      planInternalId: product.planInternalId,
      blid: product.blid,
      effectiveDate: this.formatDateToDisplay(product.effectiveDate),
      templateAvailability: product.templateAvailability,
      description: product.description,
      documentName: product.documentName,
      configurationSource: product.configurationSource,
      isConfigFromProduct: product.configurationSource ? 'Yes' : 'No',
    });
  }

  /**
   * Reset form to initial state
   */
  private resetForm(): void {
    this.productForm.reset({
      name: '',
      category: 'Medical',
      class: 'Preferred Provider Organization (PPO) Plan',
      state: 'Arkansas',
      planInternalId: '',
      blid: '',
      effectiveDate: '',
      templateAvailability: 'No',
      description: '',
      documentName: '',
      importFromDocument: 'No',
      isConfigFromProduct: 'Yes',
      configurationSource: '',
    });

    // Reset network array to single row
    while (this.networkArray.length > 0) {
      this.networkArray.removeAt(0);
    }
    this.networkArray.push(this.createNetworkTier());
    
    this.showAISuggestion = false;
  }

  /**
   * Format date from YYYY-MM-DD to MM/DD/YYYY for display
   */
  private formatDateToDisplay(dateStr: string): string {
    if (!dateStr) return '';
    
    // If already in MM/DD/YYYY format, return as is
    if (dateStr.includes('/')) return dateStr;
    
    // Convert YYYY-MM-DD to MM/DD/YYYY
    const date = new Date(dateStr + 'T00:00:00');
    if (isNaN(date.getTime())) return dateStr;
    
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();
    
    return `${month}/${day}/${year}`;
  }

  /**
   * Format date from MM/DD/YYYY to YYYY-MM-DD for storage
   */
  private formatDateToStore(dateStr: string): string {
    if (!dateStr) return '';
    
    // If already in YYYY-MM-DD format, return as is
    if (dateStr.match(/^\d{4}-\d{2}-\d{2}$/)) return dateStr;
    
    // Convert MM/DD/YYYY to YYYY-MM-DD
    const parts = dateStr.split('/');
    if (parts.length !== 3) return dateStr;
    
    const [month, day, year] = parts;
    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
  }

  /**
   * Handle Escape key to close modal
   */
  @HostListener('document:keydown.escape')
  onEscapeKey(): void {
    if (this.open()) {
      this.onClose();
    }
  }

  /**
   * Trap focus inside the open modal
   */
  @HostListener('document:keydown.tab', ['$event'])
  onTabKey(event: KeyboardEvent): void {
    if (!this.open()) {
      return;
    }

    const focusableElements = this.getFocusableElements();
    if (focusableElements.length === 0) {
      return;
    }

    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];
    const activeElement = document.activeElement as HTMLElement | null;

    if (event.shiftKey && activeElement === firstElement) {
      event.preventDefault();
      lastElement.focus();
      return;
    }

    if (!event.shiftKey && activeElement === lastElement) {
      event.preventDefault();
      firstElement.focus();
    }
  }

  /**
   * Handle modal close
   */
  onClose(): void {
    this.close.emit();
    this.showAISuggestion = false;
  }

  /**
   * Handle backdrop click to close modal
   */
  onBackdropClick(): void {
    this.onClose();
  }

  /**
   * Prevent modal content click from closing modal
   */
  onModalClick(event: Event): void {
    event.stopPropagation();
  }

  /**
   * Handle form submission
   */
  onSubmit(): void {
    if (this.productForm.valid) {
      const formValue = this.productForm.value;
      
      // Convert date to storage format
      const productData: Partial<Product> = {
        ...formValue,
        effectiveDate: this.formatDateToStore(formValue.effectiveDate),
        // Remove fields that shouldn't be saved
        importFromDocument: undefined,
        isConfigFromProduct: undefined,
      };

      // Clean up configuration source if not from product
      if (formValue.isConfigFromProduct !== 'Yes') {
        productData.configurationSource = '';
      }

      this.save.emit(productData);
      this.onClose();
    }
  }

  /**
   * Check if form is valid
   */
  isFormValid(): boolean {
    return this.productForm.valid && this.networkArray.length > 0;
  }

  /**
   * Get focusable elements within the modal
   */
  private getFocusableElements(): HTMLElement[] {
    const hostElement = this.elementRef.nativeElement;
    const modalRoot = hostElement.querySelector('[data-testid="product-form-modal"]');

    if (!modalRoot) {
      return [];
    }

    return Array.from(
      modalRoot.querySelectorAll(
        'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
      )
    ).filter((element): element is HTMLElement => element instanceof HTMLElement && !element.hasAttribute('disabled'));
  }

  /**
   * Focus the first interactive element when the modal opens
   */
  private focusFirstElement(): void {
    const firstElement = this.getFocusableElements()[0];
    firstElement?.focus();
  }

  /**
   * Get form control error message
   */
  getErrorMessage(controlName: string): string {
    const control = this.productForm.get(controlName);
    if (control?.hasError('required')) {
      return 'This field is required';
    }
    return '';
  }
}

// Made with Bob