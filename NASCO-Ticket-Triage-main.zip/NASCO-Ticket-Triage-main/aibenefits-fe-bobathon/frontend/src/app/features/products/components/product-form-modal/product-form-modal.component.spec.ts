import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { ProductFormModalComponent } from './product-form-modal.component';
import { Product } from '../../models/product.model';
import { By } from '@angular/platform-browser';

describe('ProductFormModalComponent', () => {
  let component: ProductFormModalComponent;
  let fixture: ComponentFixture<ProductFormModalComponent>;

  const mockProduct: Product = {
    id: '1',
    name: 'Premier Health Advantage',
    category: 'Medical',
    class: 'Health Maintenance Organization (HMO) Plan',
    templateAvailability: 'Yes',
    status: 'Configure',
    planId: '11CDZ',
    blid: 'BL001',
    lastUpdatedBy: 'BENTEST120',
    lastUpdatedOn: '12/15/2024',
    effectiveDate: '2025-01-01',
    documentName: 'Premier_Health_Doc',
    state: 'California',
    network: [
      { tier: 'Tier 1', network: 'Blue Shield INN' },
      { tier: 'Tier 2', network: 'Blue Shield OON' },
    ],
    planInternalId: 'PHA-2025-CA',
    description: 'Comprehensive HMO plan',
    configurationSource: 'Manual Configuration',
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductFormModalComponent, ReactiveFormsModule],
    }).compileComponents();

    fixture = TestBed.createComponent(ProductFormModalComponent);
    component = fixture.componentInstance;
  });

  describe('Component Initialization', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should be a standalone component', () => {
      const metadata = (ProductFormModalComponent as any).ɵcmp;
      expect(metadata.standalone).toBe(true);
    });

    it('should have required open input', () => {
      expect(component.open).toBeDefined();
    });

    it('should have product input', () => {
      expect(component.product).toBeDefined();
    });

    it('should have required mode input', () => {
      expect(component.mode).toBeDefined();
    });

    it('should have close output', () => {
      expect(component.close).toBeDefined();
    });

    it('should have save output', () => {
      expect(component.save).toBeDefined();
    });

    it('should initialize form with default values', () => {
      expect(component.productForm).toBeDefined();
      expect(component.productForm.get('category')?.value).toBe('Medical');
      expect(component.productForm.get('templateAvailability')?.value).toBe('No');
      expect(component.productForm.get('isConfigFromProduct')?.value).toBe('Yes');
    });

    it('should have one network tier by default', () => {
      expect(component.networkArray.length).toBe(1);
    });
  });

  describe('Modal Visibility', () => {
    it('should not render modal when open is false', () => {
      fixture.componentRef.setInput('open', false);
      fixture.componentRef.setInput('mode', 'add');
      fixture.detectChanges();

      const modal = fixture.debugElement.query(By.css('[role="dialog"]'));
      expect(modal).toBeNull();
    });

    it('should render modal when open is true', () => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'add');
      fixture.detectChanges();

      const modal = fixture.debugElement.query(By.css('[role="dialog"]'));
      expect(modal).toBeTruthy();
    });
  });

  describe('Form Initialization - Add Mode', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'add');
      fixture.componentRef.setInput('product', null);
      fixture.detectChanges();
    });

    it('should display "New Product" title in add mode', () => {
      const title = fixture.debugElement.query(By.css('h2'));
      expect(title.nativeElement.textContent.trim()).toBe('New Product');
    });

    it('should have empty name field', () => {
      expect(component.productForm.get('name')?.value).toBe('');
    });

    it('should have default category', () => {
      expect(component.productForm.get('category')?.value).toBe('Medical');
    });

    it('should have default state', () => {
      expect(component.productForm.get('state')?.value).toBe('Arkansas');
    });

    it('should display "Create Product" button text', () => {
      const submitButton = fixture.debugElement.query(By.css('button[type="submit"]'));
      expect(submitButton.nativeElement.textContent.trim()).toBe('Create Product');
    });
  });

  describe('Form Initialization - Edit Mode', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'edit');
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();
    });

    it('should display product name as title in edit mode', () => {
      const title = fixture.debugElement.query(By.css('h2'));
      expect(title.nativeElement.textContent.trim()).toBe(mockProduct.name);
    });

    it('should populate form with product data', () => {
      expect(component.productForm.get('name')?.value).toBe(mockProduct.name);
      expect(component.productForm.get('category')?.value).toBe(mockProduct.category);
      expect(component.productForm.get('class')?.value).toBe(mockProduct.class);
      expect(component.productForm.get('state')?.value).toBe(mockProduct.state);
    });

    it('should populate network tiers from product', () => {
      expect(component.networkArray.length).toBe(2);
      expect(component.networkArray.at(0).get('tier')?.value).toBe('Tier 1');
      expect(component.networkArray.at(0).get('network')?.value).toBe('Blue Shield INN');
    });

    it('should convert date to display format', () => {
      const effectiveDate = component.productForm.get('effectiveDate')?.value;
      expect(effectiveDate).toBe('01/01/2025');
    });

    it('should display "Save" button text', () => {
      const submitButton = fixture.debugElement.query(By.css('button[type="submit"]'));
      expect(submitButton.nativeElement.textContent.trim()).toBe('Save');
    });
  });

  describe('Form Fields Rendering', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'add');
      fixture.detectChanges();
    });

    it('should render product name input', () => {
      const input = fixture.debugElement.query(By.css('#name'));
      expect(input).toBeTruthy();
    });

    it('should render category dropdown', () => {
      const select = fixture.debugElement.query(By.css('#category'));
      expect(select).toBeTruthy();
      const options = select.queryAll(By.css('option'));
      expect(options.length).toBe(3);
    });

    it('should render class dropdown', () => {
      const select = fixture.debugElement.query(By.css('#class'));
      expect(select).toBeTruthy();
      const options = select.queryAll(By.css('option'));
      expect(options.length).toBe(3);
    });

    it('should render state dropdown', () => {
      const select = fixture.debugElement.query(By.css('#state'));
      expect(select).toBeTruthy();
      const options = select.queryAll(By.css('option'));
      expect(options.length).toBe(10);
    });

    it('should render description textarea', () => {
      const textarea = fixture.debugElement.query(By.css('#description'));
      expect(textarea).toBeTruthy();
      expect(textarea.nativeElement.rows).toBe(3);
    });

    it('should render template availability radio buttons', () => {
      const radios = fixture.debugElement.queryAll(By.css('input[formControlName="templateAvailability"]'));
      expect(radios.length).toBe(2);
    });

    it('should render configuration source radio buttons', () => {
      const radios = fixture.debugElement.queryAll(By.css('input[formControlName="isConfigFromProduct"]'));
      expect(radios.length).toBe(2);
    });
  });

  describe('AI Suggestion Feature', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'add');
      fixture.detectChanges();
    });

    it('should not show AI suggestion initially', () => {
      expect(component.showAISuggestion).toBe(false);
      const suggestion = fixture.debugElement.query(By.css('.bg-blue-50'));
      expect(suggestion).toBeNull();
    });

    it('should not show AI suggestion for short names', () => {
      component.productForm.get('name')?.setValue('ABC');
      fixture.detectChanges();
      
      expect(component.showAISuggestion).toBe(false);
    });

    it('should show AI suggestion when name > 3 characters', () => {
      component.productForm.get('name')?.setValue('Test Product');
      fixture.detectChanges();
      
      expect(component.showAISuggestion).toBe(true);
      const suggestion = fixture.debugElement.query(By.css('.bg-blue-50'));
      expect(suggestion).toBeTruthy();
    });

    it('should display correct AI suggestion text', () => {
      component.productForm.get('name')?.setValue('Test Product');
      fixture.detectChanges();
      
      const suggestion = fixture.debugElement.query(By.css('.bg-blue-50'));
      expect(suggestion.nativeElement.textContent).toContain('AI Suggestion');
      expect(suggestion.nativeElement.textContent).toContain('state abbreviation suffix');
    });
  });

  describe('Network Table Operations', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'add');
      fixture.detectChanges();
    });

    it('should render network table', () => {
      const table = fixture.debugElement.query(By.css('table'));
      expect(table).toBeTruthy();
    });

    it('should have table headers', () => {
      const headers = fixture.debugElement.queryAll(By.css('thead th'));
      expect(headers.length).toBe(3);
      expect(headers[0].nativeElement.textContent.trim()).toBe('Tier');
      expect(headers[1].nativeElement.textContent.trim()).toBe('Network');
    });

    it('should render one network row initially', () => {
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      expect(rows.length).toBe(1);
    });

    it('should add network tier when add button clicked', () => {
      const buttons = fixture.debugElement.queryAll(By.css('button[type="button"]'));
      // Find the Add button (contains "Add" text)
      const addButton = buttons.find(btn => btn.nativeElement.textContent.includes('Add'));
      expect(addButton).toBeTruthy();
      
      addButton!.nativeElement.click();
      fixture.detectChanges();
      
      expect(component.networkArray.length).toBe(2);
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      expect(rows.length).toBe(2);
    });

    it('should not show delete button when only one tier', () => {
      const deleteButtons = fixture.debugElement.queryAll(By.css('button[aria-label="Delete network tier"]'));
      expect(deleteButtons.length).toBe(0);
    });

    it('should show delete buttons when multiple tiers', () => {
      component.addNetworkTier();
      fixture.detectChanges();
      
      const deleteButtons = fixture.debugElement.queryAll(By.css('button[aria-label="Delete network tier"]'));
      expect(deleteButtons.length).toBe(2);
    });

    it('should remove network tier when delete clicked', () => {
      component.addNetworkTier();
      component.addNetworkTier();
      fixture.detectChanges();
      
      expect(component.networkArray.length).toBe(3);
      
      component.removeNetworkTier(1);
      fixture.detectChanges();
      
      expect(component.networkArray.length).toBe(2);
    });

    it('should not remove last network tier', () => {
      component.removeNetworkTier(0);
      expect(component.networkArray.length).toBe(1);
    });
  });

  describe('Configuration Source Visibility', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'add');
      fixture.detectChanges();
    });

    it('should show configuration source field by default', () => {
      expect(component.showConfigSource).toBe(true);
      const field = fixture.debugElement.query(By.css('#configurationSource'));
      expect(field).toBeTruthy();
    });

    it('should hide configuration source when "No" selected', () => {
      component.productForm.get('isConfigFromProduct')?.setValue('No');
      fixture.detectChanges();
      
      expect(component.showConfigSource).toBe(false);
      const field = fixture.debugElement.query(By.css('#configurationSource'));
      expect(field).toBeNull();
    });

    it('should show configuration source when "Yes" selected', () => {
      component.productForm.get('isConfigFromProduct')?.setValue('No');
      fixture.detectChanges();
      
      component.productForm.get('isConfigFromProduct')?.setValue('Yes');
      fixture.detectChanges();
      
      expect(component.showConfigSource).toBe(true);
      const field = fixture.debugElement.query(By.css('#configurationSource'));
      expect(field).toBeTruthy();
    });
  });

  describe('Form Validation', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'add');
      fixture.detectChanges();
    });

    it('should be invalid when required fields are empty', () => {
      expect(component.productForm.valid).toBe(false);
      expect(component.isFormValid()).toBe(false);
    });

    it('should be valid when required fields are filled', () => {
      component.productForm.patchValue({
        name: 'Test Product',
        category: 'Medical',
        class: 'Preferred Provider Organization (PPO) Plan',
        state: 'California',
      });
      
      expect(component.productForm.valid).toBe(true);
      expect(component.isFormValid()).toBe(true);
    });

    it('should show error message for required name field', () => {
      const nameControl = component.productForm.get('name');
      nameControl?.markAsTouched();
      fixture.detectChanges();
      
      const errorMessage = fixture.debugElement.query(By.css('.text-red-600'));
      expect(errorMessage).toBeTruthy();
      expect(errorMessage.nativeElement.textContent).toContain('required');
    });

    it('should disable submit button when form invalid', () => {
      fixture.detectChanges();
      
      const submitButton = fixture.debugElement.query(By.css('button[type="submit"]'));
      expect(submitButton.nativeElement.disabled).toBe(true);
    });

    it('should enable submit button when form valid', () => {
      component.productForm.patchValue({
        name: 'Test Product',
        category: 'Medical',
        class: 'Preferred Provider Organization (PPO) Plan',
        state: 'California',
      });
      fixture.detectChanges();
      
      const submitButton = fixture.debugElement.query(By.css('button[type="submit"]'));
      expect(submitButton.nativeElement.disabled).toBe(false);
    });
  });

  describe('Date Formatting', () => {
    it('should format YYYY-MM-DD to MM/DD/YYYY for display', () => {
      const formatted = (component as any).formatDateToDisplay('2025-01-15');
      expect(formatted).toBe('01/15/2025');
    });

    it('should return date as-is if already in MM/DD/YYYY format', () => {
      const formatted = (component as any).formatDateToDisplay('01/15/2025');
      expect(formatted).toBe('01/15/2025');
    });

    it('should return empty string for empty date', () => {
      const formatted = (component as any).formatDateToDisplay('');
      expect(formatted).toBe('');
    });

    it('should format MM/DD/YYYY to YYYY-MM-DD for storage', () => {
      const formatted = (component as any).formatDateToStore('01/15/2025');
      expect(formatted).toBe('2025-01-15');
    });

    it('should return date as-is if already in YYYY-MM-DD format', () => {
      const formatted = (component as any).formatDateToStore('2025-01-15');
      expect(formatted).toBe('2025-01-15');
    });

    it('should return empty string for empty date storage', () => {
      const formatted = (component as any).formatDateToStore('');
      expect(formatted).toBe('');
    });
  });

  describe('Form Submission', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'add');
      fixture.detectChanges();
    });

    it('should emit save event with form data', () => {
      const saveSpy = jest.spyOn(component.save, 'emit');
      
      component.productForm.patchValue({
        name: 'Test Product',
        category: 'Medical',
        class: 'Preferred Provider Organization (PPO) Plan',
        state: 'California',
        effectiveDate: '01/15/2025',
      });
      
      component.onSubmit();
      
      expect(saveSpy).toHaveBeenCalled();
      const emittedData = saveSpy.mock.calls[0][0];
      expect(emittedData.name).toBe('Test Product');
      expect(emittedData.effectiveDate).toBe('2025-01-15');
    });

    it('should not emit save event if form invalid', () => {
      const saveSpy = jest.spyOn(component.save, 'emit');
      
      component.onSubmit();
      
      expect(saveSpy).not.toHaveBeenCalled();
    });

    it('should close modal after successful save', () => {
      const closeSpy = jest.spyOn(component.close, 'emit');
      
      component.productForm.patchValue({
        name: 'Test Product',
        category: 'Medical',
        class: 'Preferred Provider Organization (PPO) Plan',
        state: 'California',
      });
      
      component.onSubmit();
      
      expect(closeSpy).toHaveBeenCalled();
    });

    it('should remove non-product fields from saved data', () => {
      const saveSpy = jest.spyOn(component.save, 'emit');
      
      component.productForm.patchValue({
        name: 'Test Product',
        category: 'Medical',
        class: 'Preferred Provider Organization (PPO) Plan',
        state: 'California',
        importFromDocument: 'Yes',
        isConfigFromProduct: 'No',
      });
      
      component.onSubmit();
      
      const emittedData = saveSpy.mock.calls[0][0] as any;
      expect(emittedData.importFromDocument).toBeUndefined();
      expect(emittedData.isConfigFromProduct).toBeUndefined();
    });

    it('should clear configuration source if not from product', () => {
      const saveSpy = jest.spyOn(component.save, 'emit');
      
      component.productForm.patchValue({
        name: 'Test Product',
        category: 'Medical',
        class: 'Preferred Provider Organization (PPO) Plan',
        state: 'California',
        isConfigFromProduct: 'No',
        configurationSource: 'Some source',
      });
      
      component.onSubmit();
      
      const emittedData = saveSpy.mock.calls[0][0];
      expect(emittedData.configurationSource).toBe('');
    });
  });

  describe('User Interactions', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'add');
      fixture.detectChanges();
    });

    it('should emit close event when close button clicked', () => {
      const closeSpy = jest.spyOn(component.close, 'emit');
      const closeButton = fixture.debugElement.query(By.css('button[aria-label="Close modal"]'));
      
      closeButton.nativeElement.click();
      
      expect(closeSpy).toHaveBeenCalled();
    });

    it('should emit close event when cancel button clicked', () => {
      const closeSpy = jest.spyOn(component.close, 'emit');
      const buttons = fixture.debugElement.queryAll(By.css('button[type="button"]'));
      // Find the Cancel button (contains "Cancel" text)
      const cancelButton = buttons.find(btn => btn.nativeElement.textContent.trim() === 'Cancel');
      expect(cancelButton).toBeTruthy();
      
      cancelButton!.nativeElement.click();
      
      expect(closeSpy).toHaveBeenCalled();
    });

    it('should emit close event when backdrop clicked', () => {
      const closeSpy = jest.spyOn(component.close, 'emit');
      const overlay = fixture.debugElement.query(By.css('.fixed.inset-0'));
      
      overlay.nativeElement.click();
      
      expect(closeSpy).toHaveBeenCalled();
    });

    it('should not emit close event when modal content clicked', () => {
      const closeSpy = jest.spyOn(component.close, 'emit');
      const modalContent = fixture.debugElement.query(By.css('[data-testid="product-form-modal"]'));
      
      modalContent.nativeElement.click();
      
      expect(closeSpy).not.toHaveBeenCalled();
    });

    it('should expose accessible validation state for the name field', () => {
      const nameControl = component.productForm.get('name');
      nameControl?.markAsTouched();
      fixture.detectChanges();

      const nameInput = fixture.debugElement.query(By.css('#name'));
      const errorMessage = fixture.debugElement.query(By.css('#name-error'));

      expect(nameInput.nativeElement.getAttribute('aria-describedby')).toBe('name-error');
      expect(nameInput.nativeElement.getAttribute('aria-invalid')).toBe('true');
      expect(errorMessage.nativeElement.getAttribute('role')).toBe('alert');
      expect(errorMessage.nativeElement.getAttribute('aria-live')).toBe('assertive');
    });

    it('should focus the first interactive element when the modal opens', async () => {
      fixture.componentRef.setInput('open', false);
      fixture.detectChanges();

      fixture.componentRef.setInput('open', true);
      fixture.detectChanges();
      await fixture.whenStable();

      const closeButton = fixture.debugElement.query(By.css('button[aria-label="Close modal"]')).nativeElement as HTMLButtonElement;
      expect(document.activeElement).toBe(closeButton);
    });

    it('should trap focus within the modal when tabbing forward from the last element', () => {
      const focusableElements = fixture.debugElement.queryAll(
        By.css('[data-testid="product-form-modal"] button, [data-testid="product-form-modal"] input, [data-testid="product-form-modal"] select, [data-testid="product-form-modal"] textarea')
      );

      const closeButton = fixture.debugElement.query(By.css('button[aria-label="Close modal"]')).nativeElement as HTMLElement;
      const lastFocusable = focusableElements[focusableElements.length - 1].nativeElement as HTMLElement;

      lastFocusable.focus();
      component.onTabKey(new KeyboardEvent('keydown', { key: 'Tab' }));

      expect(document.activeElement).toBe(closeButton);
    });

    it('should trap focus within the modal when tabbing backward from the first element', () => {
      const closeButton = fixture.debugElement.query(By.css('button[aria-label="Close modal"]')).nativeElement as HTMLElement;
      const cancelButton = fixture.debugElement
        .queryAll(By.css('button'))
        .find(button => button.nativeElement.textContent.trim() === 'Cancel')!
        .nativeElement as HTMLElement;

      closeButton.focus();
      component.onTabKey(new KeyboardEvent('keydown', { key: 'Tab', shiftKey: true }));

      expect(document.activeElement).toBe(cancelButton);
    });

    it('should close modal on Escape key', () => {
      const closeSpy = jest.spyOn(component.close, 'emit');
      
      const event = new KeyboardEvent('keydown', { key: 'Escape' });
      document.dispatchEvent(event);
      
      expect(closeSpy).toHaveBeenCalled();
    });

    it('should not close modal on Escape key when closed', () => {
      const closeSpy = jest.spyOn(component.close, 'emit');

      fixture.componentRef.setInput('open', false);
      fixture.detectChanges();

      const event = new KeyboardEvent('keydown', { key: 'Escape' });
      document.dispatchEvent(event);

      expect(closeSpy).not.toHaveBeenCalled();
    });

    it('should ignore tab trapping when modal is closed', () => {
      fixture.componentRef.setInput('open', false);
      fixture.detectChanges();

      expect(() => component.onTabKey(new KeyboardEvent('keydown', { key: 'Tab' }))).not.toThrow();
    });
  });

  describe('Component Methods', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'add');
      fixture.detectChanges();
    });

    it('should emit close and reset AI suggestion on onClose()', () => {
      const closeSpy = jest.spyOn(component.close, 'emit');
      component.showAISuggestion = true;

      component.onClose();

      expect(closeSpy).toHaveBeenCalled();
      expect(component.showAISuggestion).toBe(false);
    });

    it('should delegate backdrop clicks to onClose()', () => {
      const closeSpy = jest.spyOn(component, 'onClose');

      component.onBackdropClick();

      expect(closeSpy).toHaveBeenCalled();
    });

    it('should stop propagation on modal content click', () => {
      const stopPropagation = jest.fn();

      component.onModalClick({ stopPropagation } as unknown as Event);

      expect(stopPropagation).toHaveBeenCalled();
    });

    it('should return required field error message', () => {
      const nameControl = component.productForm.get('name');
      nameControl?.markAsTouched();

      expect(component.getErrorMessage('name')).toBe('This field is required');
    });

    it('should return empty error message when control has no errors', () => {
      component.productForm.get('name')?.setValue('Valid Product');

      expect(component.getErrorMessage('name')).toBe('');
    });
  });

  describe('Body Scroll Prevention', () => {
    it('should prevent body scroll when modal opens', () => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'add');
      fixture.detectChanges();

      expect(document.body.style.overflow).toBe('hidden');
    });

    it('should restore body scroll when modal closes', () => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'add');
      fixture.detectChanges();

      fixture.componentRef.setInput('open', false);
      fixture.detectChanges();

      expect(document.body.style.overflow).toBe('');
    });
  });

  describe('Responsive Layout', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('mode', 'add');
      fixture.detectChanges();
    });

    it('should have 2-column layout classes', () => {
      const container = fixture.debugElement.query(By.css('.grid.grid-cols-1.lg\\:grid-cols-2'));
      expect(container).toBeTruthy();
    });

    it('should have flex-1 on both columns', () => {
      const columns = fixture.debugElement.queryAll(By.css('.flex-1.space-y-4'));
      expect(columns.length).toBe(2);
    });
  });
});

// Made with Bob