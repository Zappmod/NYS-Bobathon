import { TestBed } from '@angular/core/testing';
import { ProductsService } from './products.service';
import { MOCK_PRODUCTS } from './products.mock';
import { Product } from '../models/product.model';

describe('ProductsService', () => {
  let service: ProductsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProductsService],
    });
    service = TestBed.inject(ProductsService);
    
    // Reset to initial state before each test
    service.resetProducts();
  });

  describe('Service Initialization', () => {
    it('should be created', () => {
      expect(service).toBeTruthy();
    });

    it('should be provided in root', () => {
      expect(service).toBeDefined();
    });
  });

  describe('getProducts()', () => {
    it('should return an Observable', (done) => {
      const result = service.getProducts();
      expect(result.subscribe).toBeDefined();
      done();
    });

    it('should return all products', (done) => {
      service.getProducts().subscribe(products => {
        expect(products).toBeDefined();
        expect(products.length).toBe(MOCK_PRODUCTS.length);
        done();
      });
    });

    it('should return a copy of products (immutability)', (done) => {
      service.getProducts().subscribe(products1 => {
        service.getProducts().subscribe(products2 => {
          expect(products1).not.toBe(products2); // Different array references
          expect(products1).toEqual(products2); // Same content
          done();
        });
      });
    });

    it('should simulate async with delay', (done) => {
      const startTime = Date.now();
      service.getProducts().subscribe(() => {
        const endTime = Date.now();
        const elapsed = endTime - startTime;
        expect(elapsed).toBeGreaterThanOrEqual(90); // Allow some margin
        done();
      });
    });

    it('should return products with all required fields', (done) => {
      service.getProducts().subscribe(products => {
        products.forEach(product => {
          expect(product.id).toBeDefined();
          expect(product.name).toBeDefined();
          expect(product.category).toBeDefined();
          expect(product.status).toBeDefined();
          expect(product.network).toBeDefined();
          expect(Array.isArray(product.network)).toBe(true);
        });
        done();
      });
    });
  });

  describe('getProductById()', () => {
    it('should return a product when ID exists', (done) => {
      const testId = '1';
      service.getProductById(testId).subscribe(product => {
        expect(product).toBeDefined();
        expect(product?.id).toBe(testId);
        expect(product?.name).toBe('Premier Health Advantage');
        done();
      });
    });

    it('should return null when ID does not exist', (done) => {
      service.getProductById('nonexistent-id').subscribe(product => {
        expect(product).toBeNull();
        done();
      });
    });

    it('should return a copy of the product (immutability)', (done) => {
      const testId = '1';
      service.getProductById(testId).subscribe(product1 => {
        service.getProductById(testId).subscribe(product2 => {
          expect(product1).not.toBe(product2); // Different object references
          expect(product1).toEqual(product2); // Same content
          done();
        });
      });
    });

    it('should simulate async with delay', (done) => {
      const startTime = Date.now();
      service.getProductById('1').subscribe(() => {
        const endTime = Date.now();
        const elapsed = endTime - startTime;
        expect(elapsed).toBeGreaterThanOrEqual(90);
        done();
      });
    });
  });

  describe('createProduct()', () => {
    it('should create a new product with generated ID', (done) => {
      const newProduct: Omit<Product, 'id'> = {
        name: 'Test Product',
        category: 'Dental',
        class: 'Test Class',
        templateAvailability: 'Yes',
        status: 'Draft',
        planId: 'TEST123',
        blid: 'TESTBLID',
        lastUpdatedBy: '',
        lastUpdatedOn: '',
        effectiveDate: '01/01/2027',
        documentName: 'Test_Doc',
        state: 'Test State',
        network: [{ tier: '1', network: 'INN' }],
        planInternalId: 'TEST_INTERNAL',
        description: 'Test description',
        configurationSource: 'Test source',
      };

      service.createProduct(newProduct).subscribe(created => {
        expect(created.id).toBeDefined();
        expect(created.id).toBe('11'); // Next ID after 10 mock products
        expect(created.name).toBe(newProduct.name);
        expect(created.category).toBe(newProduct.category);
        done();
      });
    });

    it('should update lastUpdatedBy and lastUpdatedOn', (done) => {
      const newProduct: Omit<Product, 'id'> = {
        name: 'Test Product',
        category: 'Vision',
        class: 'Test Class',
        templateAvailability: 'No',
        status: 'Configure',
        planId: '',
        blid: '',
        lastUpdatedBy: '',
        lastUpdatedOn: '',
        effectiveDate: '01/01/2027',
        documentName: '',
        state: 'Test State',
        network: [],
        planInternalId: 'TEST',
        description: 'Test',
        configurationSource: '',
      };

      service.createProduct(newProduct).subscribe(created => {
        expect(created.lastUpdatedBy).toBe('BENTEST120');
        expect(created.lastUpdatedOn).toMatch(/^\d{2}\/\d{2}\/\d{4}$/); // MM/DD/YYYY format
        done();
      });
    });

    it('should add product to the list', (done) => {
      const initialCount = MOCK_PRODUCTS.length;
      const newProduct: Omit<Product, 'id'> = {
        name: 'New Product',
        category: 'Medical',
        class: 'Test',
        templateAvailability: 'No',
        status: 'Draft',
        planId: '',
        blid: '',
        lastUpdatedBy: '',
        lastUpdatedOn: '',
        effectiveDate: '01/01/2027',
        documentName: '',
        state: 'Test',
        network: [],
        planInternalId: 'TEST',
        description: 'Test',
        configurationSource: '',
      };

      service.createProduct(newProduct).subscribe(() => {
        service.getProducts().subscribe(products => {
          expect(products.length).toBe(initialCount + 1);
          done();
        });
      });
    });

    it('should generate unique sequential IDs', (done) => {
      const product1: Omit<Product, 'id'> = {
        name: 'Product 1',
        category: 'Medical',
        class: 'Test',
        templateAvailability: 'No',
        status: 'Draft',
        planId: '',
        blid: '',
        lastUpdatedBy: '',
        lastUpdatedOn: '',
        effectiveDate: '01/01/2027',
        documentName: '',
        state: 'Test',
        network: [],
        planInternalId: 'TEST1',
        description: 'Test',
        configurationSource: '',
      };

      const product2: Omit<Product, 'id'> = {
        ...product1,
        name: 'Product 2',
        planInternalId: 'TEST2',
      };

      service.createProduct(product1).subscribe(created1 => {
        service.createProduct(product2).subscribe(created2 => {
          expect(parseInt(created2.id)).toBe(parseInt(created1.id) + 1);
          done();
        });
      });
    });

    it('should simulate async with delay', (done) => {
      const newProduct: Omit<Product, 'id'> = {
        name: 'Test',
        category: 'Medical',
        class: 'Test',
        templateAvailability: 'No',
        status: 'Draft',
        planId: '',
        blid: '',
        lastUpdatedBy: '',
        lastUpdatedOn: '',
        effectiveDate: '01/01/2027',
        documentName: '',
        state: 'Test',
        network: [],
        planInternalId: 'TEST',
        description: 'Test',
        configurationSource: '',
      };

      const startTime = Date.now();
      service.createProduct(newProduct).subscribe(() => {
        const endTime = Date.now();
        const elapsed = endTime - startTime;
        expect(elapsed).toBeGreaterThanOrEqual(90);
        done();
      });
    });
  });

  describe('updateProduct()', () => {
    it('should update an existing product', (done) => {
      const updates = {
        name: 'Updated Name',
        status: 'Production' as const,
      };

      service.updateProduct('1', updates).subscribe(updated => {
        expect(updated.id).toBe('1');
        expect(updated.name).toBe('Updated Name');
        expect(updated.status).toBe('Production');
        done();
      });
    });

    it('should preserve unchanged fields', (done) => {
      const updates = {
        name: 'Updated Name',
      };

      service.updateProduct('1', updates).subscribe(updated => {
        expect(updated.category).toBe('Medical'); // Original value
        expect(updated.planId).toBe('11CDZ'); // Original value
        done();
      });
    });

    it('should update lastUpdatedBy and lastUpdatedOn', (done) => {
      const updates = {
        name: 'Updated Name',
      };

      service.updateProduct('1', updates).subscribe(updated => {
        expect(updated.lastUpdatedBy).toBe('BENTEST120');
        expect(updated.lastUpdatedOn).toMatch(/^\d{2}\/\d{2}\/\d{4}$/);
        done();
      });
    });

    it('should not allow ID to be changed', (done) => {
      const updates = {
        id: 'different-id',
        name: 'Updated Name',
      };

      service.updateProduct('1', updates).subscribe(updated => {
        expect(updated.id).toBe('1'); // ID should remain unchanged
        done();
      });
    });

    it('should return error for non-existent product', (done) => {
      const updates = {
        name: 'Updated Name',
      };

      service.updateProduct('nonexistent-id', updates).subscribe({
        next: () => {
          fail('Should have thrown an error');
        },
        error: (error) => {
          expect(error.message).toContain('not found');
          done();
        },
      });
    });

    it('should update product in the list', (done) => {
      const updates = {
        name: 'Updated Name',
      };

      service.updateProduct('1', updates).subscribe(() => {
        service.getProductById('1').subscribe(product => {
          expect(product?.name).toBe('Updated Name');
          done();
        });
      });
    });

    it('should simulate async with delay', (done) => {
      const startTime = Date.now();
      service.updateProduct('1', { name: 'Test' }).subscribe(() => {
        const endTime = Date.now();
        const elapsed = endTime - startTime;
        expect(elapsed).toBeGreaterThanOrEqual(90);
        done();
      });
    });
  });

  describe('deleteProduct()', () => {
    it('should delete an existing product', (done) => {
      service.deleteProduct('1').subscribe(result => {
        expect(result).toBe(true);
        done();
      });
    });

    it('should remove product from the list', (done) => {
      const initialCount = MOCK_PRODUCTS.length;

      service.deleteProduct('1').subscribe(() => {
        service.getProducts().subscribe(products => {
          expect(products.length).toBe(initialCount - 1);
          expect(products.find(p => p.id === '1')).toBeUndefined();
          done();
        });
      });
    });

    it('should return error for non-existent product', (done) => {
      service.deleteProduct('nonexistent-id').subscribe({
        next: () => {
          fail('Should have thrown an error');
        },
        error: (error) => {
          expect(error.message).toContain('not found');
          done();
        },
      });
    });

    it('should simulate async with delay', (done) => {
      const startTime = Date.now();
      service.deleteProduct('1').subscribe(() => {
        const endTime = Date.now();
        const elapsed = endTime - startTime;
        expect(elapsed).toBeGreaterThanOrEqual(90);
        done();
      });
    });
  });

  describe('resetProducts()', () => {
    it('should reset products to initial mock data', (done) => {
      // Create a new product
      const newProduct: Omit<Product, 'id'> = {
        name: 'Temporary Product',
        category: 'Medical',
        class: 'Test',
        templateAvailability: 'No',
        status: 'Draft',
        planId: '',
        blid: '',
        lastUpdatedBy: '',
        lastUpdatedOn: '',
        effectiveDate: '01/01/2027',
        documentName: '',
        state: 'Test',
        network: [],
        planInternalId: 'TEMP',
        description: 'Temporary',
        configurationSource: '',
      };

      service.createProduct(newProduct).subscribe(() => {
        // Reset
        service.resetProducts();

        // Verify reset
        service.getProducts().subscribe(products => {
          expect(products.length).toBe(MOCK_PRODUCTS.length);
          expect(products.find(p => p.name === 'Temporary Product')).toBeUndefined();
          done();
        });
      });
    });
  });

  describe('Observable Behavior', () => {
    it('should emit values asynchronously', (done) => {
      let emitted = false;

      service.getProducts().subscribe(() => {
        emitted = true;
      });

      // Should not be emitted synchronously
      expect(emitted).toBe(false);

      // Should be emitted after delay
      setTimeout(() => {
        expect(emitted).toBe(true);
        done();
      }, 150);
    });

    it('should complete after emitting', (done) => {
      let completed = false;

      service.getProducts().subscribe({
        complete: () => {
          completed = true;
        },
      });

      setTimeout(() => {
        expect(completed).toBe(true);
        done();
      }, 150);
    });
  });

  describe('Data Immutability', () => {
    it('should not allow external modification of returned products', (done) => {
      service.getProducts().subscribe(products => {
        const originalName = products[0].name;
        products[0].name = 'Modified Name';

        service.getProducts().subscribe(freshProducts => {
          expect(freshProducts[0].name).toBe(originalName);
          done();
        });
      });
    });

    it('should return new array references on each call', (done) => {
      service.getProducts().subscribe(products1 => {
        service.getProducts().subscribe(products2 => {
          expect(products1).not.toBe(products2);
          done();
        });
      });
    });
  });
});

// Made with Bob