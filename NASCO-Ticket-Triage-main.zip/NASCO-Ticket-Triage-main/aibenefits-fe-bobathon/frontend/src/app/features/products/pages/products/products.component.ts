import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Product } from '../../models/product.model';
import { ProductsService } from '../../services/products.service';
import { AuthService } from '../../../auth/services/auth.service';
import { ProductTableComponent } from '../../components/product-table/product-table.component';
import { ProductCardViewComponent } from '../../components/product-card-view/product-card-view.component';
import { ProductDetailsModalComponent } from '../../components/product-details-modal/product-details-modal.component';
import { ProductFormModalComponent } from '../../components/product-form-modal/product-form-modal.component';

/**
 * Products Page Component
 * 
 * Main container for the products feature.
 * Manages view state, filtering, pagination, and modal interactions.
 * Uses Angular signals for reactive state management.
 * 
 * @example
 * ```html
 * <app-products></app-products>
 * ```
 */
@Component({
  selector: 'app-products',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ProductTableComponent,
    ProductCardViewComponent,
    ProductDetailsModalComponent,
    ProductFormModalComponent,
  ],
  templateUrl: './products.component.html',
})
export class ProductsComponent implements OnInit {
  // Injected services
  private readonly productsService = inject(ProductsService);
  readonly authService = inject(AuthService);
  private readonly router = inject(Router);

  // View state signals
  viewMode = signal<'table' | 'card'>('card');
  searchQuery = signal<string>('');
  categoryFilter = signal<string>('All');
  statusFilter = signal<string>('All');
  
  // Pagination signals
  page = signal<number>(1);
  pageSize = signal<number>(10);
  
  // Product state signals
  products = signal<Product[]>([]);
  selectedProduct = signal<Product | null>(null);
  
  // Modal state signals
  detailsModalOpen = signal<boolean>(false);
  formModalOpen = signal<boolean>(false);
  formMode = signal<'add' | 'edit'>('add');

  // Dropdown options — categories loaded from service, statuses are static
  categories = signal<string[]>(['All']);
  readonly statuses = ['All', 'Configure', 'Production', 'Draft'];
  readonly pageSizes = [10, 25, 50];

  /**
   * Computed signal for filtered products
   * Filters by search query, category, and status
   */
  filteredProducts = computed(() => {
    const products = this.products();
    const search = this.searchQuery().toLowerCase();
    const category = this.categoryFilter();
    const status = this.statusFilter();

    return products.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(search);
      const matchesCategory = category === 'All' || product.category === category;
      const matchesStatus = status === 'All' || product.status === status;
      return matchesSearch && matchesCategory && matchesStatus;
    });
  });

  /**
   * Computed signal for paginated products
   * Slices filtered products for current page
   */
  paginatedProducts = computed(() => {
    const filtered = this.filteredProducts();
    const currentPage = this.page();
    const size = this.pageSize();
    const startIndex = (currentPage - 1) * size;
    const endIndex = startIndex + size;
    return filtered.slice(startIndex, endIndex);
  });

  /**
   * Computed signal for total pages
   * Calculates based on filtered products and page size
   */
  totalPages = computed(() => {
    const filtered = this.filteredProducts();
    const size = this.pageSize();
    return Math.ceil(filtered.length / size);
  });

  /**
   * Computed signal for pagination display text
   * Shows "X - Y of Z" format
   */
  paginationText = computed(() => {
    const filtered = this.filteredProducts();
    const currentPage = this.page();
    const size = this.pageSize();
    const startIndex = filtered.length === 0 ? 0 : (currentPage - 1) * size + 1;
    const endIndex = Math.min(currentPage * size, filtered.length);
    return `${startIndex} - ${endIndex} of ${filtered.length}`;
  });

  /**
   * Computed signal for filtered results count
   */
  filteredCount = computed(() => this.filteredProducts().length);

  /**
   * Computed signal for whether pagination controls should be shown
   */
  hasPagination = computed(() => this.totalPages() > 0);

  /**
   * Computed signal for current page indicator text
   */
  currentPageIndicator = computed(() => {
    const totalPages = this.totalPages();
    return totalPages === 0 ? 'Page 0 of 0' : `Page ${this.page()} of ${totalPages}`;
  });

  /**
   * Computed signal for total items display
   */
  totalItemsText = computed(() => {
    const count = this.filteredCount();
    return `${count} ${count === 1 ? 'item' : 'items'} total`;
  });

  /**
   * Computed signal for user edit permission
   */
  canEdit = computed(() => {
    const user = this.authService.user();
    return user?.canEdit ?? false;
  });

  ngOnInit(): void {
    this.loadProducts();
    this.loadCategories();
  }

  private loadCategories(): void {
    this.productsService.getCategories().subscribe({
      next: (cats) => this.categories.set(['All', ...cats]),
      error: (err) => console.error('Error loading categories:', err),
    });
  }

  private loadProducts(): void {
    this.productsService.getProducts().subscribe({
      next: (products) => {
        this.products.set(products);
      },
      error: (error) => {
        console.error('Error loading products:', error);
      }
    });
  }

  /**
   * Handle search query change
   */
  onSearchChange(query: string): void {
    this.searchQuery.set(query);
    this.page.set(1); // Reset to first page on search
  }

  /**
   * Handle category filter change
   */
  onCategoryChange(category: string): void {
    this.categoryFilter.set(category);
    this.page.set(1); // Reset to first page on filter
  }

  /**
   * Handle status filter change
   */
  onStatusChange(status: string): void {
    this.statusFilter.set(status);
    this.page.set(1); // Reset to first page on filter
  }

  /**
   * Computed signal for table view active state
   */
  isTableView = computed(() => this.viewMode() === 'table');

  /**
   * Computed signal for card view active state
   */
  isCardView = computed(() => this.viewMode() === 'card');

  /**
   * Handle view mode toggle
   */
  onViewModeChange(mode: 'table' | 'card'): void {
    this.viewMode.set(mode);
  }

  /**
   * Handle page size change
   */
  onPageSizeChange(size: number): void {
    this.pageSize.set(size);
    this.page.set(1); // Reset to first page on page size change
  }

  /**
   * Handle page change
   */
  onPageChange(newPage: number): void {
    const total = this.totalPages();
    if (newPage >= 1 && newPage <= total) {
      this.page.set(newPage);
    }
  }

  /**
   * Handle product click - opens details modal
   */
  onProductClick(product: Product): void {
    this.selectedProduct.set(product);
    this.detailsModalOpen.set(true);
  }

  /**
   * Handle new product button click
   */
  onAddProduct(): void {
    this.formMode.set('add');
    this.selectedProduct.set(null);
    this.formModalOpen.set(true);
  }

  /**
   * Handle edit product from details modal
   */
  onEditProduct(): void {
    this.formMode.set('edit');
    this.detailsModalOpen.set(false);
    this.formModalOpen.set(true);
  }

  /**
   * Handle product save from form modal
   */
  onSaveProduct(productData: Partial<Product>): void {
    const mode = this.formMode();
    const currentUser = this.authService.user();

    if (mode === 'add') {
      const createPayload = {
        ...productData,
        lastUpdatedBy: currentUser?.id ?? 'BENTEST120',
      } as Omit<Product, 'id'>;

      this.productsService.createProduct(createPayload).subscribe({
        next: (newProduct) => {
          this.products.update(products => [newProduct, ...products]);
          this.formModalOpen.set(false);
          this.selectedProduct.set(newProduct);
          this.showToast('Product created successfully!');
        },
        error: (error) => {
          console.error('Error creating product:', error);
          this.showToast('Error creating product');
        }
      });
    } else if (mode === 'edit') {
      const selected = this.selectedProduct();
      if (selected) {
        const updatePayload: Partial<Product> = {
          ...productData,
          lastUpdatedBy: currentUser?.id ?? 'BENTEST120',
        };

        this.productsService.updateProduct(selected.id, updatePayload).subscribe({
          next: (updatedProduct) => {
            this.products.update(products =>
              products.map(p => p.id === updatedProduct.id ? updatedProduct : p)
            );
            this.selectedProduct.set(updatedProduct);
            this.formModalOpen.set(false);
            this.detailsModalOpen.set(false);
            this.showToast('Product updated successfully!');
          },
          error: (error) => {
            console.error('Error updating product:', error);
            this.showToast('Error updating product');
          }
        });
      }
    }
  }

  /**
   * Handle details modal close
   */
  onDetailsModalClose(): void {
    this.detailsModalOpen.set(false);
  }

  /**
   * Handle form modal close
   */
  onFormModalClose(): void {
    this.formModalOpen.set(false);
  }

  /**
   * Handle AI assistant click
   */
  onAIAssistantClick(): void {
    this.showToast('AI Assistant: How can I help you manage your benefit products?');
  }

  /**
   * Handle logout
   */
  onLogout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  /**
   * Show toast notification (placeholder)
   * In production, this would integrate with a toast service
   */
  private showToast(message: string): void {
    console.log('Toast:', message);
    // TODO: Integrate with toast notification service
  }

  /**
   * Get array of page numbers for pagination
   */
  getPageNumbers(): number[] {
    const total = this.totalPages();
    return Array.from({ length: total }, (_, i) => i + 1);
  }
}

// Made with Bob
