import {
  formatDateToDisplay,
  formatDateToStore,
  validateDateFormat,
} from './date.util';

describe('Date Utilities', () => {
  describe('formatDateToDisplay', () => {
    it('should convert YYYY-MM-DD to MM/DD/YYYY', () => {
      expect(formatDateToDisplay('2024-03-15')).toBe('03/15/2024');
      expect(formatDateToDisplay('2024-01-01')).toBe('01/01/2024');
      expect(formatDateToDisplay('2024-12-31')).toBe('12/31/2024');
    });

    it('should handle single digit months and days with padding', () => {
      expect(formatDateToDisplay('2024-01-05')).toBe('01/05/2024');
      expect(formatDateToDisplay('2024-09-09')).toBe('09/09/2024');
    });

    it('should return empty string for empty input', () => {
      expect(formatDateToDisplay('')).toBe('');
    });

    it('should return original string for invalid format', () => {
      expect(formatDateToDisplay('03/15/2024')).toBe('03/15/2024');
      expect(formatDateToDisplay('invalid')).toBe('invalid');
      expect(formatDateToDisplay('2024/03/15')).toBe('2024/03/15');
      expect(formatDateToDisplay('15-03-2024')).toBe('15-03-2024');
    });

    it('should return original string for invalid dates', () => {
      expect(formatDateToDisplay('2024-13-01')).toBe('2024-13-01');
      expect(formatDateToDisplay('2024-02-31')).toBe('2024-02-31');
      expect(formatDateToDisplay('2024-00-15')).toBe('2024-00-15');
    });

    it('should handle leap years correctly', () => {
      expect(formatDateToDisplay('2024-02-29')).toBe('02/29/2024'); // Leap year
      expect(formatDateToDisplay('2023-02-29')).toBe('2023-02-29'); // Not a leap year - invalid
    });

    it('should handle edge case dates', () => {
      expect(formatDateToDisplay('1900-01-01')).toBe('01/01/1900');
      expect(formatDateToDisplay('2099-12-31')).toBe('12/31/2099');
    });
  });

  describe('formatDateToStore', () => {
    it('should convert MM/DD/YYYY to YYYY-MM-DD', () => {
      expect(formatDateToStore('03/15/2024')).toBe('2024-03-15');
      expect(formatDateToStore('01/01/2024')).toBe('2024-01-01');
      expect(formatDateToStore('12/31/2024')).toBe('2024-12-31');
    });

    it('should handle single digit months and days with padding', () => {
      expect(formatDateToStore('1/5/2024')).toBe('2024-01-05');
      expect(formatDateToStore('9/9/2024')).toBe('2024-09-09');
      expect(formatDateToStore('01/05/2024')).toBe('2024-01-05');
    });

    it('should return empty string for empty input', () => {
      expect(formatDateToStore('')).toBe('');
    });

    it('should return original string for invalid format', () => {
      expect(formatDateToStore('2024-03-15')).toBe('2024-03-15');
      expect(formatDateToStore('invalid')).toBe('invalid');
      expect(formatDateToStore('2024/03/15')).toBe('2024/03/15');
      expect(formatDateToStore('15-03-2024')).toBe('15-03-2024');
    });

    it('should return original string for invalid dates', () => {
      expect(formatDateToStore('13/01/2024')).toBe('13/01/2024');
      expect(formatDateToStore('02/31/2024')).toBe('02/31/2024');
      expect(formatDateToStore('00/15/2024')).toBe('00/15/2024');
    });

    it('should handle leap years correctly', () => {
      expect(formatDateToStore('02/29/2024')).toBe('2024-02-29'); // Leap year
      expect(formatDateToStore('02/29/2023')).toBe('02/29/2023'); // Not a leap year - invalid
    });

    it('should handle edge case dates', () => {
      expect(formatDateToStore('01/01/1900')).toBe('1900-01-01');
      expect(formatDateToStore('12/31/2099')).toBe('2099-12-31');
    });
  });

  describe('validateDateFormat', () => {
    it('should return true for valid MM/DD/YYYY dates', () => {
      expect(validateDateFormat('03/15/2024')).toBe(true);
      expect(validateDateFormat('01/01/2024')).toBe(true);
      expect(validateDateFormat('12/31/2024')).toBe(true);
      expect(validateDateFormat('1/1/2024')).toBe(true);
      expect(validateDateFormat('9/9/2024')).toBe(true);
    });

    it('should return false for empty string', () => {
      expect(validateDateFormat('')).toBe(false);
    });

    it('should return false for invalid format', () => {
      expect(validateDateFormat('2024-03-15')).toBe(false);
      expect(validateDateFormat('invalid')).toBe(false);
      expect(validateDateFormat('2024/03/15')).toBe(false);
      expect(validateDateFormat('15-03-2024')).toBe(false);
      expect(validateDateFormat('03-15-2024')).toBe(false);
    });

    it('should return false for invalid month', () => {
      expect(validateDateFormat('13/01/2024')).toBe(false);
      expect(validateDateFormat('00/15/2024')).toBe(false);
      expect(validateDateFormat('99/15/2024')).toBe(false);
    });

    it('should return false for invalid day', () => {
      expect(validateDateFormat('03/32/2024')).toBe(false);
      expect(validateDateFormat('03/00/2024')).toBe(false);
      expect(validateDateFormat('02/31/2024')).toBe(false); // February doesn't have 31 days
      expect(validateDateFormat('04/31/2024')).toBe(false); // April doesn't have 31 days
    });

    it('should handle leap years correctly', () => {
      expect(validateDateFormat('02/29/2024')).toBe(true); // Leap year
      expect(validateDateFormat('02/29/2023')).toBe(false); // Not a leap year
      expect(validateDateFormat('02/29/2000')).toBe(true); // Leap year (divisible by 400)
      expect(validateDateFormat('02/29/1900')).toBe(false); // Not a leap year (divisible by 100 but not 400)
    });

    it('should validate days per month correctly', () => {
      // 31-day months
      expect(validateDateFormat('01/31/2024')).toBe(true);
      expect(validateDateFormat('03/31/2024')).toBe(true);
      expect(validateDateFormat('05/31/2024')).toBe(true);
      expect(validateDateFormat('07/31/2024')).toBe(true);
      expect(validateDateFormat('08/31/2024')).toBe(true);
      expect(validateDateFormat('10/31/2024')).toBe(true);
      expect(validateDateFormat('12/31/2024')).toBe(true);

      // 30-day months
      expect(validateDateFormat('04/30/2024')).toBe(true);
      expect(validateDateFormat('06/30/2024')).toBe(true);
      expect(validateDateFormat('09/30/2024')).toBe(true);
      expect(validateDateFormat('11/30/2024')).toBe(true);

      // Invalid 31st day for 30-day months
      expect(validateDateFormat('04/31/2024')).toBe(false);
      expect(validateDateFormat('06/31/2024')).toBe(false);
      expect(validateDateFormat('09/31/2024')).toBe(false);
      expect(validateDateFormat('11/31/2024')).toBe(false);

      // February
      expect(validateDateFormat('02/28/2024')).toBe(true);
      expect(validateDateFormat('02/28/2023')).toBe(true);
      expect(validateDateFormat('02/30/2024')).toBe(false);
    });

    it('should handle edge case years', () => {
      expect(validateDateFormat('01/01/1900')).toBe(true);
      expect(validateDateFormat('12/31/2099')).toBe(true);
      expect(validateDateFormat('06/15/2000')).toBe(true);
    });
  });

  describe('Round-trip conversions', () => {
    it('should convert back and forth between formats', () => {
      const isoDate = '2024-03-15';
      const usDate = '03/15/2024';

      expect(formatDateToDisplay(isoDate)).toBe(usDate);
      expect(formatDateToStore(usDate)).toBe(isoDate);
      expect(formatDateToStore(formatDateToDisplay(isoDate))).toBe(isoDate);
      expect(formatDateToDisplay(formatDateToStore(usDate))).toBe(usDate);
    });

    it('should handle single digit dates in round-trip', () => {
      const isoDate = '2024-01-05';
      const usDate = '01/05/2024';

      expect(formatDateToDisplay(isoDate)).toBe(usDate);
      expect(formatDateToStore(usDate)).toBe(isoDate);
    });
  });
});

// Made with Bob
