import { Component, input, output, effect, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Product } from '../../models/product.model';
import { getStatusColor } from '../../utils/product-status.util';

/**
 * Product Details Modal Component
 * 
 * Displays detailed product information in a modal dialog.
 * Shows all product fields in a structured layout with edit capability.
 * 
 * @example
 * ```html
 * <app-product-details-modal 
 *   [open]="isModalOpen()"
 *   [product]="selectedProduct()"
 *   (close)="handleClose()"
 *   (edit)="handleEdit()">
 * </app-product-details-modal>
 * ```
 */
@Component({
  selector: 'app-product-details-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-details-modal.component.html',
})
export class ProductDetailsModalComponent {
  /**
   * Controls modal visibility
   */
  open = input.required<boolean>();

  /**
   * Product to display in the modal
   */
  product = input.required<Product | null>();

  /**
   * Event emitted when modal should close
   */
  close = output<void>();

  /**
   * Event emitted when edit button is clicked
   */
  edit = output<void>();

  /**
   * Mock user permission for edit capability
   * In real implementation, this would come from auth service
   */
  canEdit = true;

  constructor() {
    // Prevent body scroll when modal is open
    effect(() => {
      if (this.open()) {
        document.body.style.overflow = 'hidden';
      } else {
        document.body.style.overflow = '';
      }
    });
  }

  /**
   * Handle Escape key to close modal
   */
  @HostListener('document:keydown.escape')
  onEscapeKey(): void {
    if (this.open()) {
      this.onClose();
    }
  }

  /**
   * Get Tailwind CSS classes for status badge styling
   * 
   * @param status - The product status
   * @returns Tailwind CSS class string
   */
  getStatusColor(status: string): string {
    return getStatusColor(status as any);
  }

  /**
   * Handle modal close
   */
  onClose(): void {
    this.close.emit();
  }

  /**
   * Handle backdrop click to close modal
   */
  onBackdropClick(): void {
    this.onClose();
  }

  /**
   * Prevent modal content click from closing modal
   */
  onModalClick(event: Event): void {
    event.stopPropagation();
  }

  /**
   * Handle edit button click
   */
  onEdit(): void {
    this.edit.emit();
  }

  /**
   * Format date to MM/DD/YYYY display format
   * 
   * @param dateStr - Date string in various formats
   * @returns Formatted date string or '-' if invalid
   */
  formatDate(dateStr: string): string {
    if (!dateStr) return '-';
    
    // If already in MM/DD/YYYY format, return as is
    if (dateStr.includes('/')) return dateStr;
    
    // Convert YYYY-MM-DD to MM/DD/YYYY
    const date = new Date(dateStr + 'T00:00:00');
    if (isNaN(date.getTime())) return dateStr;
    
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();
    
    return `${month}/${day}/${year}`;
  }

  /**
   * Format cell value, returning '-' for empty/null values
   * 
   * @param value - The cell value
   * @returns Formatted value or '-'
   */
  formatValue(value: string | null | undefined): string {
    return value || '-';
  }
}

// Made with Bob