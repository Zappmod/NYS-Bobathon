import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { Product } from '../models/product.model';
import { MOCK_PRODUCTS } from './products.mock';

/**
 * Products Service
 * Manages product data operations with mock implementation
 * Uses signals for state management and RxJS for async operations
 */
@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  private readonly http = inject(HttpClient);

  private productsState = signal<Product[]>([...MOCK_PRODUCTS]);

  getCategories(): Observable<string[]> {
    //Categories are fetched from the backend API, Not Mock - this is not a defect
    return this.http
      .get<{ categories: string[] }>(`${environment.apiUrl}/v1/categories`)
      .pipe(map(r => r.categories));
  }

  getProducts(): Observable<Product[]> {
    // Return a deep copy to maintain immutability
    return of(this.productsState().map(p => ({ ...p, network: [...p.network] }))).pipe(
      delay(100) // Simulate network delay
    );
  }

  /**
   * Get a single product by ID
   * @param id - Product ID to retrieve
   * @returns Observable of product or null if not found
   */
  getProductById(id: string): Observable<Product | null> {
    const product = this.productsState().find(p => p.id === id);
    return of(product ? { ...product, network: [...product.network] } : null).pipe(
      delay(100) // Simulate network delay
    );
  }

  /**
   * Create a new product
   * @param product - Product data (without id)
   * @returns Observable of created product with generated ID
   */
  createProduct(product: Omit<Product, 'id'>): Observable<Product> {
    // Generate unique ID
    const newId = this.generateUniqueId();
    
    // Get current timestamp
    const now = this.getCurrentDateString();
    
    // Create new product with generated ID and updated metadata
    const newProduct: Product = {
      ...product,
      id: newId,
      lastUpdatedBy: 'BENTEST120', // Mock user
      lastUpdatedOn: now
    };

    // Update state with new product
    this.productsState.update(products => [...products, newProduct]);

    return of({ ...newProduct }).pipe(
      delay(100) // Simulate network delay
    );
  }

  /**
   * Update an existing product
   * @param id - Product ID to update
   * @param product - Updated product data
   * @returns Observable of updated product or error if not found
   */
  updateProduct(id: string, product: Partial<Product>): Observable<Product> {
    const currentProducts = this.productsState();
    const index = currentProducts.findIndex(p => p.id === id);

    if (index === -1) {
      return throwError(() => new Error(`Product with id ${id} not found`)).pipe(
        delay(100)
      );
    }

    // Get current timestamp
    const now = this.getCurrentDateString();

    // Create updated product with metadata
    const updatedProduct: Product = {
      ...currentProducts[index],
      ...product,
      id, // Ensure ID doesn't change
      lastUpdatedBy: 'BENTEST120', // Mock user
      lastUpdatedOn: now
    };

    // Update state with modified product
    this.productsState.update(products => {
      const newProducts = [...products];
      newProducts[index] = updatedProduct;
      return newProducts;
    });

    return of({ ...updatedProduct }).pipe(
      delay(100) // Simulate network delay
    );
  }

  /**
   * Delete a product
   * @param id - Product ID to delete
   * @returns Observable of boolean indicating success
   */
  deleteProduct(id: string): Observable<boolean> {
    const currentProducts = this.productsState();
    const index = currentProducts.findIndex(p => p.id === id);

    if (index === -1) {
      return throwError(() => new Error(`Product with id ${id} not found`)).pipe(
        delay(100)
      );
    }

    // Update state by removing product
    this.productsState.update(products => 
      products.filter(p => p.id !== id)
    );

    return of(true).pipe(
      delay(100) // Simulate network delay
    );
  }

  /**
   * Reset products to initial mock data
   * Useful for testing and development
   */
  resetProducts(): void {
    this.productsState.set([...MOCK_PRODUCTS]);
  }

  /**
   * Generate a unique ID for new products
   * @returns Unique string ID
   */
  private generateUniqueId(): string {
    const currentProducts = this.productsState();
    const maxId = currentProducts.reduce((max, product) => {
      const numId = parseInt(product.id, 10);
      return isNaN(numId) ? max : Math.max(max, numId);
    }, 0);
    return (maxId + 1).toString();
  }

  /**
   * Get current date as MM/DD/YYYY string
   * @returns Formatted date string
   */
  private getCurrentDateString(): string {
    const now = new Date();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const year = now.getFullYear();
    return `${month}/${day}/${year}`;
  }
}

// Made with Bob