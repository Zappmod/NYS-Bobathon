import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProductDetailsModalComponent } from './product-details-modal.component';
import { Product } from '../../models/product.model';
import { By } from '@angular/platform-browser';

describe('ProductDetailsModalComponent', () => {
  let component: ProductDetailsModalComponent;
  let fixture: ComponentFixture<ProductDetailsModalComponent>;

  const mockProduct: Product = {
    id: '1',
    name: 'Premier Health Advantage',
    category: 'Medical',
    class: 'HMO',
    templateAvailability: 'Yes',
    status: 'Configure',
    planId: '11CDZ',
    blid: 'BL001',
    lastUpdatedBy: 'BENTEST120',
    lastUpdatedOn: '12/15/2024',
    effectiveDate: '01/01/2025',
    documentName: 'Premier_Health_Doc',
    state: 'California',
    network: [
      { tier: 'Tier 1', network: 'Blue Shield INN' },
      { tier: 'Tier 2', network: 'Blue Shield OON' },
    ],
    planInternalId: 'PHA-2025-CA',
    description: 'Comprehensive HMO plan with extensive coverage',
    configurationSource: 'Manual Configuration',
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductDetailsModalComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ProductDetailsModalComponent);
    component = fixture.componentInstance;
  });

  describe('Component Initialization', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should be a standalone component', () => {
      const metadata = (ProductDetailsModalComponent as any).ɵcmp;
      expect(metadata.standalone).toBe(true);
    });

    it('should have required open input', () => {
      expect(component.open).toBeDefined();
    });

    it('should have required product input', () => {
      expect(component.product).toBeDefined();
    });

    it('should have close output', () => {
      expect(component.close).toBeDefined();
    });

    it('should have edit output', () => {
      expect(component.edit).toBeDefined();
    });

    it('should have canEdit property set to true by default', () => {
      expect(component.canEdit).toBe(true);
    });
  });

  describe('Modal Visibility', () => {
    it('should not render modal when open is false', () => {
      fixture.componentRef.setInput('open', false);
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();

      const modal = fixture.debugElement.query(By.css('[role="dialog"]'));
      expect(modal).toBeNull();
    });

    it('should not render modal when product is null', () => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('product', null);
      fixture.detectChanges();

      const modal = fixture.debugElement.query(By.css('[role="dialog"]'));
      expect(modal).toBeNull();
    });

    it('should render modal when open is true and product exists', () => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();

      const modal = fixture.debugElement.query(By.css('[role="dialog"]'));
      expect(modal).toBeTruthy();
    });
  });

  describe('Modal Structure', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();
    });

    it('should have overlay with backdrop', () => {
      const overlay = fixture.debugElement.query(By.css('.fixed.inset-0'));
      expect(overlay).toBeTruthy();
      expect(overlay.nativeElement.classList.contains('bg-black')).toBe(true);
      expect(overlay.nativeElement.classList.contains('bg-opacity-50')).toBe(true);
    });

    it('should have modal content container', () => {
      const content = fixture.debugElement.query(By.css('[class*="bg-white"]'));
      expect(content).toBeTruthy();
      expect(content.nativeElement.classList.contains('sm:max-w-3xl')).toBe(true);
    });

    it('should have role="dialog" and aria-modal="true"', () => {
      const dialog = fixture.debugElement.query(By.css('[role="dialog"]'));
      expect(dialog.nativeElement.getAttribute('aria-modal')).toBe('true');
    });

    it('should have aria-labelledby pointing to title', () => {
      const dialog = fixture.debugElement.query(By.css('[role="dialog"]'));
      const titleId = `modal-title-${mockProduct.id}`;
      expect(dialog.nativeElement.getAttribute('aria-labelledby')).toBe(titleId);
    });
  });

  describe('Modal Header', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();
    });

    it('should display product name as h2', () => {
      const title = fixture.debugElement.query(By.css('h2'));
      expect(title).toBeTruthy();
      expect(title.nativeElement.textContent.trim()).toBe(mockProduct.name);
      expect(title.nativeElement.classList.contains('text-xl')).toBe(true);
      expect(title.nativeElement.classList.contains('sm:text-2xl')).toBe(true);
      expect(title.nativeElement.classList.contains('font-semibold')).toBe(true);
    });

    it('should have correct id on title for aria-labelledby', () => {
      const title = fixture.debugElement.query(By.css('h2'));
      expect(title.nativeElement.id).toBe(`modal-title-${mockProduct.id}`);
    });

    it('should display "Product" chip with success color', () => {
      const chips = fixture.debugElement.queryAll(By.css('span.inline-flex'));
      const productChip = chips.find(chip => 
        chip.nativeElement.textContent.trim() === 'Product'
      );
      expect(productChip).toBeTruthy();
      expect(productChip!.nativeElement.classList.contains('bg-green-600')).toBe(true);
      expect(productChip!.nativeElement.classList.contains('text-white')).toBe(true);
    });

    it('should display status chip with outlined style', () => {
      const chips = fixture.debugElement.queryAll(By.css('span.inline-flex'));
      const statusChip = chips.find(chip => 
        chip.nativeElement.textContent.trim() === mockProduct.status
      );
      expect(statusChip).toBeTruthy();
      expect(statusChip!.nativeElement.classList.contains('border-2')).toBe(true);
    });

    it('should have close button with X icon', () => {
      const closeButton = fixture.debugElement.query(By.css('button[aria-label="Close modal"]'));
      expect(closeButton).toBeTruthy();
      const svg = closeButton.query(By.css('svg'));
      expect(svg).toBeTruthy();
    });
  });

  describe('Modal Content - Left Column', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();
    });

    it('should display product name in left column', () => {
      const content = fixture.nativeElement.textContent;
      expect(content).toContain('Product Name');
      expect(content).toContain(mockProduct.name);
    });

    it('should display category in left column', () => {
      const content = fixture.nativeElement.textContent;
      expect(content).toContain('Category');
      expect(content).toContain(mockProduct.category);
    });

    it('should display class in left column', () => {
      const content = fixture.nativeElement.textContent;
      expect(content).toContain('Class');
      expect(content).toContain(mockProduct.class);
    });

    it('should display plan internal ID in left column', () => {
      const content = fixture.nativeElement.textContent;
      expect(content).toContain('Plan Internal ID');
      expect(content).toContain(mockProduct.planInternalId);
    });

    it('should display BLID in left column', () => {
      const content = fixture.nativeElement.textContent;
      expect(content).toContain('BLID');
      expect(content).toContain(mockProduct.blid);
    });
  });

  describe('Modal Content - Right Column', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();
    });

    it('should display effective date in right column', () => {
      const content = fixture.nativeElement.textContent;
      expect(content).toContain('Effective Date');
      expect(content).toContain('01/01/2025');
    });

    it('should display document name in right column', () => {
      const content = fixture.nativeElement.textContent;
      expect(content).toContain('Document Name');
      expect(content).toContain(mockProduct.documentName);
    });

    it('should display state in right column', () => {
      const content = fixture.nativeElement.textContent;
      expect(content).toContain('State');
      expect(content).toContain(mockProduct.state);
    });

    it('should display network tiers in right column', () => {
      const content = fixture.nativeElement.textContent;
      expect(content).toContain('Network');
      expect(content).toContain('Tier 1: Blue Shield INN');
      expect(content).toContain('Tier 2: Blue Shield OON');
    });

    it('should display "-" when network is empty', () => {
      const productWithoutNetwork = { ...mockProduct, network: [] };
      fixture.componentRef.setInput('product', productWithoutNetwork);
      fixture.detectChanges();

      const content = fixture.nativeElement.textContent;
      expect(content).toContain('Network');
      // Check that the network section contains a dash
      const tables = fixture.debugElement.queryAll(By.css('table'));
      const rightTable = tables[1];
      expect(rightTable.nativeElement.textContent).toContain('-');
    });
  });

  describe('Modal Content - Full Width Sections', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();
    });

    it('should display description section', () => {
      const content = fixture.nativeElement.textContent;
      expect(content).toContain('Description');
      expect(content).toContain(mockProduct.description);
    });

    it('should display configuration source with monospace font', () => {
      const content = fixture.nativeElement.textContent;
      expect(content).toContain('Configuration Source');
      expect(content).toContain(mockProduct.configurationSource);
      
      const monoText = fixture.debugElement.query(By.css('.font-mono'));
      expect(monoText).toBeTruthy();
      expect(monoText.nativeElement.textContent.trim()).toBe(mockProduct.configurationSource);
    });

    it('should not display configuration source section when empty', () => {
      const productWithoutConfig = { ...mockProduct, configurationSource: '' };
      fixture.componentRef.setInput('product', productWithoutConfig);
      fixture.detectChanges();

      const content = fixture.nativeElement.textContent;
      expect(content).not.toContain('Configuration Source');
    });
  });

  describe('Modal Footer', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();
    });

    it('should display edit button when canEdit is true', () => {
      component.canEdit = true;
      fixture.detectChanges();

      const editButton = fixture.debugElement.query(By.css('button[type="button"]:not([aria-label])'));
      expect(editButton).toBeTruthy();
      expect(editButton.nativeElement.textContent.trim()).toBe('Edit');
    });

    it('should not display edit button when canEdit is false', () => {
      component.canEdit = false;
      fixture.detectChanges();

      const buttons = fixture.debugElement.queryAll(By.css('button'));
      const editButton = buttons.find(btn => 
        btn.nativeElement.textContent.trim() === 'Edit'
      );
      expect(editButton).toBeUndefined();
    });
  });

  describe('User Interactions', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();
    });

    it('should emit close event when close button is clicked', () => {
      const emitSpy = jest.spyOn(component.close, 'emit');
      const closeButton = fixture.debugElement.query(By.css('button[aria-label="Close modal"]'));
      
      closeButton.nativeElement.click();
      
      expect(emitSpy).toHaveBeenCalled();
    });

    it('should emit close event when backdrop is clicked', () => {
      const emitSpy = jest.spyOn(component.close, 'emit');
      const overlay = fixture.debugElement.query(By.css('.fixed.inset-0'));
      
      overlay.nativeElement.click();
      
      expect(emitSpy).toHaveBeenCalled();
    });

    it('should not emit close event when modal content is clicked', () => {
      const emitSpy = jest.spyOn(component.close, 'emit');
      const modalContent = fixture.debugElement.query(By.css('[class*="bg-white"]'));
      
      modalContent.nativeElement.click();
      
      expect(emitSpy).not.toHaveBeenCalled();
    });

    it('should expose an accessible close button label', () => {
      const closeButton = fixture.debugElement.query(By.css('button[aria-label="Close modal"]'));
      expect(closeButton).toBeTruthy();
      expect(closeButton.nativeElement.classList.contains('min-h-11')).toBe(true);
      expect(closeButton.nativeElement.classList.contains('min-w-11')).toBe(true);
    });

    it('should emit edit event when edit button is clicked', () => {
      const emitSpy = jest.spyOn(component.edit, 'emit');
      const editButton = fixture.debugElement.query(By.css('button[type="button"]:not([aria-label])'));
      
      editButton.nativeElement.click();
      
      expect(emitSpy).toHaveBeenCalled();
    });

    it('should close modal on Escape key', () => {
      const emitSpy = jest.spyOn(component.close, 'emit');
      
      const event = new KeyboardEvent('keydown', { key: 'Escape' });
      document.dispatchEvent(event);
      
      expect(emitSpy).toHaveBeenCalled();
    });

    it('should not close modal on Escape key when modal is closed', () => {
      fixture.componentRef.setInput('open', false);
      fixture.detectChanges();
      
      const emitSpy = jest.spyOn(component.close, 'emit');
      
      const event = new KeyboardEvent('keydown', { key: 'Escape' });
      document.dispatchEvent(event);
      
      expect(emitSpy).not.toHaveBeenCalled();
    });
  });

  describe('Date Formatting', () => {
    it('should format YYYY-MM-DD to MM/DD/YYYY', () => {
      expect(component.formatDate('2025-01-15')).toBe('01/15/2025');
      expect(component.formatDate('2024-12-31')).toBe('12/31/2024');
    });

    it('should return date as-is if already in MM/DD/YYYY format', () => {
      expect(component.formatDate('01/15/2025')).toBe('01/15/2025');
      expect(component.formatDate('12/31/2024')).toBe('12/31/2024');
    });

    it('should return "-" for empty string', () => {
      expect(component.formatDate('')).toBe('-');
    });

    it('should return original string for invalid date', () => {
      expect(component.formatDate('invalid-date')).toBe('invalid-date');
    });
  });

  describe('Value Formatting', () => {
    it('should return value when provided', () => {
      expect(component.formatValue('test')).toBe('test');
      expect(component.formatValue('123')).toBe('123');
    });

    it('should return "-" for null', () => {
      expect(component.formatValue(null)).toBe('-');
    });

    it('should return "-" for undefined', () => {
      expect(component.formatValue(undefined)).toBe('-');
    });

    it('should return "-" for empty string', () => {
      expect(component.formatValue('')).toBe('-');
    });
  });

  describe('Component Methods', () => {
    it('should emit close from onClose()', () => {
      const emitSpy = jest.spyOn(component.close, 'emit');

      component.onClose();

      expect(emitSpy).toHaveBeenCalled();
    });

    it('should stop propagation on modal content click', () => {
      const stopPropagation = jest.fn();

      component.onModalClick({ stopPropagation } as unknown as Event);

      expect(stopPropagation).toHaveBeenCalled();
    });

    it('should emit edit from onEdit()', () => {
      const emitSpy = jest.spyOn(component.edit, 'emit');

      component.onEdit();

      expect(emitSpy).toHaveBeenCalled();
    });

    it('should delegate backdrop clicks to onClose()', () => {
      const closeSpy = jest.spyOn(component, 'onClose');

      component.onBackdropClick();

      expect(closeSpy).toHaveBeenCalled();
    });

    it('should return fallback value for null and undefined formatValue inputs', () => {
      expect(component.formatValue(null)).toBe('-');
      expect(component.formatValue(undefined)).toBe('-');
    });
  });

  describe('Body Scroll Prevention', () => {
    it('should prevent body scroll when modal opens', () => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();

      expect(document.body.style.overflow).toBe('hidden');
    });

    it('should restore body scroll when modal closes', () => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();

      fixture.componentRef.setInput('open', false);
      fixture.detectChanges();

      expect(document.body.style.overflow).toBe('');
    });
  });

  describe('Responsive Layout', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();
    });

    it('should have 2-column grid on medium screens', () => {
      const grid = fixture.debugElement.query(By.css('.grid'));
      expect(grid.nativeElement.classList.contains('grid-cols-1')).toBe(true);
      expect(grid.nativeElement.classList.contains('md:grid-cols-2')).toBe(true);
    });

    it('should have full-width sections span both columns', () => {
      const fullWidthSections = fixture.debugElement.queryAll(By.css('.md\\:col-span-2'));
      expect(fullWidthSections.length).toBeGreaterThan(0);
    });
  });

  describe('Table Styling', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('open', true);
      fixture.componentRef.setInput('product', mockProduct);
      fixture.detectChanges();
    });

    it('should have labels with primary color', () => {
      const labels = fixture.debugElement.queryAll(By.css('td.font-semibold.text-blue-600'));
      expect(labels.length).toBeGreaterThan(0);
    });

    it('should have labels with 35% width', () => {
      const labels = fixture.debugElement.queryAll(By.css('td.font-semibold'));
      labels.forEach(label => {
        expect(label.nativeElement.classList.contains('w-[35%]')).toBe(true);
      });
    });

    it('should have border between rows', () => {
      const rows = fixture.debugElement.queryAll(By.css('tr.border-b'));
      expect(rows.length).toBeGreaterThan(0);
    });
  });
});

// Made with Bob