import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProductCardViewComponent } from './product-card-view.component';
import { Product } from '../../models/product.model';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('ProductCardViewComponent', () => {
  let component: ProductCardViewComponent;
  let fixture: ComponentFixture<ProductCardViewComponent>;

  const mockProducts: Product[] = [
    {
      id: '1',
      name: 'Premier Health Advantage',
      category: 'Medical',
      class: 'HMO',
      templateAvailability: 'Yes',
      status: 'Configure',
      planId: '11CDZ',
      blid: 'BL001',
      lastUpdatedBy: 'BENTEST120',
      lastUpdatedOn: '12/15/2024',
      effectiveDate: '01/01/2025',
      documentName: 'Premier_Health_Doc',
      state: 'California',
      network: [
        { tier: 'Tier 1', network: 'Blue Shield INN' },
        { tier: 'Tier 2', network: 'Blue Shield OON' },
      ],
      planInternalId: 'PHA-2025-CA',
      description: 'Comprehensive HMO plan',
      configurationSource: 'Manual',
    },
    {
      id: '2',
      name: 'Dental Plus',
      category: 'Dental',
      class: 'PPO',
      templateAvailability: 'No',
      status: 'Production',
      planId: '',
      blid: '',
      lastUpdatedBy: 'BENTEST121',
      lastUpdatedOn: '12/16/2024',
      effectiveDate: '01/01/2025',
      documentName: 'Dental_Plus_Doc',
      state: 'Texas',
      network: [{ tier: 'Tier 1', network: 'Delta Dental' }],
      planInternalId: 'DP-2025-TX',
      description: 'Dental PPO plan',
      configurationSource: 'Template',
    },
    {
      id: '3',
      name: 'Vision Care',
      category: 'Vision',
      class: 'Standard',
      templateAvailability: 'Yes',
      status: 'Draft',
      planId: 'VC123',
      blid: 'BL003',
      lastUpdatedBy: 'BENTEST122',
      lastUpdatedOn: '12/17/2024',
      effectiveDate: '01/01/2025',
      documentName: 'Vision_Care_Doc',
      state: 'New York',
      network: [{ tier: 'Tier 1', network: 'VSP' }],
      planInternalId: 'VC-2025-NY',
      description: 'Vision care plan',
      configurationSource: 'Manual',
    },
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductCardViewComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ProductCardViewComponent);
    component = fixture.componentInstance;
  });

  describe('Component Initialization', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should be a standalone component', () => {
      const metadata = (ProductCardViewComponent as any).ɵcmp;
      expect(metadata.standalone).toBe(true);
    });

    it('should have required products input', () => {
      expect(component.products).toBeDefined();
    });

    it('should have productClick output', () => {
      expect(component.productClick).toBeDefined();
    });
  });

  describe('Grid Layout', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should render grid container with responsive classes', () => {
      const grid = fixture.debugElement.query(By.css('.grid'));
      expect(grid).toBeTruthy();
      expect(grid.nativeElement.classList.contains('grid-cols-1')).toBe(true);
      expect(grid.nativeElement.classList.contains('sm:grid-cols-2')).toBe(true);
      expect(grid.nativeElement.classList.contains('lg:grid-cols-4')).toBe(true);
      expect(grid.nativeElement.classList.contains('md:grid-cols-3')).toBe(false);
    });

    it('should have gap-3 spacing', () => {
      const grid = fixture.debugElement.query(By.css('.grid'));
      expect(grid.nativeElement.classList.contains('gap-3')).toBe(true);
    });

    it('should render correct number of cards', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      expect(cards.length).toBe(mockProducts.length);
    });
  });

  describe('Card Structure', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should have full height cards with flex layout', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        expect(card.nativeElement.classList.contains('h-full')).toBe(true);
        expect(card.nativeElement.classList.contains('flex')).toBe(true);
        expect(card.nativeElement.classList.contains('flex-col')).toBe(true);
      });
    });

    it('should have shadow and hover effect', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        expect(card.nativeElement.classList.contains('shadow')).toBe(true);
        expect(card.nativeElement.classList.contains('hover:shadow-md')).toBe(true);
        expect(card.nativeElement.classList.contains('transition-shadow')).toBe(true);
      });
    });

    it('should have cursor pointer', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        expect(card.nativeElement.classList.contains('cursor-pointer')).toBe(true);
      });
    });

    it('should have rounded corners', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        expect(card.nativeElement.classList.contains('rounded-lg')).toBe(true);
      });
    });
  });

  describe('Card Header', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should display product name as h3', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach((card, index) => {
        const heading = card.query(By.css('h3'));
        expect(heading).toBeTruthy();
        expect(heading.nativeElement.textContent.trim()).toBe(mockProducts[index].name);
        expect(heading.nativeElement.classList.contains('text-lg')).toBe(true);
        expect(heading.nativeElement.classList.contains('font-semibold')).toBe(true);
      });
    });

    it('should display category chip with outlined style', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach((card, index) => {
        const chips = card.queryAll(By.css('span.inline-flex'));
        const categoryChip = chips[0];
        expect(categoryChip.nativeElement.textContent.trim()).toBe(mockProducts[index].category);
        expect(categoryChip.nativeElement.classList.contains('border')).toBe(true);
        expect(categoryChip.nativeElement.classList.contains('border-gray-300')).toBe(true);
        expect(categoryChip.nativeElement.classList.contains('bg-white')).toBe(true);
      });
    });

    it('should display status chip with color', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach((card, index) => {
        const chips = card.queryAll(By.css('span.inline-flex'));
        const statusChip = chips[1];
        expect(statusChip.nativeElement.textContent.trim()).toBe(mockProducts[index].status);
      });
    });

    it('should have flex gap between chips', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        const chipContainer = card.query(By.css('.flex.gap-2'));
        expect(chipContainer).toBeTruthy();
        expect(chipContainer.nativeElement.classList.contains('flex-wrap')).toBe(true);
      });
    });
  });

  describe('Card Body', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should display class with label', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach((card, index) => {
        const classText = card.nativeElement.textContent;
        expect(classText).toContain('Class:');
        expect(classText).toContain(mockProducts[index].class);
      });
    });

    it('should display plan ID when it exists', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      const firstCard = cards[0]; // Has planId
      const cardText = firstCard.nativeElement.textContent;
      expect(cardText).toContain('Plan ID:');
      expect(cardText).toContain(mockProducts[0].planId);
    });

    it('should not display plan ID when it is empty', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      const secondCard = cards[1]; // Has empty planId
      const cardText = secondCard.nativeElement.textContent;
      expect(cardText).not.toContain('Plan ID:');
    });

    it('should have proper spacing in body section', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        const bodySection = card.query(By.css('.space-y-2'));
        expect(bodySection).toBeTruthy();
      });
    });
  });

  describe('Card Footer', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should display last updated by', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach((card, index) => {
        const cardText = card.nativeElement.textContent;
        expect(cardText).toContain('Updated by');
        expect(cardText).toContain(mockProducts[index].lastUpdatedBy);
      });
    });

    it('should display last updated on', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach((card, index) => {
        const cardText = card.nativeElement.textContent;
        expect(cardText).toContain(mockProducts[index].lastUpdatedOn);
      });
    });

    it('should have mt-auto to push footer to bottom', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        const footer = card.query(By.css('.mt-auto'));
        expect(footer).toBeTruthy();
        expect(footer.nativeElement.classList.contains('pt-2')).toBe(true);
      });
    });

    it('should have small text size', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        const footer = card.query(By.css('.mt-auto.pt-2'));
        expect(footer).toBeTruthy();
        expect(footer.nativeElement.classList.contains('text-xs')).toBe(true);
        expect(footer.nativeElement.classList.contains('text-gray-500')).toBe(true);
      });
    });
  });

  describe('Status Color Mapping', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should apply blue color for Configure status', () => {
      const color = component.getStatusColor('Configure');
      expect(color).toContain('bg-blue-600');
      expect(color).toContain('text-white');
    });

    it('should apply green color for Production status', () => {
      const color = component.getStatusColor('Production');
      expect(color).toContain('bg-green-600');
      expect(color).toContain('text-white');
    });

    it('should apply gray color for Draft status', () => {
      const color = component.getStatusColor('Draft');
      expect(color).toContain('bg-gray-400');
      expect(color).toContain('text-white');
    });

    it('should render status chips with correct color classes', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      
      // Check Configure status (first product)
      const configureChips = cards[0].queryAll(By.css('span.inline-flex'));
      const configureStatusChip = configureChips[1];
      expect(configureStatusChip.nativeElement.classList.contains('bg-blue-600')).toBe(true);
      
      // Check Production status (second product)
      const productionChips = cards[1].queryAll(By.css('span.inline-flex'));
      const productionStatusChip = productionChips[1];
      expect(productionStatusChip.nativeElement.classList.contains('bg-green-600')).toBe(true);
      
      // Check Draft status (third product)
      const draftChips = cards[2].queryAll(By.css('span.inline-flex'));
      const draftStatusChip = draftChips[1];
      expect(draftStatusChip.nativeElement.classList.contains('bg-gray-400')).toBe(true);
    });
  });

  describe('User Interactions', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should emit productClick event when card is clicked', () => {
      const emitSpy = jest.spyOn(component.productClick, 'emit');
      const firstCard = fixture.debugElement.query(By.css('.bg-white.rounded-lg'));
      
      firstCard.nativeElement.click();
      
      expect(emitSpy).toHaveBeenCalledWith(mockProducts[0]);
    });

    it('should emit correct product when different cards are clicked', () => {
      const emitSpy = jest.spyOn(component.productClick, 'emit');
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      
      cards[1].nativeElement.click();
      expect(emitSpy).toHaveBeenCalledWith(mockProducts[1]);
      
      cards[2].nativeElement.click();
      expect(emitSpy).toHaveBeenCalledWith(mockProducts[2]);
    });

    it('should emit productClick on Enter key', () => {
      const emitSpy = jest.spyOn(component.productClick, 'emit');
      const firstCard = fixture.debugElement.query(By.css('.bg-white.rounded-lg'));
      
      const event = new KeyboardEvent('keydown', { key: 'Enter' });
      firstCard.nativeElement.dispatchEvent(event);
      fixture.detectChanges();
      
      expect(emitSpy).toHaveBeenCalledWith(mockProducts[0]);
    });

    it('should emit productClick on Space key', () => {
      const emitSpy = jest.spyOn(component.productClick, 'emit');
      const firstCard = fixture.debugElement.query(By.css('.bg-white.rounded-lg'));
      
      const event = new KeyboardEvent('keydown', { key: ' ' });
      firstCard.nativeElement.dispatchEvent(event);
      fixture.detectChanges();
      
      expect(emitSpy).toHaveBeenCalledWith(mockProducts[0]);
    });
  });

  describe('Empty State Handling', () => {
    it('should render empty grid when products array is empty', () => {
      fixture.componentRef.setInput('products', []);
      fixture.detectChanges();
      
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      expect(cards.length).toBe(0);
    });

    it('should still render grid container when products array is empty', () => {
      fixture.componentRef.setInput('products', []);
      fixture.detectChanges();
      
      const grid = fixture.debugElement.query(By.css('.grid'));
      expect(grid).toBeTruthy();
    });
  });

  describe('Accessibility', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should have role="button" on cards', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        expect(card.nativeElement.getAttribute('role')).toBe('button');
      });
    });

    it('should have tabindex="0" on cards', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        expect(card.nativeElement.getAttribute('tabindex')).toBe('0');
      });
    });

    it('should have semantic heading for product name', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        const heading = card.query(By.css('h3'));
        expect(heading).toBeTruthy();
      });
    });
  });

  describe('Responsive Breakpoints', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should have 1 column on mobile (default)', () => {
      const grid = fixture.debugElement.query(By.css('.grid'));
      expect(grid.nativeElement.classList.contains('grid-cols-1')).toBe(true);
    });

    it('should have 2 columns on small screens', () => {
      const grid = fixture.debugElement.query(By.css('.grid'));
      expect(grid.nativeElement.classList.contains('sm:grid-cols-2')).toBe(true);
    });

    it('should not include the deprecated medium breakpoint column class', () => {
      const grid = fixture.debugElement.query(By.css('.grid'));
      expect(grid.nativeElement.classList.contains('md:grid-cols-3')).toBe(false);
    });

    it('should have 4 columns on large screens', () => {
      const grid = fixture.debugElement.query(By.css('.grid'));
      expect(grid.nativeElement.classList.contains('lg:grid-cols-4')).toBe(true);
    });
  });

  describe('Card Content Layout', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should have padding on card content', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        const content = card.query(By.css('.p-4'));
        expect(content).toBeTruthy();
      });
    });

    it('should have flex-grow on card content', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        const content = card.query(By.css('.flex-grow'));
        expect(content).toBeTruthy();
      });
    });

    it('should have proper margin on header section', () => {
      const cards = fixture.debugElement.queryAll(By.css('.bg-white.rounded-lg'));
      cards.forEach(card => {
        const header = card.query(By.css('.mb-4'));
        expect(header).toBeTruthy();
      });
    });
  });
});

// Made with Bob