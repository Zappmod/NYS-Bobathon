/**
 * Network tier configuration for a product
 * Defines the tier level and associated network name
 */
export interface NetworkTier {
  /** Tier level (e.g., 'Tier 1', 'Tier 2') */
  tier: string;
  /** Network name associated with this tier */
  network: string;
}

/**
 * Product category types
 * Represents the main benefit categories available in the system
 */
export type ProductCategory = 'Medical' | 'Dental' ;

/**
 * Product status types
 * Represents the current state of a product in its lifecycle
 */
export type ProductStatus = 'Configure' | 'Production' | 'Draft';

/**
 * Template availability indicator
 * Indicates whether a template is available for this product
 */
export type TemplateAvailability = 'Yes' | 'No';

/**
 * Product interface
 * Represents a benefit product with all its configuration details
 */
export interface Product {
  /** Unique identifier for the product */
  id: string;
  /** Product name */
  name: string;
  /** Product category (Medical, Dental) */
  category: ProductCategory;
  /** Product class/type */
  class: string;
  /** Indicates if a template is available */
  templateAvailability: TemplateAvailability;
  /** Current status of the product */
  status: ProductStatus;
  /** Plan identifier */
  planId: string;
  /** Business line identifier */
  blid: string;
  /** User who last updated the product */
  lastUpdatedBy: string;
  /** Date when the product was last updated (Format: MM/DD/YYYY) */
  lastUpdatedOn: string;
  /** Date when the product becomes effective (Format: MM/DD/YYYY) */
  effectiveDate: string;
  /** Name of the associated document */
  documentName: string;
  /** State where the product is applicable */
  state: string;
  /** Network tier configurations */
  network: NetworkTier[];
  /** Internal plan identifier */
  planInternalId: string;
  /** Product description */
  description: string;
  /** Source of the product configuration */
  configurationSource: string;
}

/**
 * Product filters interface
 * Defines the available filters for product search and filtering
 */
export interface ProductFilters {
  /** Search query string for filtering products by name or other text fields */
  searchQuery: string;
  /** Filter by product category (empty string means all categories) */
  category: string;
  /** Filter by product status (empty string means all statuses) */
  status: string;
}

/**
 * Pagination state interface
 * Manages pagination state for product lists
 */
export interface PaginationState {
  /** Current page number (1-based) */
  page: number;
  /** Number of items per page */
  pageSize: number;
  /** Total number of items across all pages */
  totalItems: number;
  /** Total number of pages */
  totalPages: number;
}

// Made with Bob
