import { Component, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Product } from '../../models/product.model';
import { getStatusColor } from '../../utils/product-status.util';

/**
 * Product Table Component
 * 
 * Displays products in a tabular format with 9 columns.
 * Provides clickable product names and color-coded status chips.
 * 
 * @example
 * ```html
 * <app-product-table 
 *   [products]="products()"
 *   (productClick)="handleProductClick($event)">
 * </app-product-table>
 * ```
 */
@Component({
  selector: 'app-product-table',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-table.component.html',
})
export class ProductTableComponent {
  /**
   * Array of products to display in the table
   */
  products = input.required<Product[]>();

  /**
   * Event emitted when a product name is clicked
   */
  productClick = output<Product>();

  /**
   * Get Tailwind CSS classes for status badge styling
   * 
   * @param status - The product status
   * @returns Tailwind CSS class string
   */
  getStatusColor(status: string): string {
    return getStatusColor(status as any);
  }

  /**
   * Handle product name click
   * 
   * @param product - The clicked product
   */
  onProductClick(product: Product): void {
    this.productClick.emit(product);
  }

  /**
   * Format cell value, returning '-' for empty/null values
   * 
   * @param value - The cell value
   * @returns Formatted value or '-'
   */
  formatCellValue(value: string | null | undefined): string {
    return value || '-';
  }
}

// Made with Bob