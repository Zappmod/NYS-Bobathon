import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';
import { signal } from '@angular/core';
import { ProductsComponent } from './products.component';
import { ProductsService } from '../../services/products.service';
import { AuthService } from '../../../auth/services/auth.service';
import { Product } from '../../models/product.model';
import { User } from '../../../auth/models/user.model';

describe('ProductsComponent', () => {
  let component: ProductsComponent;
  let fixture: ComponentFixture<ProductsComponent>;
  let mockProductsService: jest.Mocked<ProductsService>;
  let mockAuthService: Partial<AuthService>;
  let mockRouter: jest.Mocked<Router>;

  const mockUser: User = {
    id: '1',
    name: 'Test User',
    email: 'test@example.com',
    role: 'Benefit Developer',
    canEdit: true,
  };

  const mockProducts: Product[] = [
    {
      id: '1',
      name: 'Medical Plan A',
      category: 'Medical',
      class: 'PPO',
      state: 'California',
      status: 'Production',
      planId: 'PLAN-001',
      planInternalId: 'MED-001',
      blid: 'BL-001',
      effectiveDate: '2024-01-01',
      templateAvailability: 'Yes',
      description: 'Test medical plan',
      documentName: 'doc1.pdf',
      configurationSource: 'Product A',
      network: [{ tier: 'Tier 1', network: 'Network A' }],
      lastUpdatedBy: 'BENTEST120',
      lastUpdatedOn: '01/15/2024',
    },
    {
      id: '2',
      name: 'Dental Plan B',
      category: 'Dental',
      class: 'HMO',
      state: 'Texas',
      status: 'Configure',
      planId: 'PLAN-002',
      planInternalId: 'DEN-002',
      blid: 'BL-002',
      effectiveDate: '2024-02-01',
      templateAvailability: 'No',
      description: 'Test dental plan',
      documentName: 'doc2.pdf',
      configurationSource: 'Product B',
      network: [{ tier: 'Tier 1', network: 'Network B' }],
      lastUpdatedBy: 'BENTEST120',
      lastUpdatedOn: '02/15/2024',
    },
    {
      id: '3',
      name: 'Vision Plan C',
      category: 'Vision',
      class: 'PPO',
      state: 'New York',
      status: 'Draft',
      planId: 'PLAN-003',
      planInternalId: 'VIS-003',
      blid: 'BL-003',
      effectiveDate: '2024-03-01',
      templateAvailability: 'Yes',
      description: 'Test vision plan',
      documentName: 'doc3.pdf',
      configurationSource: 'Product C',
      network: [{ tier: 'Tier 1', network: 'Network C' }],
      lastUpdatedBy: 'BENTEST120',
      lastUpdatedOn: '03/15/2024',
    },
  ];

  beforeEach(async () => {
    mockProductsService = {
      getProducts: jest.fn().mockReturnValue(of(mockProducts)),
      getProductById: jest.fn(),
      createProduct: jest.fn(),
      updateProduct: jest.fn(),
      deleteProduct: jest.fn(),
      resetProducts: jest.fn(),
    } as any;

    mockAuthService = {
      user: signal(mockUser),
      logout: jest.fn(),
      getUserPermissions: jest.fn().mockReturnValue([]),
    };

    mockRouter = {
      navigate: jest.fn(),
    } as any;

    await TestBed.configureTestingModule({
      imports: [ProductsComponent],
      providers: [
        { provide: ProductsService, useValue: mockProductsService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: Router, useValue: mockRouter },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(ProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Initialization', () => {
    it('should load products on init', () => {
      expect(mockProductsService.getProducts).toHaveBeenCalled();
      expect(component.products().length).toBe(3);
    });

    it('should initialize with default state', () => {
      expect(component.viewMode()).toBe('card');
      expect(component.searchQuery()).toBe('');
      expect(component.categoryFilter()).toBe('All');
      expect(component.statusFilter()).toBe('All');
      expect(component.page()).toBe(1);
      expect(component.pageSize()).toBe(10);
      expect(component.selectedProduct()).toBeNull();
      expect(component.detailsModalOpen()).toBe(false);
      expect(component.formModalOpen()).toBe(false);
      expect(component.formMode()).toBe('add');
    });

    it('should handle products loading error', () => {
      const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
      mockProductsService.getProducts.mockReturnValue(
        throwError(() => new Error('Load error'))
      );

      component.ngOnInit();

      expect(consoleErrorSpy).toHaveBeenCalledWith(
        'Error loading products:',
        expect.any(Error)
      );
    });
  });

  describe('Computed Signals', () => {
    describe('filteredProducts', () => {
      it('should filter products by search query', () => {
        component.onSearchChange('medical');
        expect(component.filteredProducts().length).toBe(1);
        expect(component.filteredProducts()[0].name).toBe('Medical Plan A');
      });

      it('should filter products by category', () => {
        component.onCategoryChange('Dental');
        expect(component.filteredProducts().length).toBe(1);
        expect(component.filteredProducts()[0].category).toBe('Dental');
      });

      it('should filter products by status', () => {
        component.onStatusChange('Production');
        expect(component.filteredProducts().length).toBe(1);
        expect(component.filteredProducts()[0].status).toBe('Production');
      });

      it('should filter products by multiple criteria', () => {
        component.onSearchChange('plan');
        component.onCategoryChange('Medical');
        component.onStatusChange('Production');
        expect(component.filteredProducts().length).toBe(1);
      });

      it('should return all products when filters are "All"', () => {
        component.onCategoryChange('All');
        component.onStatusChange('All');
        component.onSearchChange('');
        expect(component.filteredProducts().length).toBe(3);
      });

      it('should be case-insensitive for search', () => {
        component.onSearchChange('MEDICAL');
        expect(component.filteredProducts().length).toBe(1);
      });

      it('should expose filtered count for the current filter set', () => {
        component.onCategoryChange('Vision');
        expect(component.filteredCount()).toBe(1);
      });
    });

    describe('paginatedProducts', () => {
      it('should paginate filtered products', () => {
        component.onPageSizeChange(2);
        expect(component.paginatedProducts().length).toBe(2);
      });

      it('should show correct products for page 2', () => {
        component.onPageSizeChange(2);
        component.onPageChange(2);
        expect(component.paginatedProducts().length).toBe(1);
        expect(component.paginatedProducts()[0].id).toBe('3');
      });

      it('should handle empty results', () => {
        component.onSearchChange('nonexistent');
        expect(component.paginatedProducts().length).toBe(0);
      });
    });

    describe('totalPages', () => {
      it('should calculate total pages correctly', () => {
        component.onPageSizeChange(2);
        expect(component.totalPages()).toBe(2);
      });

      it('should return 0 for empty results', () => {
        component.onSearchChange('nonexistent');
        expect(component.totalPages()).toBe(0);
      });

      it('should round up for partial pages', () => {
        component.onPageSizeChange(2);
        expect(component.totalPages()).toBe(2); // 3 products / 2 per page = 2 pages
      });
    });

    describe('paginationText', () => {
      it('should display correct range for first page', () => {
        component.onPageSizeChange(2);
        expect(component.paginationText()).toBe('1 - 2 of 3');
      });

      it('should display correct range for last page', () => {
        component.onPageSizeChange(2);
        component.onPageChange(2);
        expect(component.paginationText()).toBe('3 - 3 of 3');
      });

      it('should handle empty results', () => {
        component.onSearchChange('nonexistent');
        expect(component.paginationText()).toBe('0 - 0 of 0');
      });
    });

    describe('pagination display signals', () => {
      it('should expose total items text', () => {
        expect(component.totalItemsText()).toBe('3 items total');
      });

      it('should singularize total items text for one item', () => {
        component.onCategoryChange('Dental');
        expect(component.totalItemsText()).toBe('1 item total');
      });

      it('should expose current page indicator', () => {
        component.onPageSizeChange(2);
        component.onPageChange(2);
        expect(component.currentPageIndicator()).toBe('Page 2 of 2');
      });

      it('should expose empty page indicator when there are no results', () => {
        component.onSearchChange('nonexistent');
        expect(component.currentPageIndicator()).toBe('Page 0 of 0');
      });

      it('should indicate whether pagination controls should be shown', () => {
        expect(component.hasPagination()).toBe(true);

        component.onSearchChange('nonexistent');
        expect(component.hasPagination()).toBe(false);
      });
    });

    describe('canEdit', () => {
      it('should return true when user can edit', () => {
        expect(component.canEdit()).toBe(true);
      });

      it('should return false when user cannot edit', async () => {
        const readOnlyUser = { ...mockUser, canEdit: false };
        const readOnlyAuthService = {
          user: signal(readOnlyUser),
          logout: jest.fn(),
          getUserPermissions: jest.fn().mockReturnValue([]),
        };

        await TestBed.resetTestingModule();
        await TestBed.configureTestingModule({
          imports: [ProductsComponent],
          providers: [
            { provide: ProductsService, useValue: mockProductsService },
            { provide: AuthService, useValue: readOnlyAuthService },
            { provide: Router, useValue: mockRouter },
          ],
        }).compileComponents();

        const readOnlyFixture = TestBed.createComponent(ProductsComponent);
        const readOnlyComponent = readOnlyFixture.componentInstance;
        readOnlyFixture.detectChanges();

        expect(readOnlyComponent.canEdit()).toBe(false);
      });

      it('should return false when user is null', async () => {
        const nullUserAuthService = {
          user: signal(null),
          logout: jest.fn(),
          getUserPermissions: jest.fn().mockReturnValue([]),
        };

        await TestBed.resetTestingModule();
        await TestBed.configureTestingModule({
          imports: [ProductsComponent],
          providers: [
            { provide: ProductsService, useValue: mockProductsService },
            { provide: AuthService, useValue: nullUserAuthService },
            { provide: Router, useValue: mockRouter },
          ],
        }).compileComponents();

        const nullUserFixture = TestBed.createComponent(ProductsComponent);
        const nullUserComponent = nullUserFixture.componentInstance;
        nullUserFixture.detectChanges();

        expect(nullUserComponent.canEdit()).toBe(false);
      });
    });
  });

  describe('Filter Actions', () => {
    it('should update search query and reset page', () => {
      component.onPageChange(2);
      component.onSearchChange('test');
      expect(component.searchQuery()).toBe('test');
      expect(component.page()).toBe(1);
    });

    it('should update category filter and reset page', () => {
      component.onPageChange(2);
      component.onCategoryChange('Medical');
      expect(component.categoryFilter()).toBe('Medical');
      expect(component.page()).toBe(1);
    });

    it('should update status filter and reset page', () => {
      component.onPageChange(2);
      component.onStatusChange('Production');
      expect(component.statusFilter()).toBe('Production');
      expect(component.page()).toBe(1);
    });

    it('should reset to page 1 when multiple filters are changed sequentially', () => {
      component.onPageSizeChange(1);
      component.onPageChange(3);

      component.onSearchChange('plan');
      expect(component.page()).toBe(1);

      component.onPageChange(2);
      component.onCategoryChange('Dental');
      expect(component.page()).toBe(1);

      component.onPageChange(2);
      component.onStatusChange('Configure');
      expect(component.page()).toBe(1);
    });
  });

  describe('View Mode', () => {
    it('should default to card view state', () => {
      expect(component.viewMode()).toBe('card');
      expect(component.isCardView()).toBe(true);
      expect(component.isTableView()).toBe(false);
    });

    it('should toggle to table view', () => {
      component.onViewModeChange('table');
      expect(component.viewMode()).toBe('table');
      expect(component.isTableView()).toBe(true);
      expect(component.isCardView()).toBe(false);
    });

    it('should toggle to card view', () => {
      component.onViewModeChange('table');
      component.onViewModeChange('card');
      expect(component.viewMode()).toBe('card');
      expect(component.isCardView()).toBe(true);
      expect(component.isTableView()).toBe(false);
    });

    it('should render card view by default', () => {
      const compiled = fixture.nativeElement as HTMLElement;
      expect(compiled.querySelector('app-product-card-view')).not.toBeNull();
      expect(compiled.querySelector('app-product-table')).toBeNull();
    });

    it('should render table view when toggled', () => {
      component.onViewModeChange('table');
      fixture.detectChanges();

      const compiled = fixture.nativeElement as HTMLElement;
      expect(compiled.querySelector('app-product-table')).not.toBeNull();
      expect(compiled.querySelector('app-product-card-view')).toBeNull();
    });

    it('should set aria-pressed correctly on toggle buttons', () => {
      let buttons = fixture.nativeElement.querySelectorAll('button[aria-pressed]');
      expect(buttons[0].getAttribute('aria-pressed')).toBe('false');
      expect(buttons[1].getAttribute('aria-pressed')).toBe('true');

      component.onViewModeChange('table');
      fixture.detectChanges();

      buttons = fixture.nativeElement.querySelectorAll('button[aria-pressed]');
      expect(buttons[0].getAttribute('aria-pressed')).toBe('true');
      expect(buttons[1].getAttribute('aria-pressed')).toBe('false');
    });
  });

  describe('Pagination', () => {
    it('should expose supported page size options', () => {
      expect(component.pageSizes).toEqual([10, 25, 50]);
    });

    it('should change page size and reset to page 1', () => {
      component.onPageSizeChange(1);
      component.onPageChange(2);

      component.onPageSizeChange(25);

      expect(component.pageSize()).toBe(25);
      expect(component.page()).toBe(1);
    });

    it('should change page within valid range', () => {
      component.onPageSizeChange(2); // Set page size to 2, creating 2 pages
      component.onPageChange(2);
      expect(component.page()).toBe(2);
    });

    it('should not change page below 1', () => {
      component.onPageChange(0);
      expect(component.page()).toBe(1);
    });

    it('should not change page above total pages', () => {
      component.onPageSizeChange(2);
      component.onPageChange(10);
      expect(component.page()).toBe(1);
    });

    it('should move to the first page when requested', () => {
      component.onPageSizeChange(1);
      component.onPageChange(3);

      component.onPageChange(1);

      expect(component.page()).toBe(1);
    });

    it('should move to the last page when requested', () => {
      component.onPageSizeChange(2);

      component.onPageChange(component.totalPages());

      expect(component.page()).toBe(2);
    });

    it('should keep the current page unchanged when there are no pages', () => {
      component.onSearchChange('nonexistent');
      component.onPageChange(1);

      expect(component.page()).toBe(1);
      expect(component.totalPages()).toBe(0);
    });

    it('should get correct page numbers array', () => {
      component.onPageSizeChange(1);
      const pageNumbers = component.getPageNumbers();
      expect(pageNumbers).toEqual([1, 2, 3]);
    });

    it('should return an empty page numbers array when there are no pages', () => {
      component.onSearchChange('nonexistent');
      expect(component.getPageNumbers()).toEqual([]);
    });
  });

  describe('Product Interactions', () => {
    it('should open details modal when product clicked', () => {
      const product = mockProducts[0];
      component.onProductClick(product);
      expect(component.selectedProduct()).toBe(product);
      expect(component.detailsModalOpen()).toBe(true);
    });

    it('should open form modal in add mode', () => {
      component.onAddProduct();
      expect(component.formMode()).toBe('add');
      expect(component.selectedProduct()).toBeNull();
      expect(component.formModalOpen()).toBe(true);
    });

    it('should switch to edit mode from details modal', () => {
      component.selectedProduct.set(mockProducts[0]);
      component.detailsModalOpen.set(true);
      component.onEditProduct();
      expect(component.formMode()).toBe('edit');
      expect(component.detailsModalOpen()).toBe(false);
      expect(component.formModalOpen()).toBe(true);
    });

    it('should close details modal', () => {
      component.detailsModalOpen.set(true);
      component.onDetailsModalClose();
      expect(component.detailsModalOpen()).toBe(false);
    });

    it('should close form modal', () => {
      component.formModalOpen.set(true);
      component.onFormModalClose();
      expect(component.formModalOpen()).toBe(false);
    });
  });

  describe('Product CRUD Operations', () => {
    it('should create new product', () => {
      const newProduct: Product = {
        ...mockProducts[0],
        id: '4',
        name: 'New Product',
      };
      mockProductsService.createProduct.mockReturnValue(of(newProduct));
      component.formModalOpen.set(true);

      component.formMode.set('add');
      component.onSaveProduct({ name: 'New Product' });

      expect(mockProductsService.createProduct).toHaveBeenCalledWith(
        expect.objectContaining({
          name: 'New Product',
          lastUpdatedBy: '1',
        })
      );
      expect(component.products().length).toBe(4);
      expect(component.products()[0].name).toBe('New Product');
      expect(component.products()[0]).toEqual(newProduct);
      expect(component.selectedProduct()).toEqual(newProduct);
      expect(component.formModalOpen()).toBe(false);
    });

    it('should handle create product error', () => {
      const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
      mockProductsService.createProduct.mockReturnValue(
        throwError(() => new Error('Create error'))
      );
      component.formModalOpen.set(true);

      component.formMode.set('add');
      component.onSaveProduct({ name: 'New Product' });

      expect(consoleErrorSpy).toHaveBeenCalledWith(
        'Error creating product:',
        expect.any(Error)
      );
      expect(component.formModalOpen()).toBe(true);
    });

    it('should update existing product', () => {
      const updatedProduct: Product = {
        ...mockProducts[0],
        name: 'Updated Product',
      };
      mockProductsService.updateProduct.mockReturnValue(of(updatedProduct));
      component.formModalOpen.set(true);
      component.detailsModalOpen.set(true);

      component.formMode.set('edit');
      component.selectedProduct.set(mockProducts[0]);
      component.onSaveProduct({ name: 'Updated Product' });

      expect(mockProductsService.updateProduct).toHaveBeenCalledWith(
        '1',
        {
          name: 'Updated Product',
          lastUpdatedBy: '1',
        }
      );
      expect(component.products()[0].name).toBe('Updated Product');
      expect(component.selectedProduct()).toEqual(updatedProduct);
      expect(component.formModalOpen()).toBe(false);
      expect(component.detailsModalOpen()).toBe(false);
    });

    it('should handle update product error', () => {
      const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
      mockProductsService.updateProduct.mockReturnValue(
        throwError(() => new Error('Update error'))
      );
      component.formModalOpen.set(true);
      component.detailsModalOpen.set(true);

      component.formMode.set('edit');
      component.selectedProduct.set(mockProducts[0]);
      component.onSaveProduct({ name: 'Updated Product' });

      expect(consoleErrorSpy).toHaveBeenCalledWith(
        'Error updating product:',
        expect.any(Error)
      );
      expect(component.formModalOpen()).toBe(true);
      expect(component.detailsModalOpen()).toBe(true);
    });

    it('should not update if no product selected in edit mode', () => {
      component.formMode.set('edit');
      component.selectedProduct.set(null);
      component.onSaveProduct({ name: 'Updated Product' });

      expect(mockProductsService.updateProduct).not.toHaveBeenCalled();
    });

    it('should fall back to default lastUpdatedBy when auth user is null during create', async () => {
      const createResponse: Product = {
        ...mockProducts[0],
        id: '4',
        name: 'Fallback Product',
        lastUpdatedBy: 'BENTEST120',
      };

      await TestBed.resetTestingModule();
      await TestBed.configureTestingModule({
        imports: [ProductsComponent],
        providers: [
          { provide: ProductsService, useValue: { ...mockProductsService, createProduct: jest.fn().mockReturnValue(of(createResponse)) } },
          {
            provide: AuthService,
            useValue: {
              user: signal(null),
              logout: jest.fn(),
              getUserPermissions: jest.fn().mockReturnValue([]),
            },
          },
          { provide: Router, useValue: mockRouter },
        ],
      }).compileComponents();

      const localFixture = TestBed.createComponent(ProductsComponent);
      const localComponent = localFixture.componentInstance;
      const localProductsService = TestBed.inject(ProductsService) as jest.Mocked<ProductsService>;

      localFixture.detectChanges();
      localComponent.formMode.set('add');
      localComponent.onSaveProduct({ name: 'Fallback Product' });

      expect(localProductsService.createProduct).toHaveBeenCalledWith(
        expect.objectContaining({
          name: 'Fallback Product',
          lastUpdatedBy: 'BENTEST120',
        })
      );
    });

    it('should fall back to default lastUpdatedBy when auth user is null during update', async () => {
      const updateResponse: Product = {
        ...mockProducts[0],
        name: 'Fallback Updated Product',
        lastUpdatedBy: 'BENTEST120',
      };

      await TestBed.resetTestingModule();
      await TestBed.configureTestingModule({
        imports: [ProductsComponent],
        providers: [
          { provide: ProductsService, useValue: { ...mockProductsService, updateProduct: jest.fn().mockReturnValue(of(updateResponse)) } },
          {
            provide: AuthService,
            useValue: {
              user: signal(null),
              logout: jest.fn(),
              getUserPermissions: jest.fn().mockReturnValue([]),
            },
          },
          { provide: Router, useValue: mockRouter },
        ],
      }).compileComponents();

      const localFixture = TestBed.createComponent(ProductsComponent);
      const localComponent = localFixture.componentInstance;
      const localProductsService = TestBed.inject(ProductsService) as jest.Mocked<ProductsService>;

      localFixture.detectChanges();
      localComponent.formMode.set('edit');
      localComponent.selectedProduct.set(mockProducts[0]);
      localComponent.onSaveProduct({ name: 'Fallback Updated Product' });

      expect(localProductsService.updateProduct).toHaveBeenCalledWith(
        '1',
        {
          name: 'Fallback Updated Product',
          lastUpdatedBy: 'BENTEST120',
        }
      );
    });
  });

  describe('Responsive Design', () => {
    it('should render mobile-first stacked filter controls with full-width inputs', () => {
      const compiled = fixture.nativeElement as HTMLElement;
      const searchInput = compiled.querySelector('input[placeholder="Search Products"]');
      const categorySelect = compiled.querySelector('select');
      const viewToggle = compiled.querySelector('button[title="Table View"]')?.parentElement;

      expect(searchInput?.className).toContain('w-full');
      expect(searchInput?.className).toContain('min-h-11');
      expect(categorySelect?.className).toContain('w-full');
      expect(categorySelect?.className).toContain('min-h-11');
      expect(viewToggle?.className).toContain('w-full');
      expect(viewToggle?.className).toContain('sm:w-auto');
    });

    it('should keep responsive card grid breakpoints aligned with the spec', () => {
      const cardGrid = fixture.nativeElement.querySelector('app-product-card-view > div') as HTMLElement;

      expect(cardGrid.className).toContain('grid-cols-1');
      expect(cardGrid.className).toContain('sm:grid-cols-2');
      expect(cardGrid.className).toContain('lg:grid-cols-4');
      expect(cardGrid.className).not.toContain('md:grid-cols-3');
    });

    it('should keep the AI assistant FAB touch-friendly and repositioned by breakpoint', () => {
      const fab = fixture.nativeElement.querySelector('button[aria-label="AI Assistant"]') as HTMLButtonElement;

      expect(fab.className).toContain('w-14');
      expect(fab.className).toContain('h-14');
      expect(fab.className).toContain('bottom-4');
      expect(fab.className).toContain('sm:bottom-6');
      expect(fab.className).toContain('lg:bottom-8');
    });
  });

  describe('AI Assistant', () => {
    it('should show toast on AI assistant click', () => {
      const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
      component.onAIAssistantClick();
      expect(consoleLogSpy).toHaveBeenCalledWith(
        'Toast:',
        'AI Assistant: How can I help you manage your benefit products?'
      );
    });

    it('should render an accessible AI assistant FAB', () => {
      const fab = fixture.nativeElement.querySelector('button[aria-label="AI Assistant"]') as HTMLButtonElement;

      expect(fab).not.toBeNull();
      expect(fab.getAttribute('type')).toBe('button');
      expect(fab.getAttribute('title')).toBe('AI Assistant');
    });

    it('should invoke the click handler when the AI assistant FAB is clicked', () => {
      const clickSpy = jest.spyOn(component, 'onAIAssistantClick');
      const fab = fixture.nativeElement.querySelector('button[aria-label="AI Assistant"]') as HTMLButtonElement;

      fab.click();

      expect(clickSpy).toHaveBeenCalled();
    });
  });

  describe('Toast Handling', () => {
    it('should log a toast message for successful product creation', () => {
      const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
      const newProduct: Product = {
        ...mockProducts[0],
        id: '4',
        name: 'Created Product',
      };

      mockProductsService.createProduct.mockReturnValue(of(newProduct));
      component.formMode.set('add');

      component.onSaveProduct({ name: 'Created Product' });

      expect(consoleLogSpy).toHaveBeenCalledWith('Toast:', 'Product created successfully!');
    });

    it('should log a toast message for successful product update', () => {
      const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
      const updatedProduct: Product = {
        ...mockProducts[0],
        name: 'Updated Product',
      };

      mockProductsService.updateProduct.mockReturnValue(of(updatedProduct));
      component.formMode.set('edit');
      component.selectedProduct.set(mockProducts[0]);

      component.onSaveProduct({ name: 'Updated Product' });

      expect(consoleLogSpy).toHaveBeenCalledWith('Toast:', 'Product updated successfully!');
    });

    it('should log an error toast when product creation fails', () => {
      const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
      mockProductsService.createProduct.mockReturnValue(
        throwError(() => new Error('Create error'))
      );

      component.formMode.set('add');
      component.onSaveProduct({ name: 'Broken Product' });

      expect(consoleLogSpy).toHaveBeenCalledWith('Toast:', 'Error creating product');
    });

    it('should log an error toast when product update fails', () => {
      const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
      mockProductsService.updateProduct.mockReturnValue(
        throwError(() => new Error('Update error'))
      );

      component.formMode.set('edit');
      component.selectedProduct.set(mockProducts[0]);
      component.onSaveProduct({ name: 'Broken Product' });

      expect(consoleLogSpy).toHaveBeenCalledWith('Toast:', 'Error updating product');
    });
  });

  describe('Logout', () => {
    it('should logout and navigate to login', () => {
      component.onLogout();
      expect(mockAuthService.logout).toHaveBeenCalled();
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/login']);
    });
  });
});

// Made with Bob