import { Component, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Product } from '../../models/product.model';
import { getStatusColor } from '../../utils/product-status.util';

/**
 * Product Card View Component
 * 
 * Displays products in a responsive grid layout with card-based UI.
 * Cards show key product information and are fully clickable.
 * 
 * @example
 * ```html
 * <app-product-card-view 
 *   [products]="products()"
 *   (productClick)="handleProductClick($event)">
 * </app-product-card-view>
 * ```
 */
@Component({
  selector: 'app-product-card-view',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-card-view.component.html',
})
export class ProductCardViewComponent {
  /**
   * Array of products to display in card view
   */
  products = input.required<Product[]>();

  /**
   * Event emitted when a product card is clicked
   */
  productClick = output<Product>();

  /**
   * Get Tailwind CSS classes for status badge styling
   * 
   * @param status - The product status
   * @returns Tailwind CSS class string
   */
  getStatusColor(status: string): string {
    return getStatusColor(status as any);
  }

  /**
   * Handle product card click
   * 
   * @param product - The clicked product
   */
  onProductClick(product: Product): void {
    this.productClick.emit(product);
  }
}

// Made with Bob