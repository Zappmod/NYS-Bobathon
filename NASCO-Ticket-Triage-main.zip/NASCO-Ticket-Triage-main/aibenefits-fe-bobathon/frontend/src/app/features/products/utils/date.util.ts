/**
 * Date utility functions for product date formatting and validation
 */

/**
 * Formats a date string from YYYY-MM-DD to MM/DD/YYYY format
 * @param dateStr - Date string in YYYY-MM-DD format
 * @returns Formatted date string in MM/DD/YYYY format, or original string if format is unrecognized
 * @example
 * formatDateToDisplay('2024-03-15') // Returns '03/15/2024'
 * formatDateToDisplay('') // Returns ''
 * formatDateToDisplay('invalid') // Returns 'invalid'
 */
export function formatDateToDisplay(dateStr: string): string {
  if (!dateStr) {
    return '';
  }

  // Check if the string matches YYYY-MM-DD format
  const isoDatePattern = /^\d{4}-\d{2}-\d{2}$/;
  if (!isoDatePattern.test(dateStr)) {
    return dateStr;
  }

  const [year, month, day] = dateStr.split('-');
  const yearNum = parseInt(year);
  const monthNum = parseInt(month);
  const dayNum = parseInt(day);
  
  // Validate month is between 1-12
  if (monthNum < 1 || monthNum > 12) {
    return dateStr;
  }

  // Validate day is between 1-31
  if (dayNum < 1 || dayNum > 31) {
    return dateStr;
  }

  // Create a date and verify it's valid
  const date = new Date(yearNum, monthNum - 1, dayNum);
  
  // Check if the date is valid and matches the input
  // This catches cases like 2024-02-31 which would roll over to 2024-03-02
  if (
    isNaN(date.getTime()) ||
    date.getFullYear() !== yearNum ||
    date.getMonth() !== monthNum - 1 ||
    date.getDate() !== dayNum
  ) {
    return dateStr;
  }

  // Ensure month and day are padded with leading zeros
  const paddedMonth = month.padStart(2, '0');
  const paddedDay = day.padStart(2, '0');

  return `${paddedMonth}/${paddedDay}/${year}`;
}

/**
 * Formats a date string from MM/DD/YYYY to YYYY-MM-DD format
 * @param dateStr - Date string in MM/DD/YYYY format
 * @returns Formatted date string in YYYY-MM-DD format, or original string if format is unrecognized
 * @example
 * formatDateToStore('03/15/2024') // Returns '2024-03-15'
 * formatDateToStore('') // Returns ''
 * formatDateToStore('invalid') // Returns 'invalid'
 */
export function formatDateToStore(dateStr: string): string {
  if (!dateStr) {
    return '';
  }

  // Check if the string matches MM/DD/YYYY format
  const usDatePattern = /^\d{1,2}\/\d{1,2}\/\d{4}$/;
  if (!usDatePattern.test(dateStr)) {
    return dateStr;
  }

  const [month, day, year] = dateStr.split('/');
  const monthNum = parseInt(month);
  const dayNum = parseInt(day);
  const yearNum = parseInt(year);
  
  // Validate month is between 1-12
  if (monthNum < 1 || monthNum > 12) {
    return dateStr;
  }

  // Validate day is between 1-31
  if (dayNum < 1 || dayNum > 31) {
    return dateStr;
  }

  // Create a date and verify it's valid
  const date = new Date(yearNum, monthNum - 1, dayNum);
  
  // Check if the date is valid and matches the input
  // This catches cases like 02/31/2024 which would roll over to 03/02/2024
  if (
    isNaN(date.getTime()) ||
    date.getFullYear() !== yearNum ||
    date.getMonth() !== monthNum - 1 ||
    date.getDate() !== dayNum
  ) {
    return dateStr;
  }

  // Ensure month and day are padded with leading zeros
  const paddedMonth = month.padStart(2, '0');
  const paddedDay = day.padStart(2, '0');

  return `${year}-${paddedMonth}-${paddedDay}`;
}

/**
 * Validates if a date string is in MM/DD/YYYY format and represents a valid date
 * @param dateStr - Date string to validate
 * @returns true if the date string is valid MM/DD/YYYY format, false otherwise
 * @example
 * validateDateFormat('03/15/2024') // Returns true
 * validateDateFormat('2024-03-15') // Returns false
 * validateDateFormat('13/32/2024') // Returns false
 * validateDateFormat('') // Returns false
 */
export function validateDateFormat(dateStr: string): boolean {
  if (!dateStr) {
    return false;
  }

  // Check if the string matches MM/DD/YYYY format
  const usDatePattern = /^\d{1,2}\/\d{1,2}\/\d{4}$/;
  if (!usDatePattern.test(dateStr)) {
    return false;
  }

  const [month, day, year] = dateStr.split('/');
  const monthNum = parseInt(month);
  const dayNum = parseInt(day);
  const yearNum = parseInt(year);

  // Validate month is between 1-12
  if (monthNum < 1 || monthNum > 12) {
    return false;
  }

  // Validate day is between 1-31
  if (dayNum < 1 || dayNum > 31) {
    return false;
  }

  // Create a date and verify it's valid
  const date = new Date(yearNum, monthNum - 1, dayNum);
  
  // Check if the date is valid and matches the input
  // This catches cases like 02/31/2024 which would roll over to 03/02/2024
  return (
    !isNaN(date.getTime()) &&
    date.getFullYear() === yearNum &&
    date.getMonth() === monthNum - 1 &&
    date.getDate() === dayNum
  );
}

// Made with Bob
