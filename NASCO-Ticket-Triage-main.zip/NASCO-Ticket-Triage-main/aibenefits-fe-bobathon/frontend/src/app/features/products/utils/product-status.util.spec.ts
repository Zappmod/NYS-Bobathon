import { getStatusColor } from './product-status.util';
import { ProductStatus } from '../models/product.model';

describe('Product Status Utility', () => {
  describe('getStatusColor()', () => {
    it('should return blue classes for Configure status', () => {
      const result = getStatusColor('Configure');
      expect(result).toBe('bg-blue-600 text-white');
    });

    it('should return green classes for Production status', () => {
      const result = getStatusColor('Production');
      expect(result).toBe('bg-green-600 text-white');
    });

    it('should return gray classes for Draft status', () => {
      const result = getStatusColor('Draft');
      expect(result).toBe('bg-gray-400 text-white');
    });

    it('should handle all valid ProductStatus values', () => {
      const statuses: ProductStatus[] = ['Configure', 'Production', 'Draft'];
      
      statuses.forEach(status => {
        const result = getStatusColor(status);
        expect(result).toBeDefined();
        expect(typeof result).toBe('string');
        expect(result).toContain('bg-');
        expect(result).toContain('text-white');
      });
    });

    it('should return consistent results for same status', () => {
      const result1 = getStatusColor('Configure');
      const result2 = getStatusColor('Configure');
      expect(result1).toBe(result2);
    });

    it('should return different colors for different statuses', () => {
      const configureColor = getStatusColor('Configure');
      const productionColor = getStatusColor('Production');
      const draftColor = getStatusColor('Draft');

      expect(configureColor).not.toBe(productionColor);
      expect(configureColor).not.toBe(draftColor);
      expect(productionColor).not.toBe(draftColor);
    });

    it('should return valid Tailwind CSS classes', () => {
      const statuses: ProductStatus[] = ['Configure', 'Production', 'Draft'];
      
      statuses.forEach(status => {
        const result = getStatusColor(status);
        // Check format: should have bg- and text- classes
        expect(result).toMatch(/^bg-\w+-\d+\s+text-\w+$/);
      });
    });

    it('should include text-white for all statuses', () => {
      const statuses: ProductStatus[] = ['Configure', 'Production', 'Draft'];
      
      statuses.forEach(status => {
        const result = getStatusColor(status);
        expect(result).toContain('text-white');
      });
    });

    it('should return string type', () => {
      const result = getStatusColor('Configure');
      expect(typeof result).toBe('string');
    });

    it('should not return empty string', () => {
      const statuses: ProductStatus[] = ['Configure', 'Production', 'Draft'];
      
      statuses.forEach(status => {
        const result = getStatusColor(status);
        expect(result.length).toBeGreaterThan(0);
      });
    });
  });

  describe('Color Mapping Verification', () => {
    it('should map Configure to blue-600', () => {
      const result = getStatusColor('Configure');
      expect(result).toContain('blue-600');
    });

    it('should map Production to green-600', () => {
      const result = getStatusColor('Production');
      expect(result).toContain('green-600');
    });

    it('should map Draft to gray-400', () => {
      const result = getStatusColor('Draft');
      expect(result).toContain('gray-400');
    });
  });

  describe('Edge Cases', () => {
    it('should handle default case gracefully', () => {
      // TypeScript prevents invalid values, but testing the default case
      const result = getStatusColor('Draft');
      expect(result).toBeDefined();
      expect(result).toBe('bg-gray-400 text-white');
    });
  });
});

// Made with Bob