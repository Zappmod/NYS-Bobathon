import { ProductStatus } from '../models/product.model';

/**
 * Get Tailwind CSS classes for product status badge styling
 * 
 * Maps product status values to appropriate background and text color classes
 * for consistent visual representation across the application.
 * 
 * @param status - The product status value
 * @returns Tailwind CSS class string for background and text colors
 * 
 * @example
 * ```typescript
 * const classes = getStatusColor('Configure');
 * // Returns: 'bg-blue-600 text-white'
 * ```
 */
export function getStatusColor(status: ProductStatus): string {
  switch (status) {
    case 'Configure':
      return 'bg-blue-600 text-white';
    case 'Production':
      return 'bg-green-600 text-white';
    case 'Draft':
      return 'bg-gray-400 text-white';
    default:
      // Fallback for any unexpected status values
      return 'bg-gray-400 text-white';
  }
}

// Made with Bob