import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProductTableComponent } from './product-table.component';
import { Product } from '../../models/product.model';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('ProductTableComponent', () => {
  let component: ProductTableComponent;
  let fixture: ComponentFixture<ProductTableComponent>;

  const mockProducts: Product[] = [
    {
      id: '1',
      name: 'Premier Health Advantage',
      category: 'Medical',
      class: 'HMO',
      templateAvailability: 'Yes',
      status: 'Configure',
      planId: '11CDZ',
      blid: 'BL001',
      lastUpdatedBy: 'BENTEST120',
      lastUpdatedOn: '12/15/2024',
      effectiveDate: '01/01/2025',
      documentName: 'Premier_Health_Doc',
      state: 'California',
      network: [
        { tier: 'Tier 1', network: 'Blue Shield INN' },
        { tier: 'Tier 2', network: 'Blue Shield OON' },
      ],
      planInternalId: 'PHA-2025-CA',
      description: 'Comprehensive HMO plan',
      configurationSource: 'Manual',
    },
    {
      id: '2',
      name: 'Dental Plus',
      category: 'Dental',
      class: 'PPO',
      templateAvailability: 'No',
      status: 'Production',
      planId: '',
      blid: '',
      lastUpdatedBy: 'BENTEST121',
      lastUpdatedOn: '12/16/2024',
      effectiveDate: '01/01/2025',
      documentName: 'Dental_Plus_Doc',
      state: 'Texas',
      network: [{ tier: 'Tier 1', network: 'Delta Dental' }],
      planInternalId: 'DP-2025-TX',
      description: 'Dental PPO plan',
      configurationSource: 'Template',
    },
    {
      id: '3',
      name: 'Vision Care',
      category: 'Vision',
      class: 'Standard',
      templateAvailability: 'Yes',
      status: 'Draft',
      planId: 'VC123',
      blid: 'BL003',
      lastUpdatedBy: 'BENTEST122',
      lastUpdatedOn: '12/17/2024',
      effectiveDate: '01/01/2025',
      documentName: 'Vision_Care_Doc',
      state: 'New York',
      network: [{ tier: 'Tier 1', network: 'VSP' }],
      planInternalId: 'VC-2025-NY',
      description: 'Vision care plan',
      configurationSource: 'Manual',
    },
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductTableComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ProductTableComponent);
    component = fixture.componentInstance;
  });

  describe('Component Initialization', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should be a standalone component', () => {
      const metadata = (ProductTableComponent as any).ɵcmp;
      expect(metadata.standalone).toBe(true);
    });

    it('should have required products input', () => {
      expect(component.products).toBeDefined();
    });

    it('should have productClick output', () => {
      expect(component.productClick).toBeDefined();
    });
  });

  describe('Table Rendering', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should render table container with correct classes', () => {
      const container = fixture.debugElement.query(By.css('.overflow-x-auto'));
      expect(container).toBeTruthy();
      expect(container.nativeElement.classList.contains('bg-white')).toBe(true);
      expect(container.nativeElement.classList.contains('rounded-lg')).toBe(true);
      expect(container.nativeElement.classList.contains('shadow')).toBe(true);
    });

    it('should render table with correct classes', () => {
      const table = fixture.debugElement.query(By.css('table'));
      expect(table).toBeTruthy();
      expect(table.nativeElement.classList.contains('min-w-[900px]')).toBe(true);
      expect(table.nativeElement.classList.contains('divide-y')).toBe(true);
      expect(table.nativeElement.classList.contains('divide-gray-200')).toBe(true);
      expect(table.nativeElement.classList.contains('min-w-full')).toBe(false);
    });

    it('should render header row with gray background', () => {
      const thead = fixture.debugElement.query(By.css('thead'));
      expect(thead).toBeTruthy();
      expect(thead.nativeElement.classList.contains('bg-gray-50')).toBe(true);
    });

    it('should render all 9 column headers', () => {
      const headers = fixture.debugElement.queryAll(By.css('thead th'));
      expect(headers.length).toBe(9);
      
      const expectedHeaders = [
        'Name',
        'Category',
        'Class',
        'Template',
        'Status',
        'Plan ID',
        'BLID',
        'Last Update By',
        'Last Update On',
      ];

      headers.forEach((header, index) => {
        expect(header.nativeElement.textContent.trim()).toBe(expectedHeaders[index]);
      });
    });

    it('should render correct number of product rows', () => {
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      expect(rows.length).toBe(mockProducts.length);
    });

    it('should render all cells for each product', () => {
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      rows.forEach(row => {
        const cells = row.queryAll(By.css('td'));
        expect(cells.length).toBe(9);
      });
    });
  });

  describe('Product Data Display', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should display product name as clickable button', () => {
      const nameButtons = fixture.debugElement.queryAll(By.css('tbody tr td:first-child button'));
      expect(nameButtons.length).toBe(mockProducts.length);
      
      nameButtons.forEach((button, index) => {
        expect(button.nativeElement.textContent.trim()).toBe(mockProducts[index].name);
        expect(button.nativeElement.classList.contains('text-blue-600')).toBe(true);
        expect(button.nativeElement.classList.contains('hover:underline')).toBe(true);
      });
    });

    it('should display category correctly', () => {
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      rows.forEach((row, index) => {
        const categoryCell = row.queryAll(By.css('td'))[1];
        expect(categoryCell.nativeElement.textContent.trim()).toBe(mockProducts[index].category);
      });
    });

    it('should display class with max-width style', () => {
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      rows.forEach((row, index) => {
        const classCell = row.queryAll(By.css('td'))[2];
        expect(classCell.nativeElement.textContent.trim()).toBe(mockProducts[index].class);
        expect(classCell.nativeElement.style.maxWidth).toBe('250px');
      });
    });

    it('should display template availability', () => {
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      rows.forEach((row, index) => {
        const templateCell = row.queryAll(By.css('td'))[3];
        expect(templateCell.nativeElement.textContent.trim()).toBe(mockProducts[index].templateAvailability);
      });
    });

    it('should display status as colored chip', () => {
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      rows.forEach((row, index) => {
        const statusCell = row.queryAll(By.css('td'))[4];
        const chip = statusCell.query(By.css('span'));
        expect(chip).toBeTruthy();
        expect(chip.nativeElement.textContent.trim()).toBe(mockProducts[index].status);
      });
    });

    it('should display planId or "-" if empty', () => {
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      rows.forEach((row, index) => {
        const planIdCell = row.queryAll(By.css('td'))[5];
        const expectedValue = mockProducts[index].planId || '-';
        expect(planIdCell.nativeElement.textContent.trim()).toBe(expectedValue);
      });
    });

    it('should display blid or "-" if empty', () => {
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      rows.forEach((row, index) => {
        const blidCell = row.queryAll(By.css('td'))[6];
        const expectedValue = mockProducts[index].blid || '-';
        expect(blidCell.nativeElement.textContent.trim()).toBe(expectedValue);
      });
    });

    it('should display lastUpdatedBy', () => {
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      rows.forEach((row, index) => {
        const lastUpdatedByCell = row.queryAll(By.css('td'))[7];
        expect(lastUpdatedByCell.nativeElement.textContent.trim()).toBe(mockProducts[index].lastUpdatedBy);
      });
    });

    it('should display lastUpdatedOn', () => {
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      rows.forEach((row, index) => {
        const lastUpdatedOnCell = row.queryAll(By.css('td'))[8];
        expect(lastUpdatedOnCell.nativeElement.textContent.trim()).toBe(mockProducts[index].lastUpdatedOn);
      });
    });
  });

  describe('Status Color Mapping', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should apply blue color for Configure status', () => {
      const configureProduct = mockProducts.find(p => p.status === 'Configure');
      expect(configureProduct).toBeDefined();
      
      const color = component.getStatusColor('Configure');
      expect(color).toContain('bg-blue-600');
      expect(color).toContain('text-white');
    });

    it('should apply green color for Production status', () => {
      const productionProduct = mockProducts.find(p => p.status === 'Production');
      expect(productionProduct).toBeDefined();
      
      const color = component.getStatusColor('Production');
      expect(color).toContain('bg-green-600');
      expect(color).toContain('text-white');
    });

    it('should apply gray color for Draft status', () => {
      const draftProduct = mockProducts.find(p => p.status === 'Draft');
      expect(draftProduct).toBeDefined();
      
      const color = component.getStatusColor('Draft');
      expect(color).toContain('bg-gray-400');
      expect(color).toContain('text-white');
    });

    it('should render status chips with correct color classes', () => {
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      
      // Check Configure status (first product)
      const configureChip = rows[0].queryAll(By.css('td'))[4].query(By.css('span'));
      expect(configureChip.nativeElement.classList.contains('bg-blue-600')).toBe(true);
      
      // Check Production status (second product)
      const productionChip = rows[1].queryAll(By.css('td'))[4].query(By.css('span'));
      expect(productionChip.nativeElement.classList.contains('bg-green-600')).toBe(true);
      
      // Check Draft status (third product)
      const draftChip = rows[2].queryAll(By.css('td'))[4].query(By.css('span'));
      expect(draftChip.nativeElement.classList.contains('bg-gray-400')).toBe(true);
    });
  });

  describe('User Interactions', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should emit productClick event when product name is clicked', () => {
      const emitSpy = jest.spyOn(component.productClick, 'emit');
      const nameButton = fixture.debugElement.query(By.css('tbody tr td:first-child button'));
      
      nameButton.nativeElement.click();
      
      expect(emitSpy).toHaveBeenCalledWith(mockProducts[0]);
    });

    it('should emit correct product when different rows are clicked', () => {
      const emitSpy = jest.spyOn(component.productClick, 'emit');
      const nameButtons = fixture.debugElement.queryAll(By.css('tbody tr td:first-child button'));
      
      nameButtons[1].nativeElement.click();
      expect(emitSpy).toHaveBeenCalledWith(mockProducts[1]);
      
      nameButtons[2].nativeElement.click();
      expect(emitSpy).toHaveBeenCalledWith(mockProducts[2]);
    });

    it('should have hover effect on table rows', () => {
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      rows.forEach(row => {
        expect(row.nativeElement.classList.contains('hover:bg-gray-50')).toBe(true);
      });
    });
  });

  describe('Empty State Handling', () => {
    it('should render empty table when products array is empty', () => {
      fixture.componentRef.setInput('products', []);
      fixture.detectChanges();
      
      const rows = fixture.debugElement.queryAll(By.css('tbody tr'));
      expect(rows.length).toBe(0);
    });

    it('should still render headers when products array is empty', () => {
      fixture.componentRef.setInput('products', []);
      fixture.detectChanges();
      
      const headers = fixture.debugElement.queryAll(By.css('thead th'));
      expect(headers.length).toBe(9);
    });
  });

  describe('formatCellValue()', () => {
    it('should return value when provided', () => {
      expect(component.formatCellValue('test')).toBe('test');
      expect(component.formatCellValue('123')).toBe('123');
    });

    it('should return "-" for null', () => {
      expect(component.formatCellValue(null)).toBe('-');
    });

    it('should return "-" for undefined', () => {
      expect(component.formatCellValue(undefined)).toBe('-');
    });

    it('should return "-" for empty string', () => {
      expect(component.formatCellValue('')).toBe('-');
    });
  });

  describe('Responsive Design', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should have horizontal scroll container', () => {
      const container = fixture.debugElement.query(By.css('.overflow-x-auto'));
      expect(container).toBeTruthy();
    });

    it('should have min-width on table for horizontal scrolling', () => {
      const table = fixture.debugElement.query(By.css('table'));
      expect(table.nativeElement.classList.contains('min-w-[900px]')).toBe(true);
      expect(table.nativeElement.classList.contains('min-w-full')).toBe(false);
    });
  });

  describe('Accessibility', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should have scope attribute on header cells', () => {
      const headers = fixture.debugElement.queryAll(By.css('thead th'));
      headers.forEach(header => {
        expect(header.nativeElement.getAttribute('scope')).toBe('col');
      });
    });

    it('should have button type on clickable product names', () => {
      const nameButtons = fixture.debugElement.queryAll(By.css('tbody tr td:first-child button'));
      nameButtons.forEach(button => {
        expect(button.nativeElement.getAttribute('type')).toBe('button');
      });
    });

    it('should have focus styles on product name buttons', () => {
      const nameButtons = fixture.debugElement.queryAll(By.css('tbody tr td:first-child button'));
      nameButtons.forEach(button => {
        expect(button.nativeElement.classList.contains('focus:outline-none')).toBe(true);
        expect(button.nativeElement.classList.contains('focus:underline')).toBe(true);
        expect(button.nativeElement.classList.contains('min-h-11')).toBe(true);
      });
    });
  });

  describe('Styling', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('products', mockProducts);
      fixture.detectChanges();
    });

    it('should have proper padding on table cells', () => {
      const cells = fixture.debugElement.queryAll(By.css('tbody td'));
      cells.forEach(cell => {
        expect(cell.nativeElement.classList.contains('px-6')).toBe(true);
        expect(cell.nativeElement.classList.contains('py-4')).toBe(true);
      });
    });

    it('should have proper padding on header cells', () => {
      const headers = fixture.debugElement.queryAll(By.css('thead th'));
      headers.forEach(header => {
        expect(header.nativeElement.classList.contains('px-6')).toBe(true);
        expect(header.nativeElement.classList.contains('py-3')).toBe(true);
      });
    });

    it('should have divider between rows', () => {
      const tbody = fixture.debugElement.query(By.css('tbody'));
      expect(tbody.nativeElement.classList.contains('divide-y')).toBe(true);
      expect(tbody.nativeElement.classList.contains('divide-gray-200')).toBe(true);
    });

    it('should have rounded corners on container', () => {
      const container = fixture.debugElement.query(By.css('.overflow-x-auto'));
      expect(container.nativeElement.classList.contains('rounded-lg')).toBe(true);
    });

    it('should have shadow on container', () => {
      const container = fixture.debugElement.query(By.css('.overflow-x-auto'));
      expect(container.nativeElement.classList.contains('shadow')).toBe(true);
    });
  });
});

// Made with Bob