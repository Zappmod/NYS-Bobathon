import { User, DemoAccount } from '../models';

/**
 * Mock Users Data
 * 
 * This constant contains mock user data for development and testing purposes.
 * These users match the prototype data from `prototype/src/app/context/AuthContext.tsx`.
 * 
 * **IMPORTANT**: This is mock data only. In production, user data will come from the backend API.
 * 
 * @constant {ReadonlyArray<User>} MOCK_USERS
 * 
 * @example
 * // Use in AuthService for mock authentication
 * const user = MOCK_USERS.find(u => u.email === email);
 */
export const MOCK_USERS: ReadonlyArray<User> = [
  {
    id: '550e8400-e29b-41d4-a716-446655440001',
    name: 'Jack',
    email: 'jack@aibenefits.com',
    role: 'Benefit Developer',
    canEdit: true,
  },
  {
    id: '550e8400-e29b-41d4-a716-446655440002',
    name: 'Smith',
    email: 'smith@aibenefits.com',
    role: 'Product Reviewer',
    canEdit: false,
  },
] as const;

/**
 * Demo Accounts Information
 * 
 * This constant contains demo account information for display on the login page.
 * Shows users which test accounts are available and their capabilities.
 * 
 * @constant {ReadonlyArray<DemoAccount>} DEMO_ACCOUNTS
 * 
 * @example
 * // Display in login component
 * <div>
 *   {DEMO_ACCOUNTS.map(account => (
 *     <div key={account.email}>
 *       {account.email} ({account.role} - {account.description})
 *     </div>
 *   ))}
 * </div>
 */
export const DEMO_ACCOUNTS: ReadonlyArray<DemoAccount> = [
  {
    email: 'jack@aibenefits.com',
    role: 'Benefit Developer',
    description: 'Full Access',
  },
  {
    email: 'smith@aibenefits.com',
    role: 'Product Reviewer',
    description: 'View Only',
  },
] as const;

/**
 * Generate a mock JWT token.
 * 
 * This function generates a realistic-looking JWT token for development and testing.
 * The token is NOT cryptographically secure and should NEVER be used in production.
 * 
 * **Structure**: header.payload.signature (Base64 encoded)
 * 
 * @param {User} user - The user for whom to generate the token
 * @param {number} expiresIn - Token expiration time in seconds (default: 3600 = 1 hour)
 * @returns {string} A mock JWT token string
 * 
 * @example
 * const token = generateMockToken(user, 3600);
 * // Returns: "<base64-header>.<base64-payload>.mock-signature"
 */
export function generateMockToken(user: User, expiresIn: number = 3600): string {
  const now = Math.floor(Date.now() / 1000);
  
  // Mock JWT header
  const header = {
    alg: 'HS256',
    typ: 'JWT',
  };
  
  // Mock JWT payload with user claims
  const payload = {
    sub: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    canEdit: user.canEdit,
    iat: now,
    exp: now + expiresIn,
    iss: 'aibenefits-api',
    aud: 'aibenefits-frontend',
  };
  
  // Base64 encode (mock implementation - not cryptographically secure)
  const encodedHeader = btoa(JSON.stringify(header));
  const encodedPayload = btoa(JSON.stringify(payload));
  const mockSignature = 'mock-signature-' + user.id.substring(0, 8);
  
  return `${encodedHeader}.${encodedPayload}.${mockSignature}`;
}

/**
 * Generate a mock refresh token.
 * 
 * This function generates a realistic-looking refresh token for development and testing.
 * The token is NOT cryptographically secure and should NEVER be used in production.
 * 
 * @param {User} user - The user for whom to generate the refresh token
 * @param {number} expiresIn - Token expiration time in seconds (default: 604800 = 7 days)
 * @returns {string} A mock refresh token string
 * 
 * @example
 * const refreshToken = generateMockRefreshToken(user);
 * // Returns: "<base64-header>.<base64-payload>.mock-refresh-signature"
 */
export function generateMockRefreshToken(user: User, expiresIn: number = 604800): string {
  const now = Math.floor(Date.now() / 1000);
  
  // Mock JWT header
  const header = {
    alg: 'HS256',
    typ: 'JWT',
  };
  
  // Mock refresh token payload
  const payload = {
    sub: user.id,
    jti: `refresh-${user.id.substring(0, 8)}`,
    iat: now,
    exp: now + expiresIn,
    iss: 'aibenefits-api',
    type: 'refresh',
  };
  
  // Base64 encode (mock implementation - not cryptographically secure)
  const encodedHeader = btoa(JSON.stringify(header));
  const encodedPayload = btoa(JSON.stringify(payload));
  const mockSignature = 'mock-refresh-signature-' + user.id.substring(0, 8);
  
  return `${encodedHeader}.${encodedPayload}.${mockSignature}`;
}

/**
 * Validate mock credentials.
 *
 * This function validates user credentials against the mock user database.
 * In production, this validation will be performed by the backend API.
 *
 * @param {string} email - User's email address
 * @param {string} password - User's password (must match the mock password for mock users)
 * @returns {User | null} The authenticated user or null if credentials are invalid
 *
 * @example
 * const user = validateMockCredentials('jack@aibenefits.com', '<mock-password>');
 * if (user) {
 *   console.log('Login successful:', user.name);
 * } else {
 *   console.log('Invalid credentials');
 * }
 */
export function validateMockCredentials(email: string, password: string): User | null {
  // Mock password for all users — value intentionally kept out of source; set via environment or test config
  const MOCK_PASSWORD = process.env['MOCK_PASSWORD'] ?? 'mock-password';
  
  // Validate password
  if (password !== MOCK_PASSWORD) {
    return null;
  }
  
  // Find user by email
  const user = MOCK_USERS.find(u => u.email.toLowerCase() === email.toLowerCase());
  
  return user || null;
}

/**
 * Get user permissions based on role.
 * 
 * This function returns the list of permissions for a given user based on their role.
 * In production, permissions will be included in the JWT token from the backend.
 * 
 * @param {User} user - The user for whom to get permissions
 * @returns {ReadonlyArray<string>} Array of permission strings
 * 
 * @example
 * const permissions = getMockUserPermissions(user);
 * // For Benefit Developer: ['PRODUCT_CREATE', 'PRODUCT_READ', 'PRODUCT_UPDATE', 'PRODUCT_DELETE', ...]
 * // For Product Reviewer: ['PRODUCT_READ', 'SERVICE_READ', 'CONFIG_READ']
 */
export function getMockUserPermissions(user: User): ReadonlyArray<string> {
  if (user.role === 'Benefit Developer') {
    // Full access - all CRUD operations
    return [
      'PRODUCT_CREATE',
      'PRODUCT_READ',
      'PRODUCT_UPDATE',
      'PRODUCT_DELETE',
      'SERVICE_CREATE',
      'SERVICE_READ',
      'SERVICE_UPDATE',
      'SERVICE_DELETE',
      'CONFIG_CREATE',
      'CONFIG_READ',
      'CONFIG_UPDATE',
      'CONFIG_DELETE',
    ] as const;
  } else {
    // Product Reviewer - read-only access
    return [
      'PRODUCT_READ',
      'SERVICE_READ',
      'CONFIG_READ',
    ] as const;
  }
}

// Made with Bob
