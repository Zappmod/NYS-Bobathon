import { TestBed } from '@angular/core/testing';
import { HttpInterceptorFn, HttpRequest, HttpHandlerFn, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';
import { authInterceptor } from './auth.interceptor';
import { AuthService } from '../services/auth.service';

describe('authInterceptor', () => {
  let mockAuthService: jasmine.SpyObj<AuthService>;
  let mockRouter: jasmine.SpyObj<Router>;
  let mockNext: jasmine.Spy<HttpHandlerFn>;

  beforeEach(() => {
    // Create mock AuthService
    mockAuthService = jasmine.createSpyObj('AuthService', [
      'token',
      'refreshToken',
      'refreshAccessToken',
      'logout',
    ]);

    // Create mock Router
    mockRouter = jasmine.createSpyObj('Router', ['navigate'], {
      url: '/products',
    });

    // Create mock next handler
    mockNext = jasmine.createSpy('next').and.returnValue(of({} as HttpEvent<unknown>));

    TestBed.configureTestingModule({
      providers: [
        { provide: AuthService, useValue: mockAuthService },
        { provide: Router, useValue: mockRouter },
      ],
    });
  });

  it('should be created', () => {
    expect(authInterceptor).toBeTruthy();
  });

  describe('Public Endpoints', () => {
    it('should not add Authorization header for login endpoint', () => {
      const req = new HttpRequest('POST', '/api/v1/auth/login', {});
      mockAuthService.token.and.returnValue('mock-token');

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext);
      });

      expect(mockNext).toHaveBeenCalledWith(req);
      expect(req.headers.has('Authorization')).toBe(false);
    });

    it('should not add Authorization header for refresh endpoint', () => {
      const req = new HttpRequest('POST', '/api/v1/auth/refresh', {});
      mockAuthService.token.and.returnValue('mock-token');

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext);
      });

      expect(mockNext).toHaveBeenCalledWith(req);
      expect(req.headers.has('Authorization')).toBe(false);
    });

    it('should not add Authorization header for forgot-password endpoint', () => {
      const req = new HttpRequest('POST', '/api/v1/auth/forgot-password', {});
      mockAuthService.token.and.returnValue('mock-token');

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext);
      });

      expect(mockNext).toHaveBeenCalledWith(req);
    });

    it('should not add Authorization header for reset-password endpoint', () => {
      const req = new HttpRequest('POST', '/api/v1/auth/reset-password', {});
      mockAuthService.token.and.returnValue('mock-token');

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext);
      });

      expect(mockNext).toHaveBeenCalledWith(req);
    });
  });

  describe('Protected Endpoints', () => {
    it('should add Authorization header with Bearer token', () => {
      const req = new HttpRequest('GET', '/api/v1/products', {});
      const token = 'mock-jwt-token';
      mockAuthService.token.and.returnValue(token);

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext);
      });

      const calledRequest = mockNext.calls.mostRecent().args[0] as HttpRequest<unknown>;
      expect(calledRequest.headers.get('Authorization')).toBe(`Bearer ${token}`);
    });

    it('should not add Authorization header if no token exists', () => {
      const req = new HttpRequest('GET', '/api/v1/products', {});
      mockAuthService.token.and.returnValue(null);

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext);
      });

      const calledRequest = mockNext.calls.mostRecent().args[0] as HttpRequest<unknown>;
      expect(calledRequest.headers.has('Authorization')).toBe(false);
    });

    it('should pass through request without modification if no token', () => {
      const req = new HttpRequest('GET', '/api/v1/products', {});
      mockAuthService.token.and.returnValue(null);

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext);
      });

      expect(mockNext).toHaveBeenCalledWith(req);
    });
  });

  describe('401 Unauthorized Handling', () => {
    it('should attempt token refresh on 401 error', (done) => {
      const req = new HttpRequest('GET', '/api/v1/products', {});
      const error = new HttpErrorResponse({ status: 401 });
      
      mockAuthService.token.and.returnValue('expired-token');
      mockAuthService.refreshToken.and.returnValue('refresh-token');
      mockAuthService.refreshAccessToken.and.returnValue(
        of({ token: 'new-token', expiresIn: 3600 })
      );
      mockNext.and.returnValue(throwError(() => error));

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext).subscribe({
          error: () => {
            expect(mockAuthService.refreshAccessToken).toHaveBeenCalled();
            done();
          },
        });
      });
    });

    it('should retry request with new token after successful refresh', (done) => {
      const req = new HttpRequest('GET', '/api/v1/products', {});
      const error = new HttpErrorResponse({ status: 401 });
      const newToken = 'new-token';
      
      mockAuthService.token.and.returnValue('expired-token');
      mockAuthService.refreshToken.and.returnValue('refresh-token');
      mockAuthService.refreshAccessToken.and.returnValue(
        of({ token: newToken, expiresIn: 3600 })
      );
      
      let callCount = 0;
      mockNext.and.callFake((request: HttpRequest<unknown>) => {
        callCount++;
        if (callCount === 1) {
          return throwError(() => error);
        }
        // Second call should have new token
        expect(request.headers.get('Authorization')).toBe(`Bearer ${newToken}`);
        return of({} as HttpEvent<unknown>);
      });

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext).subscribe({
          next: () => {
            expect(callCount).toBe(2);
            done();
          },
        });
      });
    });

    it('should logout and redirect to login if no refresh token', (done) => {
      const req = new HttpRequest('GET', '/api/v1/products', {});
      const error = new HttpErrorResponse({ status: 401 });
      
      mockAuthService.token.and.returnValue('expired-token');
      mockAuthService.refreshToken.and.returnValue(null);
      mockNext.and.returnValue(throwError(() => error));

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext).subscribe({
          error: () => {
            expect(mockAuthService.logout).toHaveBeenCalled();
            expect(mockRouter.navigate).toHaveBeenCalledWith(['/login'], {
              queryParams: { returnUrl: '/products' },
            });
            done();
          },
        });
      });
    });

    it('should logout and redirect to login if token refresh fails', (done) => {
      const req = new HttpRequest('GET', '/api/v1/products', {});
      const error = new HttpErrorResponse({ status: 401 });
      const refreshError = new Error('Refresh failed');
      
      mockAuthService.token.and.returnValue('expired-token');
      mockAuthService.refreshToken.and.returnValue('refresh-token');
      mockAuthService.refreshAccessToken.and.returnValue(
        throwError(() => refreshError)
      );
      mockNext.and.returnValue(throwError(() => error));

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext).subscribe({
          error: () => {
            expect(mockAuthService.logout).toHaveBeenCalled();
            expect(mockRouter.navigate).toHaveBeenCalledWith(['/login'], {
              queryParams: { returnUrl: '/products' },
            });
            done();
          },
        });
      });
    });

    it('should preserve return URL in query params', (done) => {
      const req = new HttpRequest('GET', '/api/v1/products', {});
      const error = new HttpErrorResponse({ status: 401 });
      
      mockAuthService.token.and.returnValue('expired-token');
      mockAuthService.refreshToken.and.returnValue(null);
      mockNext.and.returnValue(throwError(() => error));
      mockRouter.url = '/products/123';

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext).subscribe({
          error: () => {
            expect(mockRouter.navigate).toHaveBeenCalledWith(['/login'], {
              queryParams: { returnUrl: '/products/123' },
            });
            done();
          },
        });
      });
    });
  });

  describe('403 Forbidden Handling', () => {
    it('should pass through 403 error without logout', (done) => {
      const req = new HttpRequest('GET', '/api/v1/products', {});
      const error = new HttpErrorResponse({ status: 403, url: '/api/v1/products' });
      
      mockAuthService.token.and.returnValue('valid-token');
      mockNext.and.returnValue(throwError(() => error));

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext).subscribe({
          error: (err) => {
            expect(err.status).toBe(403);
            expect(mockAuthService.logout).not.toHaveBeenCalled();
            expect(mockRouter.navigate).not.toHaveBeenCalled();
            done();
          },
        });
      });
    });

    it('should log warning for 403 errors', (done) => {
      const req = new HttpRequest('GET', '/api/v1/products', {});
      const error = new HttpErrorResponse({ status: 403, url: '/api/v1/products' });
      
      spyOn(console, 'warn');
      mockAuthService.token.and.returnValue('valid-token');
      mockNext.and.returnValue(throwError(() => error));

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext).subscribe({
          error: () => {
            expect(console.warn).toHaveBeenCalledWith('Access forbidden:', '/api/v1/products');
            done();
          },
        });
      });
    });
  });

  describe('Other Error Handling', () => {
    it('should pass through 500 errors without special handling', (done) => {
      const req = new HttpRequest('GET', '/api/v1/products', {});
      const error = new HttpErrorResponse({ status: 500 });
      
      mockAuthService.token.and.returnValue('valid-token');
      mockNext.and.returnValue(throwError(() => error));

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext).subscribe({
          error: (err) => {
            expect(err.status).toBe(500);
            expect(mockAuthService.logout).not.toHaveBeenCalled();
            expect(mockRouter.navigate).not.toHaveBeenCalled();
            done();
          },
        });
      });
    });

    it('should pass through 404 errors without special handling', (done) => {
      const req = new HttpRequest('GET', '/api/v1/products/999', {});
      const error = new HttpErrorResponse({ status: 404 });
      
      mockAuthService.token.and.returnValue('valid-token');
      mockNext.and.returnValue(throwError(() => error));

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext).subscribe({
          error: (err) => {
            expect(err.status).toBe(404);
            expect(mockAuthService.logout).not.toHaveBeenCalled();
            done();
          },
        });
      });
    });

    it('should pass through 400 errors without special handling', (done) => {
      const req = new HttpRequest('POST', '/api/v1/products', {});
      const error = new HttpErrorResponse({ status: 400 });
      
      mockAuthService.token.and.returnValue('valid-token');
      mockNext.and.returnValue(throwError(() => error));

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext).subscribe({
          error: (err) => {
            expect(err.status).toBe(400);
            expect(mockAuthService.logout).not.toHaveBeenCalled();
            done();
          },
        });
      });
    });
  });

  describe('Request Cloning', () => {
    it('should not modify original request', () => {
      const req = new HttpRequest('GET', '/api/v1/products', {});
      const token = 'mock-token';
      mockAuthService.token.and.returnValue(token);

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext);
      });

      // Original request should not have Authorization header
      expect(req.headers.has('Authorization')).toBe(false);
      
      // Cloned request passed to next should have it
      const calledRequest = mockNext.calls.mostRecent().args[0] as HttpRequest<unknown>;
      expect(calledRequest.headers.get('Authorization')).toBe(`Bearer ${token}`);
    });

    it('should preserve other headers when adding Authorization', () => {
      const req = new HttpRequest('GET', '/api/v1/products', {}, {
        headers: {
          'Content-Type': 'application/json',
          'X-Custom-Header': 'custom-value',
        },
      });
      const token = 'mock-token';
      mockAuthService.token.and.returnValue(token);

      TestBed.runInInjectionContext(() => {
        authInterceptor(req, mockNext);
      });

      const calledRequest = mockNext.calls.mostRecent().args[0] as HttpRequest<unknown>;
      expect(calledRequest.headers.get('Content-Type')).toBe('application/json');
      expect(calledRequest.headers.get('X-Custom-Header')).toBe('custom-value');
      expect(calledRequest.headers.get('Authorization')).toBe(`Bearer ${token}`);
    });
  });
});

// Made with Bob
