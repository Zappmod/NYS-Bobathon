import { TestBed } from '@angular/core/testing';
import { AuthService } from './auth.service';
import { MOCK_USERS } from './auth.mock';

describe('AuthService', () => {
  let service: AuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthService],
    });
    service = TestBed.inject(AuthService);

    // Clear storage before each test
    localStorage.clear();
    sessionStorage.clear();
  });

  afterEach(() => {
    // Clean up after each test
    localStorage.clear();
    sessionStorage.clear();
  });

  describe('Service Initialization', () => {
    it('should be created', () => {
      expect(service).toBeTruthy();
    });

    it('should initialize with null user', () => {
      expect(service.user()).toBeNull();
    });

    it('should initialize with null token', () => {
      expect(service.token()).toBeNull();
    });

    it('should initialize with isAuthenticated as false', () => {
      expect(service.isAuthenticated()).toBe(false);
    });

    it('should initialize with isLoading as false', () => {
      expect(service.isLoading()).toBe(false);
    });

    it('should initialize with null error', () => {
      expect(service.error()).toBeNull();
    });
  });

  describe('login()', () => {
    it('should successfully login with valid credentials (Jack)', (done) => {
      const credentials = {
        email: 'jack@aibenefits.com',
        password: 'password',
        rememberMe: false,
      };

      service.login(credentials).subscribe({
        next: (response) => {
          expect(response).toBeDefined();
          expect(response.user).toBeDefined();
          expect(response.user.email).toBe('jack@aibenefits.com');
          expect(response.user.name).toBe('Jack');
          expect(response.user.role).toBe('Benefit Developer');
          expect(response.user.canEdit).toBe(true);
          expect(response.token).toBeDefined();
          expect(response.refreshToken).toBeDefined();
          expect(response.expiresIn).toBe(3600);
          done();
        },
        error: (error) => {
          fail('Login should succeed with valid credentials');
          done();
        },
      });
    });

    it('should successfully login with valid credentials (Smith)', (done) => {
      const credentials = {
        email: 'smith@aibenefits.com',
        password: 'password',
        rememberMe: false,
      };

      service.login(credentials).subscribe({
        next: (response) => {
          expect(response.user.email).toBe('smith@aibenefits.com');
          expect(response.user.name).toBe('Smith');
          expect(response.user.role).toBe('Product Reviewer');
          expect(response.user.canEdit).toBe(false);
          done();
        },
        error: () => {
          fail('Login should succeed with valid credentials');
          done();
        },
      });
    });

    it('should update user signal after successful login', (done) => {
      const credentials = {
        email: 'jack@aibenefits.com',
        password: 'password',
      };

      service.login(credentials).subscribe({
        next: () => {
          expect(service.user()).not.toBeNull();
          expect(service.user()?.email).toBe('jack@aibenefits.com');
          done();
        },
      });
    });

    it('should update token signal after successful login', (done) => {
      const credentials = {
        email: 'jack@aibenefits.com',
        password: 'password',
      };

      service.login(credentials).subscribe({
        next: () => {
          expect(service.token()).not.toBeNull();
          expect(service.token()).toContain('.');
          done();
        },
      });
    });

    it('should set isAuthenticated to true after successful login', (done) => {
      const credentials = {
        email: 'jack@aibenefits.com',
        password: 'password',
      };

      service.login(credentials).subscribe({
        next: () => {
          expect(service.isAuthenticated()).toBe(true);
          done();
        },
      });
    });

    it('should fail login with invalid email', (done) => {
      const credentials = {
        email: 'invalid@example.com',
        password: 'password',
      };

      service.login(credentials).subscribe({
        next: () => {
          fail('Login should fail with invalid email');
          done();
        },
        error: (error) => {
          expect(error).toBeDefined();
          expect(error.message).toContain('Invalid email or password');
          expect(service.isAuthenticated()).toBe(false);
          done();
        },
      });
    });

    it('should fail login with empty password', (done) => {
      const credentials = {
        email: 'jack@aibenefits.com',
        password: '',
      };

      service.login(credentials).subscribe({
        next: () => {
          fail('Login should fail with empty password');
          done();
        },
        error: (error) => {
          expect(error).toBeDefined();
          expect(service.isAuthenticated()).toBe(false);
          done();
        },
      });
    });

    it('should set error signal on failed login', (done) => {
      const credentials = {
        email: 'invalid@example.com',
        password: 'password',
      };

      service.login(credentials).subscribe({
        error: () => {
          expect(service.error()).not.toBeNull();
          expect(service.error()).toContain('Invalid email or password');
          done();
        },
      });
    });

    it('should store session in sessionStorage when rememberMe is false', (done) => {
      const credentials = {
        email: 'jack@aibenefits.com',
        password: 'password',
        rememberMe: false,
      };

      service.login(credentials).subscribe({
        next: () => {
          expect(sessionStorage.getItem('auth_user')).not.toBeNull();
          expect(sessionStorage.getItem('auth_token')).not.toBeNull();
          expect(localStorage.getItem('auth_user')).toBeNull();
          done();
        },
      });
    });

    it('should store session in localStorage when rememberMe is true', (done) => {
      const credentials = {
        email: 'jack@aibenefits.com',
        password: 'password',
        rememberMe: true,
      };

      service.login(credentials).subscribe({
        next: () => {
          expect(localStorage.getItem('auth_user')).not.toBeNull();
          expect(localStorage.getItem('auth_token')).not.toBeNull();
          expect(sessionStorage.getItem('auth_user')).toBeNull();
          done();
        },
      });
    });

    it('should be case-insensitive for email', (done) => {
      const credentials = {
        email: 'JACK@AIBENEFITS.COM',
        password: 'password',
      };

      service.login(credentials).subscribe({
        next: (response) => {
          expect(response.user.email).toBe('jack@aibenefits.com');
          done();
        },
        error: () => {
          fail('Login should be case-insensitive');
          done();
        },
      });
    });
  });

  describe('logout()', () => {
    beforeEach((done) => {
      // Login first
      service
        .login({
          email: 'jack@aibenefits.com',
          password: 'password',
          rememberMe: false,
        })
        .subscribe({
          next: () => done(),
        });
    });

    it('should clear user signal', () => {
      expect(service.user()).not.toBeNull();
      service.logout();
      expect(service.user()).toBeNull();
    });

    it('should clear token signal', () => {
      expect(service.token()).not.toBeNull();
      service.logout();
      expect(service.token()).toBeNull();
    });

    it('should set isAuthenticated to false', () => {
      expect(service.isAuthenticated()).toBe(true);
      service.logout();
      expect(service.isAuthenticated()).toBe(false);
    });

    it('should clear sessionStorage', () => {
      expect(sessionStorage.getItem('auth_user')).not.toBeNull();
      service.logout();
      expect(sessionStorage.getItem('auth_user')).toBeNull();
      expect(sessionStorage.getItem('auth_token')).toBeNull();
      expect(sessionStorage.getItem('auth_refresh_token')).toBeNull();
    });

    it('should clear error signal', () => {
      service.logout();
      expect(service.error()).toBeNull();
    });
  });

  describe('refreshAccessToken()', () => {
    beforeEach((done) => {
      // Login first
      service
        .login({
          email: 'jack@aibenefits.com',
          password: 'password',
        })
        .subscribe({
          next: () => done(),
        });
    });

    it('should generate new access token', (done) => {
      const oldToken = service.token();

      service.refreshAccessToken().subscribe({
        next: (response) => {
          expect(response.token).toBeDefined();
          expect(response.token).not.toBe(oldToken);
          expect(response.expiresIn).toBe(3600);
          done();
        },
      });
    });

    it('should update token signal', (done) => {
      const oldToken = service.token();

      service.refreshAccessToken().subscribe({
        next: () => {
          expect(service.token()).not.toBe(oldToken);
          done();
        },
      });
    });

    it('should fail if not authenticated', (done) => {
      service.logout();

      service.refreshAccessToken().subscribe({
        next: () => {
          fail('Refresh should fail when not authenticated');
          done();
        },
        error: (error) => {
          expect(error.message).toContain('No refresh token available');
          done();
        },
      });
    });

    it('should update storage with new token', (done) => {
      service.refreshAccessToken().subscribe({
        next: () => {
          const storedToken = sessionStorage.getItem('auth_token');
          expect(storedToken).toBe(service.token());
          done();
        },
      });
    });
  });

  describe('getUserPermissions()', () => {
    it('should return empty array when not authenticated', () => {
      const permissions = service.getUserPermissions();
      expect(permissions).toEqual([]);
    });

    it('should return full permissions for Benefit Developer', (done) => {
      service
        .login({
          email: 'jack@aibenefits.com',
          password: 'password',
        })
        .subscribe({
          next: () => {
            const permissions = service.getUserPermissions();
            expect(permissions.length).toBe(12);
            expect(permissions).toContain('PRODUCT_CREATE');
            expect(permissions).toContain('PRODUCT_READ');
            expect(permissions).toContain('PRODUCT_UPDATE');
            expect(permissions).toContain('PRODUCT_DELETE');
            done();
          },
        });
    });

    it('should return read-only permissions for Product Reviewer', (done) => {
      service
        .login({
          email: 'smith@aibenefits.com',
          password: 'password',
        })
        .subscribe({
          next: () => {
            const permissions = service.getUserPermissions();
            expect(permissions.length).toBe(3);
            expect(permissions).toContain('PRODUCT_READ');
            expect(permissions).toContain('SERVICE_READ');
            expect(permissions).toContain('CONFIG_READ');
            expect(permissions).not.toContain('PRODUCT_CREATE');
            done();
          },
        });
    });
  });

  describe('hasPermission()', () => {
    it('should return false when not authenticated', () => {
      expect(service.hasPermission('PRODUCT_READ')).toBe(false);
    });

    it('should return true for valid permission (Benefit Developer)', (done) => {
      service
        .login({
          email: 'jack@aibenefits.com',
          password: 'password',
        })
        .subscribe({
          next: () => {
            expect(service.hasPermission('PRODUCT_CREATE')).toBe(true);
            expect(service.hasPermission('PRODUCT_UPDATE')).toBe(true);
            done();
          },
        });
    });

    it('should return false for invalid permission (Product Reviewer)', (done) => {
      service
        .login({
          email: 'smith@aibenefits.com',
          password: 'password',
        })
        .subscribe({
          next: () => {
            expect(service.hasPermission('PRODUCT_CREATE')).toBe(false);
            expect(service.hasPermission('PRODUCT_UPDATE')).toBe(false);
            expect(service.hasPermission('PRODUCT_READ')).toBe(true);
            done();
          },
        });
    });
  });

  describe('canEdit()', () => {
    it('should return false when not authenticated', () => {
      expect(service.canEdit()).toBe(false);
    });

    it('should return true for Benefit Developer', (done) => {
      service
        .login({
          email: 'jack@aibenefits.com',
          password: 'password',
        })
        .subscribe({
          next: () => {
            expect(service.canEdit()).toBe(true);
            done();
          },
        });
    });

    it('should return false for Product Reviewer', (done) => {
      service
        .login({
          email: 'smith@aibenefits.com',
          password: 'password',
        })
        .subscribe({
          next: () => {
            expect(service.canEdit()).toBe(false);
            done();
          },
        });
    });
  });

  describe('Session Restoration', () => {
    it('should restore session from sessionStorage on initialization', () => {
      // Manually set session data
      const mockUser = MOCK_USERS[0];
      sessionStorage.setItem('auth_user', JSON.stringify(mockUser));
      sessionStorage.setItem('auth_token', 'mock-token');
      sessionStorage.setItem('auth_refresh_token', 'mock-refresh-token');

      // Create new service instance
      const newService = new AuthService();

      expect(newService.user()).not.toBeNull();
      expect(newService.user()?.email).toBe('jack@aibenefits.com');
      expect(newService.token()).toBe('mock-token');
      expect(newService.isAuthenticated()).toBe(true);
    });

    it('should restore session from localStorage when rememberMe is true', () => {
      // Set remember me preference
      localStorage.setItem('auth_remember_me', 'true');

      // Manually set session data in localStorage
      const mockUser = MOCK_USERS[0];
      localStorage.setItem('auth_user', JSON.stringify(mockUser));
      localStorage.setItem('auth_token', 'mock-token');
      localStorage.setItem('auth_refresh_token', 'mock-refresh-token');

      // Create new service instance
      const newService = new AuthService();

      expect(newService.user()).not.toBeNull();
      expect(newService.isAuthenticated()).toBe(true);
    });

    it('should handle corrupted session data gracefully', () => {
      // Set invalid JSON
      sessionStorage.setItem('auth_user', 'invalid-json');
      sessionStorage.setItem('auth_token', 'mock-token');

      // Create new service instance (should not throw)
      const newService = new AuthService();

      expect(newService.user()).toBeNull();
      expect(newService.isAuthenticated()).toBe(false);
    });
  });

  describe('authState computed signal', () => {
    it('should return complete auth state', () => {
      const state = service.authState();
      expect(state.user).toBeNull();
      expect(state.token).toBeNull();
      expect(state.isAuthenticated).toBe(false);
      expect(state.isLoading).toBe(false);
      expect(state.error).toBeNull();
    });

    it('should update when user logs in', (done) => {
      service
        .login({
          email: 'jack@aibenefits.com',
          password: 'password',
        })
        .subscribe({
          next: () => {
            const state = service.authState();
            expect(state.user).not.toBeNull();
            expect(state.token).not.toBeNull();
            expect(state.isAuthenticated).toBe(true);
            done();
          },
        });
    });
  });
});

// Made with Bob
