/**
 * Authentication Models Barrel File
 * 
 * This file exports all authentication-related models, interfaces, and types
 * for convenient importing throughout the application.
 * 
 * @module auth/models
 * 
 * @example
 * // Import specific models
 * import { User, LoginRequest, LoginResponse } from '@app/features/auth/models';
 * 
 * @example
 * // Import all models
 * import * as AuthModels from '@app/features/auth/models';
 */

// User models
export type { User, UserRole, DemoAccount } from './user.model';

// Authentication models
export type {
  LoginRequest,
  LoginResponse,
  RefreshTokenRequest,
  RefreshTokenResponse,
  AuthState,
  LogoutRequest,
  LogoutResponse,
  ApiErrorResponse,
} from './auth.model';

// Made with Bob
