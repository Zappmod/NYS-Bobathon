import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { guestGuard } from './guest.guard';
import { AuthService } from '../services/auth.service';

describe('guestGuard', () => {
  let mockAuthService: jasmine.SpyObj<AuthService>;
  let mockRouter: jasmine.SpyObj<Router>;

  beforeEach(() => {
    // Create mock AuthService
    mockAuthService = jasmine.createSpyObj('AuthService', ['isAuthenticated']);

    // Create mock Router
    mockRouter = jasmine.createSpyObj('Router', ['navigate']);

    TestBed.configureTestingModule({
      providers: [
        { provide: AuthService, useValue: mockAuthService },
        { provide: Router, useValue: mockRouter },
      ],
    });
  });

  it('should be created', () => {
    expect(guestGuard).toBeTruthy();
  });

  describe('Unauthenticated User', () => {
    beforeEach(() => {
      mockAuthService.isAuthenticated.and.returnValue(false);
    });

    it('should allow access when user is not authenticated', () => {
      const result = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(result).toBe(true);
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should not redirect when user is not authenticated', () => {
      TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should check authentication status', () => {
      TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(mockAuthService.isAuthenticated).toHaveBeenCalled();
    });

    it('should allow access to login page', () => {
      const result = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(result).toBe(true);
    });

    it('should allow access to register page', () => {
      const result = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(result).toBe(true);
    });
  });

  describe('Authenticated User', () => {
    beforeEach(() => {
      mockAuthService.isAuthenticated.and.returnValue(true);
    });

    it('should deny access when user is authenticated', () => {
      const result = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(result).toBe(false);
    });

    it('should redirect to products page', () => {
      TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(mockRouter.navigate).toHaveBeenCalledWith(['/products']);
    });

    it('should check authentication status before redirecting', () => {
      TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(mockAuthService.isAuthenticated).toHaveBeenCalled();
      expect(mockRouter.navigate).toHaveBeenCalled();
    });

    it('should prevent access to login page', () => {
      const result = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(result).toBe(false);
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/products']);
    });

    it('should prevent access to register page', () => {
      const result = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(result).toBe(false);
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/products']);
    });

    it('should prevent access to forgot password page', () => {
      const result = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(result).toBe(false);
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/products']);
    });
  });

  describe('Multiple Guard Calls', () => {
    it('should handle multiple calls with different authentication states', () => {
      // First call - not authenticated
      mockAuthService.isAuthenticated.and.returnValue(false);
      let result = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));
      expect(result).toBe(true);
      expect(mockRouter.navigate).not.toHaveBeenCalled();

      // Second call - authenticated
      mockAuthService.isAuthenticated.and.returnValue(true);
      result = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));
      expect(result).toBe(false);
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/products']);
    });

    it('should be called only once per navigation', () => {
      mockAuthService.isAuthenticated.and.returnValue(false);

      TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(mockAuthService.isAuthenticated).toHaveBeenCalledTimes(1);
    });
  });

  describe('Inverse Logic of AuthGuard', () => {
    it('should allow access when authGuard would deny', () => {
      mockAuthService.isAuthenticated.and.returnValue(false);

      const result = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(result).toBe(true);
    });

    it('should deny access when authGuard would allow', () => {
      mockAuthService.isAuthenticated.and.returnValue(true);

      const result = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(result).toBe(false);
    });

    it('should redirect when authGuard would not', () => {
      mockAuthService.isAuthenticated.and.returnValue(true);

      TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(mockRouter.navigate).toHaveBeenCalled();
    });

    it('should not redirect when authGuard would', () => {
      mockAuthService.isAuthenticated.and.returnValue(false);

      TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });
  });

  describe('Edge Cases', () => {
    it('should handle rapid authentication state changes', () => {
      // Simulate rapid state changes
      mockAuthService.isAuthenticated.and.returnValue(false);
      let result1 = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      mockAuthService.isAuthenticated.and.returnValue(true);
      let result2 = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      mockAuthService.isAuthenticated.and.returnValue(false);
      let result3 = TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(result1).toBe(true);
      expect(result2).toBe(false);
      expect(result3).toBe(true);
    });

    it('should always redirect to /products for authenticated users', () => {
      mockAuthService.isAuthenticated.and.returnValue(true);

      // Multiple calls should always redirect to same place
      TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));
      TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));
      TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(mockRouter.navigate).toHaveBeenCalledTimes(3);
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/products']);
    });
  });

  describe('Integration with AuthService', () => {
    it('should rely on AuthService for authentication state', () => {
      mockAuthService.isAuthenticated.and.returnValue(false);

      TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      expect(mockAuthService.isAuthenticated).toHaveBeenCalled();
    });

    it('should not cache authentication state', () => {
      // First call
      mockAuthService.isAuthenticated.and.returnValue(false);
      TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      // Second call with different state
      mockAuthService.isAuthenticated.and.returnValue(true);
      TestBed.runInInjectionContext(() => guestGuard({} as any, {} as any));

      // Should call isAuthenticated each time
      expect(mockAuthService.isAuthenticated).toHaveBeenCalledTimes(2);
    });
  });
});

// Made with Bob
