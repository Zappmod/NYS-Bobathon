import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, switchMap, throwError } from 'rxjs';
import { AuthService } from '../services/auth.service';

/**
 * HTTP Interceptor for JWT Authentication
 *
 * This functional interceptor handles:
 * - Adding JWT Bearer token to outgoing requests
 * - Skipping token for public endpoints (login, refresh)
 * - Automatic token refresh on 401 Unauthorized responses
 * - Logout and redirect on refresh failure
 *
 * @example
 * ```typescript
 * // In app.config.ts
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideHttpClient(
 *       withInterceptors([authInterceptor])
 *     )
 *   ]
 * };
 * ```
 *
 * **Flow:**
 * 1. Check if endpoint is public (login, refresh) → skip token
 * 2. Add Authorization header with Bearer token if authenticated
 * 3. On 401 error → attempt token refresh → retry original request
 * 4. On refresh failure → logout and redirect to login
 *
 * @param {HttpRequest<unknown>} req - The outgoing HTTP request
 * @param {HttpHandlerFn} next - The next handler in the chain
 * @returns {Observable<HttpEvent<unknown>>} Observable of HTTP events
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // List of public endpoints that don't require authentication
  const publicEndpoints = [
    '/auth/login',
    '/auth/refresh',
    '/auth/forgot-password',
    '/auth/reset-password',
  ];

  // Check if the request is to a public endpoint
  const isPublicEndpoint = publicEndpoints.some((endpoint) =>
    req.url.includes(endpoint)
  );

  // Don't add token for public endpoints
  if (isPublicEndpoint) {
    return next(req);
  }

  // Get current token
  const token = authService.token();

  // Clone request and add Authorization header if token exists
  let authReq = req;
  if (token) {
    authReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      },
    });
  }

  // Handle the request and catch errors
  return next(authReq).pipe(
    catchError((error: HttpErrorResponse) => {
      // Handle 401 Unauthorized - attempt token refresh
      if (error.status === 401 && !req.url.includes('/auth/refresh')) {
        const refreshToken = authService.refreshToken();

        // If no refresh token, logout and redirect
        if (!refreshToken) {
          console.warn('No refresh token available, logging out');
          authService.logout();
          router.navigate(['/login'], {
            queryParams: { returnUrl: router.url },
          });
          return throwError(() => error);
        }

        // Attempt to refresh the access token
        return authService.refreshAccessToken().pipe(
          switchMap((response) => {
            // Token refreshed successfully, retry the original request with new token
            const retryReq = req.clone({
              setHeaders: {
                Authorization: `Bearer ${response.token}`,
              },
            });
            return next(retryReq);
          }),
          catchError((refreshError) => {
            // Token refresh failed, logout and redirect
            console.error('Token refresh failed:', refreshError);
            authService.logout();
            router.navigate(['/login'], {
              queryParams: { returnUrl: router.url },
            });
            return throwError(() => refreshError);
          })
        );
      }

      // For other errors, log and pass through
      if (error.status !== 401) {
        console.warn(`HTTP Error ${error.status}:`, error.message);
      }

      return throwError(() => error);
    })
  );
};

// Made with Bob
