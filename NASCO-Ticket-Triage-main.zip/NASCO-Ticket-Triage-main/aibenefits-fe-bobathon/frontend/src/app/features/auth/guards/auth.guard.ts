import { CanActivateFn, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

/**
 * Authentication Route Guard
 * 
 * Functional guard that protects routes requiring authentication.
 * Redirects unauthenticated users to the login page while preserving
 * the intended destination URL.
 * 
 * **Usage:**
 * ```typescript
 * // In route configuration
 * {
 *   path: 'products',
 *   component: ProductsComponent,
 *   canActivate: [authGuard]
 * }
 * ```
 * 
 * **Features:**
 * - Checks if user is authenticated via AuthService
 * - Redirects to /login if not authenticated
 * - Preserves return URL in query parameters
 * - Validates token presence (not just user object)
 * 
 * @param {ActivatedRouteSnapshot} route - The activated route snapshot
 * @param {RouterStateSnapshot} state - The router state snapshot
 * @returns {boolean} True if user can activate the route, false otherwise
 * 
 * @example
 * ```typescript
 * // Protected route
 * const routes: Routes = [
 *   {
 *     path: 'dashboard',
 *     component: DashboardComponent,
 *     canActivate: [authGuard]
 *   }
 * ];
 * 
 * // User not authenticated → redirects to /login?returnUrl=/dashboard
 * // User authenticated → allows access to /dashboard
 * ```
 */
export const authGuard: CanActivateFn = (
  route: ActivatedRouteSnapshot,
  state: RouterStateSnapshot
): boolean => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // Check if user is authenticated
  const isAuthenticated = authService.isAuthenticated();

  if (isAuthenticated) {
    // User is authenticated - allow access
    return true;
  }

  // User is not authenticated - redirect to login
  // Preserve the intended destination URL as a query parameter
  router.navigate(['/login'], {
    queryParams: {
      returnUrl: state.url
    }
  });

  return false;
};

// Made with Bob
