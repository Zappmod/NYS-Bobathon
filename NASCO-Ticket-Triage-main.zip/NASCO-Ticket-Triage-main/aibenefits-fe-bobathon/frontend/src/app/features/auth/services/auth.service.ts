import { Injectable, signal, computed, effect, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, of, Observer } from 'rxjs';
import { map, catchError, tap, delay } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import {
  User,
  LoginRequest,
  LoginResponse,
  RefreshTokenRequest,
  RefreshTokenResponse,
  AuthState,
} from '../models';
import {
  getMockUserPermissions,
  validateMockCredentials,
  generateMockToken,
  generateMockRefreshToken
} from './auth.mock';

/**
 * Authentication Service
 *
 * Manages user authentication, session state, and token management.
 * Uses Angular signals for reactive state management.
 *
 * **Implementation**: Uses mock data when `environment.useMockData` is true, otherwise uses real HTTP API calls.
 * 
 * @class AuthService
 * @injectable
 * 
 * @example
 * ```typescript
 * export class LoginComponent {
 *   private authService = inject(AuthService);
 * 
 *   login(email: string, password: string, rememberMe: boolean) {
 *     this.authService.login({ email, password, rememberMe }).subscribe({
 *       next: (response) => console.log('Login successful', response.user),
 *       error: (error) => console.error('Login failed', error)
 *     });
 *   }
 * }
 * ```
 */
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly apiUrl = `${environment.apiUrl}/v1`;

  // Private signals for internal state management
  private readonly userSignal = signal<User | null>(null);
  private readonly tokenSignal = signal<string | null>(null);
  private readonly refreshTokenSignal = signal<string | null>(null);
  private readonly isLoadingSignal = signal<boolean>(false);
  private readonly errorSignal = signal<string | null>(null);

  // Public readonly signals for external consumption
  /**
   * Current authenticated user (null if not authenticated)
   */
  readonly user = this.userSignal.asReadonly();

  /**
   * Current JWT access token (null if not authenticated)
   */
  readonly token = this.tokenSignal.asReadonly();

  /**
   * Current refresh token (null if not authenticated)
   */
  readonly refreshToken = this.refreshTokenSignal.asReadonly();

  /**
   * Loading state indicator
   */
  readonly isLoading = this.isLoadingSignal.asReadonly();

  /**
   * Last error message (null if no error)
   */
  readonly error = this.errorSignal.asReadonly();

  /**
   * Computed signal indicating if user is authenticated
   */
  readonly isAuthenticated = computed(() => {
    const user = this.user();
    const token = this.token();
    return user !== null && token !== null;
  });

  /**
   * Computed signal for current authentication state
   */
  readonly authState = computed<AuthState>(() => ({
    user: this.user(),
    token: this.token(),
    isAuthenticated: this.isAuthenticated(),
    isLoading: this.isLoading(),
    error: this.error(),
  }));

  // Storage keys
  private readonly TOKEN_KEY = 'auth_token';
  private readonly REFRESH_TOKEN_KEY = 'auth_refresh_token';
  private readonly USER_KEY = 'auth_user';
  private readonly REMEMBER_ME_KEY = 'auth_remember_me';

  constructor() {
    // Restore session on service initialization
    this.restoreSession();

    // Effect to sync state with storage
    effect(() => {
      const user = this.user();
      const token = this.token();
      const refreshToken = this.refreshToken();

      if (user && token && refreshToken) {
        this.persistSession(user, token, refreshToken);
      }
    });
  }

  /**
   * Authenticate user with email and password.
   *
   * Makes HTTP POST request to /api/v1/auth/login endpoint.
   *
   * @param {LoginRequest} credentials - User credentials
   * @returns {Observable<LoginResponse>} Observable of login response
   *
   * @example
   * ```typescript
   * this.authService.login({
   *   email: 'jack@aibenefits.com',
   *   password: 'password',
   *   rememberMe: true
   * }).subscribe({
   *   next: (response) => {
   *     console.log('Logged in as:', response.user.name);
   *     this.router.navigate(['/products']);
   *   },
   *   error: (error) => {
   *     console.error('Login failed:', error);
   *   }
   * });
   * ```
   */
  login(credentials: LoginRequest): Observable<LoginResponse> {
    this.isLoadingSignal.set(true);
    this.errorSignal.set(null);

    // Use mock data if configured
    if (environment.useMockData) {
      return new Observable<LoginResponse>((observer: Observer<LoginResponse>) => {
        // Simulate network delay
        setTimeout(() => {
          const user = validateMockCredentials(credentials.email, credentials.password);
          
          if (user) {
            const token = generateMockToken(user);
            const refreshToken = generateMockRefreshToken(user);
            
            const response: LoginResponse = {
              user,
              token,
              refreshToken,
              expiresIn: 3600  // 1 hour in seconds
            };
            
            // Update state
            this.userSignal.set(user);
            this.tokenSignal.set(token);
            this.refreshTokenSignal.set(refreshToken);
            this.setRememberMe(credentials.rememberMe || false);
            this.persistSession(user, token, refreshToken);
            this.isLoadingSignal.set(false);
            
            observer.next(response);
            observer.complete();
          } else {
            this.isLoadingSignal.set(false);
            this.errorSignal.set('Invalid email or password.');
            observer.error(new Error('Invalid credentials'));
          }
        }, 500);
      });
    }

    // Real HTTP implementation
    return this.http
      .post<LoginResponse>(`${this.apiUrl}/auth/login`, credentials)
      .pipe(
        tap((response: LoginResponse) => {
          // Update state
          this.userSignal.set(response.user);
          this.tokenSignal.set(response.token);
          this.refreshTokenSignal.set(response.refreshToken);

          // Store remember me preference
          this.setRememberMe(credentials.rememberMe || false);

          // Persist session
          this.persistSession(response.user, response.token, response.refreshToken);

          this.isLoadingSignal.set(false);
        }),
        catchError((error: HttpErrorResponse) => {
          this.isLoadingSignal.set(false);
          const errorMessage = this.extractErrorMessage(error);
          this.errorSignal.set(errorMessage);
          return throwError(() => error);
        })
      );
  }

  /**
   * Logout current user and clear session.
   *
   * Makes HTTP POST request to /api/v1/auth/logout to revoke tokens on server.
   * Clears all authentication state and removes tokens from storage.
   *
   * @example
   * ```typescript
   * this.authService.logout();
   * this.router.navigate(['/login']);
   * ```
   */
  logout(): void {
    // Use mock data if configured
    if (environment.useMockData) {
      // Mock implementation - just clear state
      this.userSignal.set(null);
      this.tokenSignal.set(null);
      this.refreshTokenSignal.set(null);
      this.errorSignal.set(null);
      this.clearSession();
      return;
    }

    // Real HTTP implementation
    const currentRefreshToken = this.refreshToken();
    
    // Call backend logout endpoint if refresh token exists
    if (currentRefreshToken) {
      const request: RefreshTokenRequest = {
        refreshToken: currentRefreshToken,
      };
      
      this.http.post(`${this.apiUrl}/auth/logout`, request).subscribe({
        error: (error: unknown) => console.error('Logout API call failed:', error),
      });
    }

    // Clear signals
    this.userSignal.set(null);
    this.tokenSignal.set(null);
    this.refreshTokenSignal.set(null);
    this.errorSignal.set(null);

    // Clear storage
    this.clearSession();
  }

  /**
   * Refresh access token using refresh token.
   *
   * Makes HTTP POST request to /api/v1/auth/refresh endpoint.
   *
   * @returns {Observable<RefreshTokenResponse>} Observable of refresh response
   *
   * @example
   * ```typescript
   * this.authService.refreshAccessToken().subscribe({
   *   next: (response) => console.log('Token refreshed'),
   *   error: (error) => {
   *     console.error('Token refresh failed');
   *     this.authService.logout();
   *     this.router.navigate(['/login']);
   *   }
   * });
   * ```
   */
  refreshAccessToken(): Observable<RefreshTokenResponse> {
    const currentRefreshToken = this.refreshToken();

    if (!currentRefreshToken) {
      return throwError(() => new Error('No refresh token available'));
    }

    // Use mock data if configured
    if (environment.useMockData) {
      return new Observable<RefreshTokenResponse>((observer: Observer<RefreshTokenResponse>) => {
        setTimeout(() => {
          const user = this.user();
          if (user) {
            const newToken = generateMockToken(user);
            const response: RefreshTokenResponse = {
              token: newToken,
              expiresIn: 3600  // 1 hour in seconds
            };
            
            this.tokenSignal.set(newToken);
            const storage = this.getStorage();
            storage.setItem(this.TOKEN_KEY, newToken);
            
            observer.next(response);
            observer.complete();
          } else {
            this.errorSignal.set('Token refresh failed');
            observer.error(new Error('No user found'));
          }
        }, 300);
      });
    }

    // Real HTTP implementation
    const request: RefreshTokenRequest = {
      refreshToken: currentRefreshToken,
    };

    return this.http
      .post<RefreshTokenResponse>(`${this.apiUrl}/auth/refresh`, request)
      .pipe(
        tap((response: RefreshTokenResponse) => {
          // Update token signal
          this.tokenSignal.set(response.token);

          // Update storage
          const storage = this.getStorage();
          storage.setItem(this.TOKEN_KEY, response.token);
        }),
        catchError((error: HttpErrorResponse) => {
          this.errorSignal.set('Token refresh failed');
          return throwError(() => error);
        })
      );
  }

  /**
   * Get current user's permissions.
   * 
   * @returns {ReadonlyArray<string>} Array of permission strings
   * 
   * @example
   * ```typescript
   * const permissions = this.authService.getUserPermissions();
   * const canEdit = permissions.includes('PRODUCT_UPDATE');
   * ```
   */
  getUserPermissions(): ReadonlyArray<string> {
    const user = this.user();
    return user ? getMockUserPermissions(user) : [];
  }

  /**
   * Check if user has a specific permission.
   * 
   * @param {string} permission - Permission to check
   * @returns {boolean} True if user has the permission
   * 
   * @example
   * ```typescript
   * if (this.authService.hasPermission('PRODUCT_UPDATE')) {
   *   // Show edit button
   * }
   * ```
   */
  hasPermission(permission: string): boolean {
    const permissions = this.getUserPermissions();
    return permissions.includes(permission);
  }

  /**
   * Check if user can edit resources.
   * 
   * @returns {boolean} True if user has edit permissions
   * 
   * @example
   * ```typescript
   * <button *ngIf="authService.canEdit()">Edit</button>
   * ```
   */
  canEdit(): boolean {
    const user = this.user();
    return user?.canEdit || false;
  }

  /**
   * Restore session from storage on app initialization.
   * 
   * @private
   */
  private restoreSession(): void {
    try {
      const storage = this.getStorage();
      const userJson = storage.getItem(this.USER_KEY);
      const token = storage.getItem(this.TOKEN_KEY);
      const refreshToken = storage.getItem(this.REFRESH_TOKEN_KEY);

      if (userJson && token && refreshToken) {
        const user = JSON.parse(userJson) as User;

        // Restore state
        this.userSignal.set(user);
        this.tokenSignal.set(token);
        this.refreshTokenSignal.set(refreshToken);

        // TODO: In production, validate token with backend
        // If token is expired, attempt to refresh it
      }
    } catch (error) {
      console.error('Failed to restore session:', error);
      this.clearSession();
    }
  }

  /**
   * Persist session to storage.
   * 
   * @private
   * @param {User} user - User to persist
   * @param {string} token - Access token to persist
   * @param {string} refreshToken - Refresh token to persist
   */
  private persistSession(user: User, token: string, refreshToken: string): void {
    try {
      const storage = this.getStorage();
      storage.setItem(this.USER_KEY, JSON.stringify(user));
      storage.setItem(this.TOKEN_KEY, token);
      storage.setItem(this.REFRESH_TOKEN_KEY, refreshToken);
    } catch (error) {
      console.error('Failed to persist session:', error);
    }
  }

  /**
   * Clear session from storage.
   * 
   * @private
   */
  private clearSession(): void {
    try {
      const storage = this.getStorage();
      storage.removeItem(this.USER_KEY);
      storage.removeItem(this.TOKEN_KEY);
      storage.removeItem(this.REFRESH_TOKEN_KEY);
      storage.removeItem(this.REMEMBER_ME_KEY);
    } catch (error) {
      console.error('Failed to clear session:', error);
    }
  }

  /**
   * Get appropriate storage based on remember me preference.
   * 
   * @private
   * @returns {Storage} localStorage or sessionStorage
   */
  private getStorage(): Storage {
    const rememberMe = this.getRememberMe();
    return rememberMe ? localStorage : sessionStorage;
  }

  /**
   * Set remember me preference.
   * 
   * @private
   * @param {boolean} rememberMe - Remember me flag
   */
  private setRememberMe(rememberMe: boolean): void {
    try {
      // Store preference in localStorage (always persistent)
      localStorage.setItem(this.REMEMBER_ME_KEY, String(rememberMe));
    } catch (error) {
      console.error('Failed to set remember me preference:', error);
    }
  }

  /**
   * Get remember me preference.
   * 
   * @private
   * @returns {boolean} Remember me flag
   */
  private getRememberMe(): boolean {
    try {
      const value = localStorage.getItem(this.REMEMBER_ME_KEY);
      return value === 'true';
    } catch (error) {
      return false;
    }
  }

  /**
   * Extract user-friendly error message from HTTP error response.
   *
   * @private
   * @param {HttpErrorResponse} error - HTTP error response
   * @returns {string} User-friendly error message
   */
  private extractErrorMessage(error: HttpErrorResponse): string {
    // Check if error has a message from backend
    if (error.error && typeof error.error === 'object') {
      // Backend error response format: { errorCode, errorMessage, timestamp, path }
      if (error.error.errorMessage) {
        return error.error.errorMessage;
      }
      if (error.error.message) {
        return error.error.message;
      }
    }

    // Map HTTP status codes to user-friendly messages
    switch (error.status) {
      case 400:
        return 'Invalid request. Please check your input.';
      case 401:
        return 'Invalid email or password.';
      case 423:
        return 'Account locked due to multiple failed login attempts. Please try again later.';
      case 500:
        return 'Server error. Please try again later.';
      case 0:
        return 'Unable to connect to server. Please check your internet connection.';
      default:
        return error.message || 'An unexpected error occurred.';
    }
  }
}

// Made with Bob
