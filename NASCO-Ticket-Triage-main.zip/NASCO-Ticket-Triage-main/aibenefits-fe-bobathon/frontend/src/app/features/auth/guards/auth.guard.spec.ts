import { TestBed } from '@angular/core/testing';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { authGuard } from './auth.guard';
import { AuthService } from '../services/auth.service';

describe('authGuard', () => {
  let mockAuthService: jasmine.SpyObj<AuthService>;
  let mockRouter: jasmine.SpyObj<Router>;
  let mockRoute: ActivatedRouteSnapshot;
  let mockState: RouterStateSnapshot;

  beforeEach(() => {
    // Create mock AuthService
    mockAuthService = jasmine.createSpyObj('AuthService', ['isAuthenticated']);

    // Create mock Router
    mockRouter = jasmine.createSpyObj('Router', ['navigate']);

    // Create mock route and state
    mockRoute = {} as ActivatedRouteSnapshot;
    mockState = { url: '/products' } as RouterStateSnapshot;

    TestBed.configureTestingModule({
      providers: [
        { provide: AuthService, useValue: mockAuthService },
        { provide: Router, useValue: mockRouter },
      ],
    });
  });

  it('should be created', () => {
    expect(authGuard).toBeTruthy();
  });

  describe('Authenticated User', () => {
    beforeEach(() => {
      mockAuthService.isAuthenticated.and.returnValue(true);
    });

    it('should allow access when user is authenticated', () => {
      const result = TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );

      expect(result).toBe(true);
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should not redirect when user is authenticated', () => {
      TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );

      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should check authentication status', () => {
      TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );

      expect(mockAuthService.isAuthenticated).toHaveBeenCalled();
    });
  });

  describe('Unauthenticated User', () => {
    beforeEach(() => {
      mockAuthService.isAuthenticated.and.returnValue(false);
    });

    it('should deny access when user is not authenticated', () => {
      const result = TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );

      expect(result).toBe(false);
    });

    it('should redirect to login page', () => {
      TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );

      expect(mockRouter.navigate).toHaveBeenCalledWith(['/login'], {
        queryParams: { returnUrl: '/products' },
      });
    });

    it('should preserve return URL in query params', () => {
      mockState.url = '/dashboard/analytics';

      TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );

      expect(mockRouter.navigate).toHaveBeenCalledWith(['/login'], {
        queryParams: { returnUrl: '/dashboard/analytics' },
      });
    });

    it('should handle root URL', () => {
      mockState.url = '/';

      TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );

      expect(mockRouter.navigate).toHaveBeenCalledWith(['/login'], {
        queryParams: { returnUrl: '/' },
      });
    });

    it('should handle URLs with query parameters', () => {
      mockState.url = '/products?category=electronics&sort=price';

      TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );

      expect(mockRouter.navigate).toHaveBeenCalledWith(['/login'], {
        queryParams: { returnUrl: '/products?category=electronics&sort=price' },
      });
    });

    it('should handle URLs with fragments', () => {
      mockState.url = '/products#featured';

      TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );

      expect(mockRouter.navigate).toHaveBeenCalledWith(['/login'], {
        queryParams: { returnUrl: '/products#featured' },
      });
    });

    it('should check authentication status before redirecting', () => {
      TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );

      expect(mockAuthService.isAuthenticated).toHaveBeenCalled();
      expect(mockRouter.navigate).toHaveBeenCalled();
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty state URL', () => {
      mockAuthService.isAuthenticated.and.returnValue(false);
      mockState.url = '';

      TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );

      expect(mockRouter.navigate).toHaveBeenCalledWith(['/login'], {
        queryParams: { returnUrl: '' },
      });
    });

    it('should handle nested routes', () => {
      mockAuthService.isAuthenticated.and.returnValue(false);
      mockState.url = '/products/123/details';

      TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );

      expect(mockRouter.navigate).toHaveBeenCalledWith(['/login'], {
        queryParams: { returnUrl: '/products/123/details' },
      });
    });

    it('should be called only once per navigation', () => {
      mockAuthService.isAuthenticated.and.returnValue(true);

      TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );

      expect(mockAuthService.isAuthenticated).toHaveBeenCalledTimes(1);
    });
  });

  describe('Multiple Guard Calls', () => {
    it('should handle multiple calls with different authentication states', () => {
      // First call - authenticated
      mockAuthService.isAuthenticated.and.returnValue(true);
      let result = TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );
      expect(result).toBe(true);

      // Second call - not authenticated
      mockAuthService.isAuthenticated.and.returnValue(false);
      result = TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );
      expect(result).toBe(false);
      expect(mockRouter.navigate).toHaveBeenCalled();
    });

    it('should handle multiple calls with different URLs', () => {
      mockAuthService.isAuthenticated.and.returnValue(false);

      // First call
      mockState.url = '/products';
      TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/login'], {
        queryParams: { returnUrl: '/products' },
      });

      // Second call
      mockState.url = '/services';
      TestBed.runInInjectionContext(() =>
        authGuard(mockRoute, mockState)
      );
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/login'], {
        queryParams: { returnUrl: '/services' },
      });
    });
  });
});

// Made with Bob
