import { User } from './user.model';

/**
 * Login request payload for user authentication.
 * 
 * @interface LoginRequest
 * @property {string} email - User's email address (required, must be valid email format)
 * @property {string} password - User's password (required, minimum 1 character)
 * @property {boolean} [rememberMe] - Optional flag to persist session (default: false)
 */
export interface LoginRequest {
  email: string;
  password: string;
  rememberMe?: boolean;
}

/**
 * Login response containing user profile and authentication tokens.
 * 
 * @interface LoginResponse
 * @property {User} user - Authenticated user's profile information
 * @property {string} token - JWT access token for API authentication
 * @property {string} refreshToken - JWT refresh token for obtaining new access tokens
 * @property {number} expiresIn - Access token expiration time in seconds
 */
export interface LoginResponse {
  user: User;
  token: string;
  refreshToken: string;
  expiresIn: number;
}

/**
 * Refresh token request payload.
 * 
 * @interface RefreshTokenRequest
 * @property {string} refreshToken - JWT refresh token to exchange for new access token
 */
export interface RefreshTokenRequest {
  refreshToken: string;
}

/**
 * Refresh token response containing new access token.
 * 
 * @interface RefreshTokenResponse
 * @property {string} token - New JWT access token
 * @property {number} expiresIn - Token expiration time in seconds
 */
export interface RefreshTokenResponse {
  token: string;
  expiresIn: number;
}

/**
 * Authentication state representing the current authentication status.
 * Used for managing authentication state in the application.
 * 
 * @interface AuthState
 * @property {User | null} user - Currently authenticated user (null if not authenticated)
 * @property {string | null} token - Current JWT access token (null if not authenticated)
 * @property {boolean} isAuthenticated - Flag indicating if user is authenticated
 * @property {boolean} isLoading - Flag indicating if authentication operation is in progress
 * @property {string | null} error - Error message from last authentication operation (null if no error)
 */
export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

/**
 * Logout request payload.
 * 
 * @interface LogoutRequest
 * @property {string} refreshToken - JWT refresh token to revoke
 */
export interface LogoutRequest {
  refreshToken: string;
}

/**
 * Logout response.
 * 
 * @interface LogoutResponse
 * @property {boolean} success - Indicates if logout was successful
 * @property {string} message - Success message
 */
export interface LogoutResponse {
  success: boolean;
  message: string;
}

/**
 * API error response structure.
 * 
 * @interface ApiErrorResponse
 * @property {string} errorCode - Application-specific error code
 * @property {string} errorMessage - Human-readable error message
 * @property {string} timestamp - ISO 8601 timestamp of when error occurred
 * @property {string} path - API path where error occurred
 */
export interface ApiErrorResponse {
  errorCode: string;
  errorMessage: string;
  timestamp: string;
  path: string;
}

// Made with Bob
