import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

/**
 * Guest Route Guard
 * 
 * Functional guard that protects routes intended for unauthenticated users only
 * (e.g., login page, registration page). Redirects authenticated users away from
 * these pages to prevent unnecessary access.
 * 
 * **Usage:**
 * ```typescript
 * // In route configuration
 * {
 *   path: 'login',
 *   component: LoginComponent,
 *   canActivate: [guestGuard]
 * }
 * ```
 * 
 * **Features:**
 * - Checks if user is authenticated via AuthService
 * - Redirects to /products if authenticated
 * - Allows access if not authenticated
 * - Inverse logic of authGuard
 * 
 * @param {ActivatedRouteSnapshot} route - The activated route snapshot
 * @param {RouterStateSnapshot} state - The router state snapshot
 * @returns {boolean} True if user can activate the route (not authenticated), false otherwise
 * 
 * @example
 * ```typescript
 * // Guest-only route
 * const routes: Routes = [
 *   {
 *     path: 'login',
 *     component: LoginComponent,
 *     canActivate: [guestGuard]
 *   },
 *   {
 *     path: 'register',
 *     component: RegisterComponent,
 *     canActivate: [guestGuard]
 *   }
 * ];
 * 
 * // User authenticated → redirects to /products
 * // User not authenticated → allows access to login/register
 * ```
 */
export const guestGuard: CanActivateFn = (): boolean => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // Check if user is authenticated
  const isAuthenticated = authService.isAuthenticated();

  if (isAuthenticated) {
    // User is already authenticated - redirect to products page
    router.navigate(['/products']);
    return false;
  }

  // User is not authenticated - allow access to guest pages
  return true;
};

// Made with Bob
