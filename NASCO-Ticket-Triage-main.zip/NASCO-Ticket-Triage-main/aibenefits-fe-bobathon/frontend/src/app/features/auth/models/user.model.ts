/**
 * User model representing an authenticated user in the system.
 * 
 * @interface User
 * @property {string} id - Unique identifier for the user (UUID)
 * @property {string} name - Display name of the user
 * @property {string} email - Email address (unique identifier for login)
 * @property {UserRole} role - User's role in the system
 * @property {boolean} canEdit - Permission flag indicating if user can edit resources
 */
export interface User {
  readonly id: string;
  readonly name: string;
  readonly email: string;
  readonly role: UserRole;
  readonly canEdit: boolean;
}

/**
 * User role type defining available roles in the system.
 * 
 * @typedef {string} UserRole
 * @description
 * - 'Benefit Developer': Full access with edit capabilities
 * - 'Product Reviewer': Read-only access for review purposes
 */
export type UserRole = 'Benefit Developer' | 'Product Reviewer';

/**
 * Demo account information for UI display.
 * Used to show available test accounts on the login page.
 * 
 * @interface DemoAccount
 * @property {string} email - Demo account email address
 * @property {string} role - Role name for display
 * @property {string} description - Brief description of account capabilities
 */
export interface DemoAccount {
  readonly email: string;
  readonly role: string;
  readonly description: string;
}

// Made with Bob
