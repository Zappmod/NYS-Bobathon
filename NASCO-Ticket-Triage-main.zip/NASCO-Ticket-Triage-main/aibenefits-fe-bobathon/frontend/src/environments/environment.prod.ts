export const environment = {
  production: true,
  apiUrl: '/api',
  useMockData: false  // Production uses real API
};

// Made with Bob
