export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api',
  useMockData: true  // Set to false when backend is ready
};

// Made with Bob
