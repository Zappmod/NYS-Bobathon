import type { Config } from 'jest';

const config: Config = {
  preset: 'jest-preset-angular',
  setupFilesAfterEnv: ['<rootDir>/setup-jest.ts'],
  testPathIgnorePatterns: [
    '<rootDir>/node_modules/',
    '<rootDir>/dist/'
  ],
  coverageDirectory: 'coverage',
  collectCoverageFrom: [
    'src/**/*.ts',
    '!src/**/*.spec.ts',
    '!src/**/*.mock.ts',
    '!src/main.ts',
    '!src/environments/**'
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80
    }
  },
  moduleNameMapper: {
    '^@aibenefit-portal/shared-ui$': '<rootDir>/src/app/shared/ui/index.ts',
    '^@aibenefit-portal/shared-models$': '<rootDir>/src/app/shared/models/index.ts',
    '^@aibenefit-portal/shared-utils$': '<rootDir>/src/app/shared/utils/index.ts',
    '^@aibenefit-portal/core$': '<rootDir>/src/app/core/index.ts'
  }
};

export default config;

// Made with Bob
