# Frontend AGENTS.md

This file provides guidance to agents when working with frontend code in this repository.

## Project-Specific Non-Obvious Rules

### Testing Framework (CRITICAL)
- Uses **Jest + jest-preset-angular**, NOT Karma/Jasmine as Angular defaults suggest
- Run single test: `npm test -- <filename>.spec.ts`
- 80% coverage threshold enforced in `jest.config.ts` - builds fail below this
- Path aliases in `jest.config.ts` must match `tsconfig.json` paths

### Tailwind Version (CRITICAL)
- Uses **Tailwind CSS v3.4.3**, NOT v4
- Standard `tailwind.config.js`, NOT `@tailwindcss/postcss`
- CSS custom properties in `src/styles.css` define theme tokens
- All colors reference CSS variables via Tailwind utilities (e.g., `bg-primary`, `text-muted`)

### Angular 18 Specifics
- Standalone components only - NO `NgModule`
- `OnPush` change detection on ALL components (enforced in `angular.json` schematics)
- New control flow: `@if`, `@for`, `@switch` - NO `*ngIf`, `*ngFor`, `*ngSwitch`
- Signal inputs/outputs: `input()`, `output()` - NOT `@Input()`, `@Output()`

### Path Aliases (Non-Standard)
- `@aibenefit-portal/shared-ui` → `src/app/shared/ui/index.ts`
- `@aibenefit-portal/shared-models` → `src/app/shared/models/index.ts`
- `@aibenefit-portal/shared-utils` → `src/app/shared/utils/index.ts`
- `@aibenefit-portal/core` → `src/app/core/index.ts`
- Configured in both `tsconfig.json` AND `jest.config.ts` - must stay in sync

### Mock Data Strategy
- Mock data goes in `.mock.ts` files in service directories, NOT in components
- Services return mock data with same signatures as future API calls
- Components consume data through services only - never directly access mocks

### Prototype Reference
- React prototype in `/prototype/` is **READ-ONLY** - UI/UX reference only
- Copy Tailwind classes and layout structure, NOT React code patterns
- Never import or reference prototype code in Angular implementation

### ESLint Configuration
- `@typescript-eslint/no-explicit-any` set to "error" - `any` type forbidden
- Unused vars with `_` prefix are allowed (e.g., `_unusedParam`)
- Component prefix: `app-` (kebab-case)
- Directive prefix: `app` (camelCase)

### Prettier Configuration
- Single quotes enforced
- 100 character line width (NOT default 80)
- Semicolons required
- Trailing commas: ES5 style

## Quick Commands

```bash
cd frontend
npm install
npm start                    # Dev server on http://localhost:4300
npm test                     # Run all Jest tests
npm test -- file.spec.ts     # Run single test file
npm run test:watch           # Watch mode
npm run test:coverage        # Coverage report
npm run lint                 # ESLint
npm run format               # Prettier format
npm run format:check         # Check formatting
npm run build                # Production build
```

## Common Gotchas

1. **angular.json test builder** still references Karma - ignore this, Jest is configured separately
2. **Test files** must be `*.spec.ts` (NOT `*.test.ts`) for Jest to find them
3. **Path aliases** break if not configured in BOTH `tsconfig.json` and `jest.config.ts`
4. **OnPush components** require immutable updates - always return new object/array references
5. **Signal inputs** don't work with `@Input()` decorators - use `input()` function instead