import 'jest-preset-angular/setup-jest';

// Made with Bob
