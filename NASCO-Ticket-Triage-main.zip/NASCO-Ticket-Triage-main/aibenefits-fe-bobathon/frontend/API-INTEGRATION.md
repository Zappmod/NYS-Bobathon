# Frontend-Backend API Integration Guide

## Overview

This document describes how the Angular frontend connects to the Spring Boot backend API for authentication and data operations.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Angular Frontend                          │
│                                                                   │
│  ┌──────────────┐      ┌──────────────┐      ┌──────────────┐  │
│  │   Login      │─────▶│  AuthService │◀─────│  Auth Guard  │  │
│  │  Component   │      │              │      │              │  │
│  └──────────────┘      └──────┬───────┘      └──────────────┘  │
│                               │                                  │
│                               ▼                                  │
│                    ┌──────────────────┐                          │
│                    │  HTTP Interceptor│                          │
│                    │  (JWT Token)     │                          │
│                    └────────┬─────────┘                          │
│                             │                                    │
└─────────────────────────────┼────────────────────────────────────┘
                              │
                              │ HTTP/HTTPS
                              │
┌─────────────────────────────▼────────────────────────────────────┐
│                     Spring Boot Backend                           │
│                                                                   │
│  ┌──────────────┐      ┌──────────────┐      ┌──────────────┐  │
│  │   Security   │─────▶│     Auth     │─────▶│  PostgreSQL  │  │
│  │    Filter    │      │  Controller  │      │   Database   │  │
│  └──────────────┘      └──────────────┘      └──────────────┘  │
│                                                                   │
└───────────────────────────────────────────────────────────────────┘
```

---

## Configuration

### Environment Variables

**Development** (`frontend/src/environments/environment.ts`):
```typescript
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api'
};
```

**Production** (`frontend/src/environments/environment.prod.ts`):
```typescript
export const environment = {
  production: true,
  apiUrl: '/api'  // Relative path for same-domain deployment
};
```

### Backend Configuration

**CORS Settings** (`backend/src/main/resources/application.properties`):
```properties
cors.allowed-origins=http://localhost:4300,http://localhost:3000
cors.allowed-methods=GET,POST,PUT,DELETE,OPTIONS,PATCH
cors.allowed-headers=*
cors.allow-credentials=true
```

**JWT Settings**:
```properties
jwt.access-token-expiration=900000      # 15 minutes
jwt.refresh-token-expiration=604800000  # 7 days
```

---

## Authentication Flow

### 1. Login Process

```typescript
// User submits login form
this.authService.login({
  email: 'jack@aibenefits.com',
  password: 'password',
  rememberMe: true
}).subscribe({
  next: (response) => {
    // Success: tokens stored, user authenticated
    // Navigate to protected route
    this.router.navigate(['/products']);
  },
  error: (error) => {
    // Display error message to user
    console.error('Login failed:', error);
  }
});
```

**HTTP Request**:
```http
POST /api/v1/auth/login HTTP/1.1
Host: localhost:8080
Content-Type: application/json

{
  "email": "jack@aibenefits.com",
  "password": "password",
  "rememberMe": true
}
```

**HTTP Response** (Success):
```
// 200 OK
{
  user: { id, name, email, role, canEdit, permissions[] },
  accessToken: <jwt>,        // short-lived access token (15 min)
  refreshToken: <jwt>,       // long-lived refresh token (7 days)
  expiresIn: 900
}
```

**Token Storage**:
- `rememberMe: true` → localStorage (persistent across browser sessions)
- `rememberMe: false` → sessionStorage (cleared when browser closes)

---

### 2. Authenticated API Calls

All API calls to protected endpoints automatically include the JWT token via the HTTP interceptor.

**Example Request**:
```http
GET /api/v1/products HTTP/1.1
Host: localhost:8080
Authorization: Bearer <YOUR_JWT_TOKEN>
```

**Interceptor Logic**:
```typescript
// auth.interceptor.ts
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = authService.token();
  
  // Skip public endpoints
  if (req.url.includes('/auth/login') || req.url.includes('/auth/refresh')) {
    return next(req);
  }
  
  // Add Authorization header
  if (token) {
    req = req.clone({
      setHeaders: { Authorization: `Bearer ${token}` }
    });
  }
  
  return next(req);
};
```

---

### 3. Token Refresh Flow

When an access token expires (15 minutes), the interceptor automatically refreshes it using the refresh token.

**Automatic Refresh on 401**:
```typescript
// Interceptor catches 401 error
catchError((error: HttpErrorResponse) => {
  if (error.status === 401 && !req.url.includes('/auth/refresh')) {
    // Attempt token refresh
    return authService.refreshAccessToken().pipe(
      switchMap((response) => {
        // Retry original request with new token
        const retryReq = req.clone({
          setHeaders: { Authorization: `Bearer ${response.token}` }
        });
        return next(retryReq);
      }),
      catchError(() => {
        // Refresh failed - logout user
        authService.logout();
        router.navigate(['/login']);
        return throwError(() => error);
      })
    );
  }
  return throwError(() => error);
})
```

**Refresh Request**:
```
POST /api/v1/auth/refresh
Body: { refreshToken: <jwt> }
```

**Refresh Response**:
```
{ accessToken: <jwt>, expiresIn: 900 }
```

---

### 4. Logout Process

```typescript
// User clicks logout
this.authService.logout();
this.router.navigate(['/login']);
```

**HTTP Request**:
```
POST /api/v1/auth/logout
Authorization: Bearer <access-token>
Body: { refreshToken: <jwt> }
```

**Actions**:
1. Revokes refresh token on server
2. Clears all tokens from storage (localStorage/sessionStorage)
3. Resets authentication state signals
4. Redirects to login page

---

## Route Protection

### Auth Guard

Protects routes requiring authentication:

```typescript
// app.routes.ts
{
  path: 'products',
  loadComponent: () => import('./features/products/...'),
  canActivate: [authGuard]  // ← Requires authentication
}
```

**Guard Logic**:
```typescript
export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  
  if (authService.isAuthenticated()) {
    return true;  // Allow access
  }
  
  // Redirect to login with return URL
  router.navigate(['/login'], {
    queryParams: { returnUrl: state.url }
  });
  return false;
};
```

### Guest Guard

Prevents authenticated users from accessing login page:

```typescript
// app.routes.ts
{
  path: 'login',
  loadComponent: () => import('./features/auth/...'),
  canActivate: [guestGuard]  // ← Redirects if already authenticated
}
```

---

## Error Handling

### Backend Error Response Format

```json
{
  "errorCode": "AUTH001",
  "errorMessage": "Invalid email or password",
  "timestamp": "2026-05-03T15:30:00.000Z",
  "path": "/api/v1/auth/login"
}
```

### Error Code Mapping

| Error Code | HTTP Status | Message |
|------------|-------------|---------|
| `AUTH001` | 401 | Invalid email or password |
| `AUTH002` | 423 | Account locked due to multiple failed attempts |
| `AUTH003` | 401 | Invalid or expired refresh token |
| `AUTH004` | 401 | Unauthorized access |
| `AUTH400` | 400 | Invalid request format |
| `SYS001` | 500 | Internal server error |

### Frontend Error Handling

```typescript
private extractErrorMessage(error: HttpErrorResponse): string {
  // Check backend error response
  if (error.error?.errorMessage) {
    return error.error.errorMessage;
  }
  
  // Map HTTP status codes
  switch (error.status) {
    case 400: return 'Invalid request. Please check your input.';
    case 401: return 'Invalid email or password.';
    case 423: return 'Account locked. Please try again later.';
    case 500: return 'Server error. Please try again later.';
    case 0: return 'Unable to connect to server.';
    default: return 'An unexpected error occurred.';
  }
}
```

---

## Testing

### Test Credentials

**Benefit Developer** (Full Access):
- Email: `jack@aibenefits.com`
- Password: `password`
- Permissions: All CRUD operations

**Product Reviewer** (Read-Only):
- Email: `smith@aibenefits.com`
- Password: `password`
- Permissions: Read-only access

### Manual Testing Steps

1. **Start Backend**:
   ```bash
   cd backend
   mvn spring-boot:run
   ```
   Backend runs on: `http://localhost:8080`

2. **Start Frontend**:
   ```bash
   cd frontend
   npm start
   ```
   Frontend runs on: `http://localhost:4300`

3. **Test Login**:
   - Navigate to `http://localhost:4300/login`
   - Enter test credentials
   - Verify successful login and redirect to `/products`

4. **Test Protected Routes**:
   - Try accessing `/products` without login → should redirect to `/login`
   - Login and access `/products` → should display products page

5. **Test Token Refresh**:
   - Login and wait 15+ minutes
   - Make an API call → should auto-refresh token
   - Verify no logout occurs

6. **Test Logout**:
   - Click logout button
   - Verify redirect to login page
   - Verify tokens cleared from storage
   - Try accessing protected route → should redirect to login

---

## API Endpoints Reference

### Authentication Endpoints

| Method | Endpoint | Auth Required | Description |
|--------|----------|---------------|-------------|
| POST | `/api/v1/auth/login` | No | User login |
| POST | `/api/v1/auth/refresh` | No | Refresh access token |
| POST | `/api/v1/auth/logout` | Yes | User logout |
| GET | `/api/v1/auth/me` | Yes | Get current user profile |

### Future Endpoints (Products, Services, Config)

| Method | Endpoint | Auth Required | Description |
|--------|----------|---------------|-------------|
| GET | `/api/v1/products` | Yes | List all products |
| GET | `/api/v1/products/{id}` | Yes | Get product by ID |
| POST | `/api/v1/products` | Yes | Create new product |
| PUT | `/api/v1/products/{id}` | Yes | Update product |
| DELETE | `/api/v1/products/{id}` | Yes | Delete product |

---

## Troubleshooting

### Issue: CORS Error

**Symptom**: Browser console shows CORS policy error

**Solution**:
1. Verify backend CORS configuration includes `http://localhost:4300`
2. Check `cors.allowed-origins` in `application.properties`
3. Restart backend after configuration changes

### Issue: 401 Unauthorized on All Requests

**Symptom**: All API calls return 401, even after login

**Solution**:
1. Check if token is being stored: Open DevTools → Application → Storage
2. Verify interceptor is registered in `app.config.ts`
3. Check if token is being added to headers in Network tab

### Issue: Token Not Refreshing

**Symptom**: User logged out after 15 minutes

**Solution**:
1. Verify refresh token is stored
2. Check interceptor catches 401 errors
3. Verify `/auth/refresh` endpoint is accessible
4. Check browser console for refresh errors

### Issue: Cannot Connect to Backend

**Symptom**: Network error, unable to reach server

**Solution**:
1. Verify backend is running: `http://localhost:8080/actuator/health`
2. Check `environment.ts` has correct `apiUrl`
3. Verify no firewall blocking port 8080

---

## Security Considerations

### Token Storage

- **Access Token**: Short-lived (15 min), stored in memory and storage
- **Refresh Token**: Long-lived (7 days), stored in localStorage/sessionStorage
- **Remember Me**: Controls storage location (localStorage vs sessionStorage)

### Best Practices

1. ✅ Always use HTTPS in production
2. ✅ Tokens stored in httpOnly cookies (future enhancement)
3. ✅ Implement CSRF protection for state-changing operations
4. ✅ Validate tokens on every request (backend)
5. ✅ Revoke refresh tokens on logout
6. ✅ Implement rate limiting on login endpoint
7. ✅ Log authentication events for audit

### Current Limitations

- Tokens stored in localStorage/sessionStorage (vulnerable to XSS)
- **Recommendation**: Migrate to httpOnly cookies for production

---

## Development Workflow

### Adding New API Endpoints

1. **Define in OpenAPI Spec** (`backend/openapi/*.yaml`)
2. **Implement Backend Controller**
3. **Create Frontend Service**:
   ```typescript
   @Injectable({ providedIn: 'root' })
   export class ProductsApiService {
     private http = inject(HttpClient);
     private apiUrl = `${environment.apiUrl}/v1/products`;
     
     getAll(): Observable<Product[]> {
       return this.http.get<Product[]>(this.apiUrl);
     }
   }
   ```
4. **Use in Components**:
   ```typescript
   export class ProductsComponent {
     private productsApi = inject(ProductsApiService);
     
     products = signal<Product[]>([]);
     
     ngOnInit() {
       this.productsApi.getAll().subscribe({
         next: (products) => this.products.set(products)
       });
     }
   }
   ```

---

## Additional Resources

- **Backend API Documentation**: `http://localhost:8080/swagger-ui.html`
- **OpenAPI Specification**: `backend/openapi/auth-api.yaml`
- **Frontend Architecture**: `frontend/AGENTS.md`
- **Backend Architecture**: `backend/AGENTS.md`

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-05-03 | Initial API integration with real backend |

---

**Last Updated**: 2026-05-03  
**Maintained By**: AIBenefit Development Team