from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="AIBenefit API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:4300"],
    allow_methods=["GET"],
    allow_headers=["*"],
)

PROPERTIES_FILE = Path(__file__).parent / "category.properties"


def load_categories() -> list[str]:
    if not PROPERTIES_FILE.exists():
        raise FileNotFoundError(f"Properties file not found: {PROPERTIES_FILE}")
    for line in PROPERTIES_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        if key.strip() == "categories":
            return [c.strip() for c in value.split(",") if c.strip()]
    return []


@app.get("/api/v1/categories")
def get_categories():
    try:
        categories = load_categories()
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"categories": categories}
