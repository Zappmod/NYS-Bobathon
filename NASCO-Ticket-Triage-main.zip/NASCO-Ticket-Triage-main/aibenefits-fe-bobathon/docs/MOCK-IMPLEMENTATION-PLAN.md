# Mock Implementation Plan

## Current State Analysis

### Auth Service (frontend/src/app/features/auth/services/auth.service.ts)
- Currently makes HTTP calls to backend API endpoints:
  - `POST /api/v1/auth/login` - Login endpoint
  - `POST /api/v1/auth/logout` - Logout endpoint  
  - `POST /api/v1/auth/refresh` - Token refresh endpoint
- Uses `HttpClient` for all API calls
- Has complete mock data available in `auth.mock.ts`

### Mock Data Available (frontend/src/app/features/auth/services/auth.mock.ts)
- `MOCK_USERS` - Two test users (Jack and Smith)
- `DEMO_ACCOUNTS` - Demo account information
- `generateMockToken()` - Generates mock JWT tokens
- `generateMockRefreshToken()` - Generates mock refresh tokens
- `validateMockCredentials()` - Validates credentials against mock users
- `getMockUserPermissions()` - Returns permissions based on role

## Implementation Plan

### Step 1: Update Environment Configuration
**File**: `frontend/src/environments/environment.ts`
- Add `useMockData: true` flag to enable mock mode
- Keep `apiUrl` for future reference but won't be used when mocking

**File**: `frontend/src/environments/environment.prod.ts`
- Add `useMockData: false` flag (production will use real API)

### Step 2: Update Auth Service to Use Mocks
**File**: `frontend/src/app/features/auth/services/auth.service.ts`

#### Changes Required:

1. **Import mock functions**:
   ```typescript
   import { 
     validateMockCredentials, 
     generateMockToken, 
     generateMockRefreshToken 
   } from './auth.mock';
   ```

2. **Update login() method**:
   - Check `environment.useMockData` flag
   - If true: Use `validateMockCredentials()` and return mock response
   - If false: Use existing HTTP call
   - Return Observable with same signature

3. **Update logout() method**:
   - Check `environment.useMockData` flag
   - If true: Skip HTTP call, just clear local state
   - If false: Use existing HTTP call

4. **Update refreshAccessToken() method**:
   - Check `environment.useMockData` flag
   - If true: Generate new mock token and return
   - If false: Use existing HTTP call

### Step 3: Implementation Details

#### Login Method (Mock Implementation)
```typescript
login(credentials: LoginRequest): Observable<LoginResponse> {
  this.isLoadingSignal.set(true);
  this.errorSignal.set(null);

  if (environment.useMockData) {
    // Mock implementation
    return new Observable(observer => {
      setTimeout(() => {
        const user = validateMockCredentials(credentials.email, credentials.password);
        
        if (user) {
          const token = generateMockToken(user);
          const refreshToken = generateMockRefreshToken(user);
          
          const response: LoginResponse = { user, token, refreshToken };
          
          // Update state
          this.userSignal.set(user);
          this.tokenSignal.set(token);
          this.refreshTokenSignal.set(refreshToken);
          this.setRememberMe(credentials.rememberMe || false);
          this.persistSession(user, token, refreshToken);
          this.isLoadingSignal.set(false);
          
          observer.next(response);
          observer.complete();
        } else {
          this.isLoadingSignal.set(false);
          this.errorSignal.set('Invalid email or password.');
          observer.error(new Error('Invalid credentials'));
        }
      }, 500); // Simulate network delay
    });
  }

  // Real HTTP implementation (existing code)
  return this.http.post<LoginResponse>(`${this.apiUrl}/auth/login`, credentials)
    .pipe(/* existing implementation */);
}
```

#### Logout Method (Mock Implementation)
```typescript
logout(): void {
  if (environment.useMockData) {
    // Mock implementation - just clear state
    this.userSignal.set(null);
    this.tokenSignal.set(null);
    this.refreshTokenSignal.set(null);
    this.errorSignal.set(null);
    this.clearSession();
    return;
  }

  // Real HTTP implementation (existing code)
  const currentRefreshToken = this.refreshToken();
  if (currentRefreshToken) {
    // ... existing HTTP call
  }
}
```

#### Refresh Token Method (Mock Implementation)
```typescript
refreshAccessToken(): Observable<RefreshTokenResponse> {
  const currentRefreshToken = this.refreshToken();

  if (!currentRefreshToken) {
    return throwError(() => new Error('No refresh token available'));
  }

  if (environment.useMockData) {
    // Mock implementation
    return new Observable(observer => {
      setTimeout(() => {
        const user = this.user();
        if (user) {
          const newToken = generateMockToken(user);
          const response: RefreshTokenResponse = { token: newToken };
          
          this.tokenSignal.set(newToken);
          const storage = this.getStorage();
          storage.setItem(this.TOKEN_KEY, newToken);
          
          observer.next(response);
          observer.complete();
        } else {
          observer.error(new Error('No user found'));
        }
      }, 300);
    });
  }

  // Real HTTP implementation (existing code)
  return this.http.post<RefreshTokenResponse>(`${this.apiUrl}/auth/refresh`, request)
    .pipe(/* existing implementation */);
}
```

### Step 4: Testing Checklist

After implementation, verify:
- [ ] Login with jack@aibenefits.com works
- [ ] Login with smith@aibenefits.com works
- [ ] Invalid credentials show error message
- [ ] Logout clears session properly
- [ ] Token refresh works (if implemented)
- [ ] Remember me functionality works
- [ ] Session persists across page refresh
- [ ] Permissions work correctly for each role
- [ ] No HTTP calls are made to backend

### Step 5: Future Migration Path

When backend is ready:
1. Set `useMockData: false` in environment.ts
2. Update `apiUrl` to point to real backend
3. No other code changes needed - service already supports both modes

## Benefits of This Approach

1. **Zero Breaking Changes**: Existing code structure remains intact
2. **Easy Toggle**: Single flag switches between mock and real API
3. **Same Interface**: Components don't know if data is mocked or real
4. **Future-Ready**: When backend is ready, just flip the flag
5. **Testable**: Can test both mock and real implementations

## Files to Modify

1. `frontend/src/environments/environment.ts` - Add useMockData flag
2. `frontend/src/environments/environment.prod.ts` - Add useMockData flag
3. `frontend/src/app/features/auth/services/auth.service.ts` - Add mock logic

## Execution Order

1. Update environment files (add useMockData flag)
2. Update auth.service.ts (add mock implementation)
3. Test login/logout functionality
4. Verify no backend calls are made
5. Update AGENTS.md if needed