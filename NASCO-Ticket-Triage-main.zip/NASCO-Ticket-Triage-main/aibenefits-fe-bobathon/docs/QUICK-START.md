# Quick Start Guide

> **Architecture**: Frontend (Angular, mock auth + products) + Python backend (FastAPI, categories API). The Python backend must be running — `GET /api/v1/categories` is always called live regardless of `useMockData`.

## Prerequisites

- Node.js 18+ and npm
- Python 3.10+

---

## 1. Start the Backend

```bash
cd backend
pip install -r requirements.txt  # First time only
uvicorn main:app --reload --port 8080
```

**Backend will run on**: `http://localhost:8080`

Verify it's up:
```
GET http://localhost:8080/api/v1/categories
→ { "categories": ["Medical", "Dental"] }
```

Interactive docs: `http://localhost:8080/docs`

---

## 2. Start the Frontend

```bash
cd frontend
npm install  # First time only
npm start
```

**Frontend will run on**: `http://localhost:4300`

---

## 3. Log In

Navigate to `http://localhost:4300` — you will be redirected to the login page automatically.

### Demo accounts

| Role | Email | Password | Access |
|---|---|---|---|
| Benefit Developer | `jack@aibenefits.com` | `nasco123!` | Full (can edit) |
| Product Reviewer | `smith@aibenefits.com` | `nasco123!` | Read-only |

### After login

1. ✅ Redirected to `/products`
2. ✅ User name appears in the header
3. ✅ Auth state stored in browser storage under keys `auth_token`, `auth_refresh_token`, `auth_user`
   - **Remember Me checked** → `localStorage`
   - **Remember Me unchecked** → `sessionStorage`

---

## 4. Verify Core Flows

### Protected routes
- Navigate to `/products` while logged in — page loads
- Log out, then navigate to `/products` — redirects to `/login`

### Logout
1. Click "Logout"
2. ✅ Redirected to `/login`
3. ✅ Tokens cleared from storage

---

## 5. Architecture Overview

### What's live (calls real API)

| Feature | Endpoint | Source |
|---|---|---|
| Category filter dropdown | `GET /api/v1/categories` | `backend/category.properties` |

### What's mocked (no backend needed)

| Feature | Mock file |
|---|---|
| Login / logout / token refresh | `auth/services/auth.mock.ts` |
| Products list, create, edit | `products/services/products.mock.ts` |

Mock behaviour is controlled by `environment.useMockData` in `frontend/src/environments/environment.ts`.

### Adding a category

Edit `backend/category.properties` and restart the backend:
```properties
categories=Medical,Dental,Vision,Life
```

---

## 6. Common Issues

### Category dropdown shows nothing / error
The Python backend is not running. Start it (see step 1).

### Login fails with "Invalid email or password"
Use the exact credentials from the table above — mock auth validates against `auth.mock.ts`.

### Page does not load / blank screen
Check the browser console (F12) for Angular errors. Ensure `npm install` completed without errors.

### Changes not reflecting
The dev server supports hot reload. If a change is not picked up, stop the server (`Ctrl+C`) and restart with `npm start`.

---

## 7. Development Workflow

### Changing mock data
Edit the relevant `*.mock.ts` file — changes take effect on next page reload.

### Adding or editing categories
Edit `backend/category.properties` — restart uvicorn to pick up changes (or use `--reload` flag).

### Adding a new feature
1. Implement in `frontend/src/app/features/`
2. Add mock data to the corresponding `*.mock.ts` file
3. Run tests: `npm test`

### Enabling real backend for auth/products (future)
1. Implement the missing endpoints (see API status below)
2. Set `useMockData: false` in `frontend/src/environments/environment.ts`
3. Verify API calls in DevTools → Network → Fetch/XHR

---

## 8. API Status

| Endpoint | Status | Notes |
|---|---|---|
| `GET /api/v1/categories` | ✅ Live (Python) | Always called |
| `POST /api/v1/auth/login` | ⏳ Mocked | HTTP code ready in `auth.service.ts` |
| `POST /api/v1/auth/logout` | ⏳ Mocked | HTTP code ready in `auth.service.ts` |
| `POST /api/v1/auth/refresh` | ⏳ Mocked | HTTP code ready in `auth.service.ts` |
| `GET /api/v1/products` | ⏳ Mocked | Needs backend + service HTTP code |
| `POST /api/v1/products` | ⏳ Mocked | Needs backend + service HTTP code |
| `PUT /api/v1/products/:id` | ⏳ Mocked | Needs backend + service HTTP code |

---

## 9. Useful Commands

### Backend
```bash
pip install -r requirements.txt
uvicorn main:app --reload --port 8080
```

### Frontend
```bash
npm install
npm start              # http://localhost:4300
npm test               # Run all tests (Jest)
npm test -- path/to/file.spec.ts  # Single test
npm run lint
npm run format
npm run build
```

---

## 10. Project Structure

```
aibenefit/
├── backend/                        # Python FastAPI backend
│   ├── main.py                     # FastAPI app (categories endpoint)
│   ├── category.properties         # Category values config
│   └── requirements.txt
│
├── frontend/                       # Angular application
│   └── src/app/
│       ├── features/
│       │   ├── auth/
│       │   │   ├── services/       # AuthService + auth.mock.ts
│       │   │   ├── interceptors/   # JWT interceptor
│       │   │   ├── guards/         # Route guards
│       │   │   └── models/
│       │   └── products/
│       │       ├── services/       # ProductsService + products.mock.ts
│       │       ├── components/     # Product UI components
│       │       └── models/
│       └── shared/ui/              # Shared UI components
│
└── QUICK-START.md                  # This file
```

---

## 11. Next Steps

1. **Explore the codebase**:
   - [frontend/src/app/features/auth/services/auth.service.ts](../frontend/src/app/features/auth/services/auth.service.ts) — authentication logic
   - [frontend/src/app/features/products/services/products.service.ts](../frontend/src/app/features/products/services/products.service.ts) — product data
   - [backend/main.py](../backend/main.py) — categories API

2. **Read the documentation**:
   - [frontend/AGENTS.md](../frontend/AGENTS.md) — frontend architecture and conventions
   - [AGENTS.md](AGENTS.md) — project-wide rules and workflow

---

## Summary Checklist

- [ ] Backend running on `http://localhost:8080`
- [ ] Frontend running on `http://localhost:4300`
- [ ] Category dropdown shows Medical, Dental
- [ ] Can log in with demo credentials
- [ ] Auth state visible in browser storage
- [ ] Protected routes redirect to `/login` when unauthenticated
- [ ] Logout clears tokens and redirects

**If all checked ✅ - You're ready to develop!**

---

**Last Updated**: 2026-09-01  
**Version**: 3.0