## Setup

Refer to the following for build and run in local environment.

> Both the backend and frontend must be running. The category filter always calls the live Python API.

### Backend (Python FastAPI)
```bash
# Navigate to backend directory
cd backend

# Install dependencies (first time only)
pip install -r requirements.txt

# Run the API server
uvicorn main:app --reload --port 8080
```

- Runs on: `http://localhost:8080`
- Categories endpoint: `GET http://localhost:8080/api/v1/categories`
- Interactive docs: `http://localhost:8080/docs`
- To add/remove categories edit `backend/category.properties` and restart

### Frontend (Angular)
```bash
# Navigate to frontend directory
cd frontend

# Install dependencies (first time only)
npm install

# Run development server
npm start

# Run tests (Jest)
npm test

# Run a single test file
npm test -- path/to/file.spec.ts

# Lint
npm run lint

# Format
npm run format

# Build for production
npm run build
```

- Runs on: `http://localhost:4300`
- Auth and product data are mocked (`useMockData: true` in `src/environments/environment.ts`)
- Categories are always fetched live from the Python backend
