# AGENTS.md

This file provides guidance to agents when working with code in this repository.

## Project-Specific Non-Obvious Rules

### Implementation Strategy (CRITICAL)
- **Hybrid implementation** — Python backend handles categories; auth and products remain mocked in the frontend
- `GET /api/v1/categories` is **always called live** — it bypasses `useMockData` — the Python backend must be running
- Auth and product data are mocked in `.mock.ts` files; `useMockData` flag controls those only
- Backend directory contains a real FastAPI app (`main.py`), not just reference specs

### Backend (Python FastAPI)
- Entry point: `backend/main.py`
- Categories config: `backend/category.properties` (key: `categories`, comma-separated values)
- Run: `uvicorn main:app --reload --port 8080`
- CORS is configured for `http://localhost:4300` only
- Live endpoint: `GET http://localhost:8080/api/v1/categories`
- Docs: `http://localhost:8080/docs`

### Frontend Ports
- Frontend: `http://localhost:4300` (set in `angular.json`)
- Backend: `http://localhost:8080` (set in `frontend/src/environments/environment.ts`)

### Frontend: Jest (NOT Karma as stated in angular.json)
- Project uses Jest + jest-preset-angular for testing (NOT Jasmine + Karma)
- Test command: `npm test` (runs Jest, not Karma)
- Path aliases configured in `jest.config.ts` (e.g., `@aibenefit-portal/shared-ui`)
- 80% coverage threshold enforced in `jest.config.ts`

### Frontend: Tailwind v3 (NOT v4 as stated in frontend/AGENTS.md)
- `package.json` shows Tailwind CSS v3.4.3, not v4
- Uses standard Tailwind config, not `@tailwindcss/postcss`

### Testing Strategy
- Frontend: Run single test file with `npm test -- <filename>.spec.ts`
- Coverage: 80% minimum threshold enforced via Jest config

### Mode-Specific File Restrictions
- Plan mode can only edit `\.md$` files - attempting to edit code files will fail with FileRestrictionError
- Other modes have different file pattern restrictions - check mode documentation

## Quick Commands

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8080
```

### Frontend
```bash
cd frontend
npm install
npm start              # Dev server on http://localhost:4300
npm test               # Run all tests
npm test -- file.spec.ts  # Run single test
npm run lint
npm run format
```

## Support Resources
- Frontend details: `../frontend/AGENTS.md`
- Backend: `../backend/main.py`, `../backend/category.properties`